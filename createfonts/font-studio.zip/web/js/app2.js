/* تب «چیدمان» (کرنینگ، ویژگی‌های OpenType، اتصال حروف) و ردیابی تصویر */
(function () {
  'use strict';
  var A = window.StudioApp, FS = window.FS; if (!A) return;
  var S = A.S, T = A.T, $ = A.$, esc = A.esc, hex = A.hex, Host = A.Host;

  /* ---------- یافتن گلیف از متن: نویسه، U+0628، #شماره، نام ---------- */
  function resolveGlyph(str) {
    str = (str || '').trim(); if (!str) return -1; var gl = S.font.glyphs;
    var n = gl.findIndex(function (g) { return g.name === str; }); if (n >= 0) return n;
    if (/^#\d+$/.test(str)) { var i = +str.slice(1); return i < gl.length ? i : -1; }
    var cp = null; if (Array.from(str).length === 1) cp = str.codePointAt(0); else if (/^(u\+|0x)[0-9a-f]{2,6}$/i.test(str)) cp = parseInt(str.replace(/^(u\+|0x)/i, ''), 16);
    if (cp !== null) return gl.findIndex(function (g) { return g.unicodes.indexOf(cp) >= 0; });
    return -1;
  }
  function gname(i) { var g = S.font.glyphs[i]; return g ? g.name : '#' + i; }
  function ref(i) { var g = S.font.glyphs[i]; if (!g) return '#' + i; return g.name; }

  var FEATURE_NAMES = { kern: 'کرنینگ', liga: 'لیگاتور استاندارد', rlig: 'لیگاتور اجباری', dlig: 'لیگاتور اختیاری', calt: 'جایگزینی متنی', clig: 'لیگاتور متنی', init: 'شکل آغازین', medi: 'شکل میانی', fina: 'شکل پایانی', isol: 'شکل مجزا', locl: 'محلی‌سازی', ccmp: 'ترکیب/تجزیه', mark: 'نشانه به پایه', mkmk: 'نشانه به نشانه', curs: 'اتصال مارپیچی', salt: 'جایگزین‌های سبکی', smcp: 'حروف کوچک بزرگ', numr: 'صورت', frac: 'کسر', zero: 'صفر با خط', ss01: 'مجموعهٔ سبکی ۱', ss02: 'مجموعهٔ سبکی ۲', ss03: 'مجموعهٔ سبکی ۳', aalt: 'جایگزین‌های دسترسی' };
  var LK_GSUB = { 1: 'جایگزینی ساده', 2: 'چندتایی', 3: 'جایگزین‌ها', 4: 'لیگاتور', 5: 'متنی', 6: 'متنی زنجیره‌ای', 8: 'معکوس' };
  var LK_GPOS = { 1: 'تک‌موقعیت', 2: 'جفت (کرنینگ)', 3: 'اتصال مارپیچی', 4: 'نشانه به پایه', 5: 'نشانه به لیگاتور', 6: 'نشانه به نشانه', 7: 'متنی', 8: 'متنی زنجیره‌ای' };

  function touch() { S.ttf = null; S.dirty = true; Host.setUnsaved(true); }

  /* =========================== تب چیدمان =========================== */
  var K = { l: -1, r: -1, rtl: true };
  A.viewLayout = function () {
    var m = $('main'), f = S.font, L = FS.layout.open(f);
    m.innerHTML =
      '<div class="card"><h3>' + T('کرنینگ جفت‌حروف', 'Pair kerning') + '</h3>' +
      '<div class="muted">' + T('کرنینگ روی گلیف‌های نهایی (بعد از جایگزینی‌های GSUB مثل شکل آغازین/پایانی) اعمال می‌شود؛ برای حروف متصل نام گلیف شکل (مثلاً uni0628.init) را بدهید.', 'Kerning applies to final glyphs (after GSUB). For joined letters use the form glyph name (e.g. uni0628.init).') + '</div>' +
      '<div class="row"><label class="f grow">' + T('گلیف اول (منطقی)', 'First glyph') + '<input id="kL" placeholder="A  /  U+0628  /  name  /  #12"></label><label class="f grow">' + T('گلیف دوم', 'Second glyph') + '<input id="kR"></label><button class="b" id="kSwap">⇄</button></div>' +
      '<label class="chk"><input type="checkbox" id="kRtl" ' + (K.rtl ? 'checked' : '') + '> ' + T('پیش‌نمایش راست‌به‌چپ', 'RTL preview') + '</label>' +
      '<canvas id="kCv" style="width:100%;height:150px;background:var(--card);border:1px solid var(--line);border-radius:12px"></canvas>' +
      '<div class="muted" id="kInfo"></div>' +
      '<div class="row"><button class="b" data-d="-50">−50</button><button class="b" data-d="-10">−10</button><button class="b" data-d="-1">−1</button><input id="kVal" type="number" value="0"><button class="b" data-d="1">+1</button><button class="b" data-d="10">+10</button><button class="b" data-d="50">+50</button></div>' +
      '<div class="row"><button class="b" id="kReset">' + T('بازگشت به مقدار اصلی فونت', 'Reset to font value') + '</button></div>' +
      '<label class="f">' + T('یا متنی بنویسید تا جفت‌های کنار هم را بسازم', 'Or type text to get its adjacent pairs') + '<input id="kText" placeholder="AVATAR   یا   میراث"></label><div class="row" id="kChips"></div></div>' +
      '<div class="card"><h3>' + T('کرنینگ‌های ثبت‌شدهٔ شما', 'Your kerning edits') + '</h3><div class="list" id="kList"></div></div>' +
      '<div class="card"><h3>' + T('ویژگی‌های OpenType', 'OpenType features') + '</h3><div class="row"><button class="b p" id="fAdd">＋ ' + T('ویژگی جایگزینی/لیگاتور جدید', 'New substitution feature') + '</button><button class="b" id="fJoin">🔗 ' + T('ساخت خودکار اتصال حروف (isol/init/medi/fina)', 'Auto-build joining forms') + '</button></div>' +
      '<div id="fGsub"></div><div id="fGpos"></div></div>';
    var pcv = $('kCv');
    function pair() { return K.l >= 0 && K.r >= 0; }
    function drawPair() {
      var cv = pcv, r = cv.getBoundingClientRect(), d = window.devicePixelRatio || 1; cv.width = Math.max(10, r.width * d); cv.height = Math.max(10, r.height * d); var ctx = cv.getContext('2d'); ctx.setTransform(d, 0, 0, d, 0, 0); ctx.clearRect(0, 0, r.width, r.height);
      if (!pair()) { $('kInfo').textContent = T('دو گلیف را وارد کنید.', 'Enter two glyphs.'); return; }
      var gl = f.glyphs, a = gl[K.l], b = gl[K.r], kv = FS.layout.getKern(L.GPOS, K.l, K.r), up = f.upm, s = (r.height * 0.62) / (f.hhea.asc - f.hhea.desc), baseY = r.height * 0.8 - 0, total = a.adv + b.adv + kv.total, ox = (r.width - total * s) / 2;
      function g(gi, x) { var gg = gl[gi]; if (!gg.contours.length) return; ctx.save(); ctx.setTransform(d * s, 0, 0, -d * s, d * (ox + x * s), d * baseY); ctx.fillStyle = getComputedStyle(document.body).color; ctx.fill(new Path2D(FS.geom.pathD(gg.contours, false)), 'nonzero'); ctx.restore(); }
      ctx.strokeStyle = 'rgba(128,128,128,.4)'; ctx.beginPath(); ctx.moveTo(0, baseY); ctx.lineTo(r.width, baseY); ctx.stroke();
      if (!K.rtl) { g(K.l, 0); g(K.r, a.adv + kv.total); mark(ox, a.adv, kv.total, s, r.height); }
      else { /* راست‌به‌چپ: گلیف اول سمت راست */ var xr = total; g(K.l, xr - a.adv); g(K.r, xr - a.adv - kv.total - b.adv); mark(ox + (b.adv) * s, b.adv, kv.total, s, r.height, true); }
      function mark(x0, w, kk, sc, H, rtl) { ctx.strokeStyle = '#f59e0b'; var x = rtl ? x0 - kk * sc : x0 + w * sc; ctx.beginPath(); ctx.moveTo(x, 8); ctx.lineTo(x, H - 8); ctx.stroke(); }
      $('kInfo').textContent = T('مقدار اصلی فونت: ', 'Font value: ') + kv.base + ' · ' + T('ویرایش شما: ', 'Your edit: ') + kv.own + ' · ' + T('مجموع: ', 'Total: ') + kv.total + '  (' + a.name + ' + ' + b.name + ')';
      $('kVal').value = kv.total;
    }
    function setKern(v) { if (!pair()) return; FS.layout.setKern(L.GPOS, K.l, K.r, v); touch(); drawPair(); listOwn(); }
    function load(l, r) { K.l = l; K.r = r; $('kL').value = ref(l); $('kR').value = ref(r); drawPair(); }
    function readIn() { K.l = resolveGlyph($('kL').value); K.r = resolveGlyph($('kR').value); drawPair(); }
    $('kL').onchange = readIn; $('kR').onchange = readIn; $('kRtl').onchange = function () { K.rtl = this.checked; drawPair(); };
    $('kSwap').onclick = function () { var t = $('kL').value; $('kL').value = $('kR').value; $('kR').value = t; readIn(); };
    m.querySelectorAll('[data-d]').forEach(function (b) { b.onclick = function () { if (pair()) setKern(FS.layout.getKern(L.GPOS, K.l, K.r).total + (+b.dataset.d)); }; });
    $('kVal').onchange = function () { setKern(+this.value || 0); };
    $('kReset').onclick = function () { if (pair()) setKern(FS.layout.getKern(L.GPOS, K.l, K.r).base); };
    $('kText').oninput = function () {
      var cs = Array.from(this.value), box = $('kChips'); box.innerHTML = '';
      for (var i = 0; i + 1 < cs.length; i++) { (function (a, b) { var ga = resolveGlyph(a), gb = resolveGlyph(b); if (ga < 0 || gb < 0) return; var bt = document.createElement('button'); bt.className = 'b'; bt.textContent = a + b; bt.onclick = function () { load(ga, gb); }; box.appendChild(bt); })(cs[i], cs[i + 1]); }
    };
    function listOwn() {
      var rows = FS.layout.ownPairs(L.GPOS).slice(0, 300), el = $('kList');
      el.innerHTML = rows.length ? rows.map(function (r, i) { return '<div class="kRow" data-i="' + i + '"><span dir="ltr">' + esc(gname(r[0])) + ' + ' + esc(gname(r[1])) + '</span><b dir="ltr">' + (r[2] > 0 ? '+' : '') + r[2] + '</b></div>'; }).join('') : '<div class="muted">' + T('هنوز کرنینگی ثبت نکرده‌اید.', 'No edits yet.') + '</div>';
      el.querySelectorAll('.kRow').forEach(function (d) { d.onclick = function () { var r = rows[+d.dataset.i]; load(r[0], r[1]); }; });
    }
    listOwn(); setTimeout(drawPair, 30);
    renderFeatures();
    $('fAdd').onclick = function () { featureDialog(null); };
    $('fJoin').onclick = joiningWizard;
  };

  function lookupDesc(m, i) {
    var l = m.lookups[i], names = m.kind === 'GSUB' ? LK_GSUB : LK_GPOS, n = '';
    if (l.rules) n = l.rules.map ? Object.keys(l.rules.map).length : l.rules.ligs ? l.rules.ligs.length : l.rules.pairs ? Object.keys(l.rules.pairs).length : '';
    return (names[l.type] || ('type ' + l.type)) + (n !== '' ? ' · ' + n : '') + (l.editable ? '' : ' · ' + T('فقط‌خواندنی', 'read-only'));
  }
  function renderFeatures() {
    var L = FS.layout.open(S.font);
    ['GSUB', 'GPOS'].forEach(function (k) {
      var m = L[k], el = $(k === 'GSUB' ? 'fGsub' : 'fGpos'); if (!el) return;
      var scripts = {}; m.scripts.forEach(function (s) { var set = {}; [s.def].concat(s.langs.map(function (l) { return l.ls; })).forEach(function (ls) { if (ls) ls.feats.forEach(function (fi) { set[fi] = 1; }); }); Object.keys(set).forEach(function (fi) { (scripts[fi] = scripts[fi] || []).push(s.tag.trim()); }); });
      var rows = m.features.map(function (ft, fi) { return { ft: ft, fi: fi }; }).filter(function (x) { return !x.ft.deleted; });
      el.innerHTML = '<h3 style="margin:10px 0 4px">' + k + ' <small class="muted">(' + rows.length + ')</small></h3>' + (rows.length ? '' : '<div class="muted">' + T('خالی', 'empty') + '</div>') + rows.map(function (x) {
        return '<details><summary><b dir="ltr">' + esc(x.ft.tag) + '</b> ' + esc(FEATURE_NAMES[x.ft.tag] || '') + ' <small class="muted">' + (scripts[x.fi] || []).join(' ') + '</small></summary>' +
          x.ft.lookups.map(function (li) { var l = m.lookups[li]; return '<div class="row"><span class="grow" dir="ltr">#' + li + ' ' + esc(lookupDesc(m, li)) + '</span>' + (l && l.editable && l.rules && !l.rules.pairs ? '<button class="b ruleEd" data-k="' + k + '" data-l="' + li + '">✎ ' + T('قواعد', 'Rules') + '</button>' : '') + '</div>'; }).join('') +
          '<div class="row"><button class="b d ftDel" data-k="' + k + '" data-f="' + x.fi + '">🗑 ' + T('حذف ویژگی', 'Remove feature') + '</button></div></details>';
      }).join('');
      el.querySelectorAll('.ruleEd').forEach(function (b) { b.onclick = function () { featureDialog({ kind: b.dataset.k, lookup: +b.dataset.l }); }; });
      el.querySelectorAll('.ftDel').forEach(function (b) { b.onclick = async function () { if (!(await A.ask(T('این ویژگی حذف شود؟ (lookupها در فایل می‌مانند ولی دیگر استفاده نمی‌شوند)', 'Remove this feature? (lookups stay in the file but are unused)')))) return; FS.layout.removeFeature(L[b.dataset.k], +b.dataset.f); touch(); renderFeatures(); }; });
    });
  }

  /* قواعد به‌صورت متن:  a -> b  |  f i -> fi  |  a -> b c  |  a -> b | c | d */
  function rulesToText(l) {
    var r = l.rules, out = [];
    if (r.ligs) r.ligs.slice(0, 2000).forEach(function (x) { out.push(x.comps.map(ref).join(' ') + ' -> ' + ref(x.out)); });
    else if (r.map) Object.keys(r.map).slice(0, 2000).forEach(function (k) { var v = r.map[k]; out.push(ref(+k) + ' -> ' + (Array.isArray(v) ? v.map(ref).join(l.type === 3 ? ' | ' : ' ') : ref(v))); });
    return out.join('\n');
  }
  function parseRules(text, type) {
    var lines = text.split(/\n/).map(function (s) { return s.trim(); }).filter(function (s) { return s && s[0] !== '#'; }), err = [];
    var out = type === 4 ? { ligs: [] } : { map: {} };
    function g(s, ln) { var i = resolveGlyph(s); if (i < 0) err.push(T('گلیف نامعتبر «', 'Unknown glyph “') + s + T('» در خط ', '” on line ') + (ln + 1)); return i; }
    lines.forEach(function (line, ln) {
      var p = line.split('->'); if (p.length !== 2) { err.push(T('خط ', 'Line ') + (ln + 1) + T(': قالب باید «ورودی -> خروجی» باشد', ': format must be “input -> output”')); return; }
      var L = p[0].trim().split(/\s+/), R = p[1].trim();
      if (type === 4) { var comps = L.map(function (s) { return g(s, ln); }), o = g(R, ln); if (comps.length < 2) { err.push(T('لیگاتور دست‌کم دو جزء می‌خواهد (خط ', 'Ligature needs ≥2 components (line ') + (ln + 1) + ')'); return; } if (comps.every(function (x) { return x >= 0; }) && o >= 0) out.ligs.push({ comps: comps, out: o }); }
      else { if (L.length !== 1) { err.push(T('خط ', 'Line ') + (ln + 1) + T(': ورودی باید یک گلیف باشد', ': input must be one glyph')); return; } var i = g(L[0], ln); if (type === 1) { var v = g(R, ln); if (i >= 0 && v >= 0) out.map[i] = v; } else { var outs = (type === 3 ? R.split('|') : R.split(/\s+/)).map(function (s) { return g(s.trim(), ln); }); if (i >= 0 && outs.length && outs.every(function (x) { return x >= 0; })) out.map[i] = outs; } }
    });
    return { rules: out, err: err };
  }
  var COMMON = ['liga', 'rlig', 'calt', 'ccmp', 'locl', 'init', 'medi', 'fina', 'isol', 'dlig', 'salt', 'ss01', 'ss02', 'ss03', 'smcp', 'frac', 'zero'];
  function featureDialog(edit) {
    var L = FS.layout.open(S.font), existing = edit ? L[edit.kind].lookups[edit.lookup] : null;
    var scriptTags = {}; L.GSUB.scripts.concat(L.GPOS.scripts).forEach(function (s) { scriptTags[s.tag] = 1; }); ['DFLT', 'arab', 'latn'].forEach(function (t) { scriptTags[t] = 1; });
    A.modal('<h3>' + (edit ? T('ویرایش قواعد', 'Edit rules') : T('ویژگی جدید (GSUB)', 'New feature (GSUB)')) + '</h3>' +
      (edit ? '' : '<label class="f">' + T('برچسب ویژگی', 'Feature tag') + '<input id="fdTag" dir="ltr" list="fdTags" value="liga" maxlength="4"><datalist id="fdTags">' + COMMON.map(function (t) { return '<option value="' + t + '">'; }).join('') + '</datalist></label>' +
        '<label class="f">' + T('نوع', 'Type') + '<select id="fdType"><option value="1">' + T('جایگزینی ساده (a -> b)', 'Single (a -> b)') + '</option><option value="4">' + T('لیگاتور (f i -> fi)', 'Ligature (f i -> fi)') + '</option><option value="2">' + T('چندتایی (a -> b c)', 'Multiple (a -> b c)') + '</option><option value="3">' + T('جایگزین‌ها (a -> b | c)', 'Alternates (a -> b | c)') + '</option></select></label>' +
        '<div class="muted">' + T('اسکریپت‌ها:', 'Scripts:') + '</div><div class="row">' + Object.keys(scriptTags).map(function (t) { return '<label class="chk"><input type="checkbox" class="fdS" value="' + esc(t) + '" ' + (t === 'DFLT' || t === 'arab' || t === 'latn' ? 'checked' : '') + '> ' + esc(t.trim()) + '</label>'; }).join('') + '</div>') +
      '<div class="muted">' + T('هر خط یک قاعده. گلیف: نویسه، U+0628، نام، یا #شماره.', 'One rule per line. Glyph: char, U+0628, name or #index.') + '</div>' +
      '<textarea id="fdRules" dir="ltr" placeholder="' + (edit ? '' : 'f i -> fi') + '">' + (existing ? esc(rulesToText(existing)) : '') + '</textarea><div class="err" id="fdErr"></div>' +
      '<div class="row"><button class="b p" id="fdOk">' + (edit ? T('اعمال', 'Apply') : T('ساخت', 'Create')) + '</button><button class="b" id="fdNo">' + T('انصراف', 'Cancel') + '</button></div>',
      function (b) {
        b.querySelector('#fdNo').onclick = A.closeModal;
        b.querySelector('#fdOk').onclick = function () {
          var type = edit ? existing.type : +b.querySelector('#fdType').value, pr = parseRules(b.querySelector('#fdRules').value, type);
          if (pr.err.length) { b.querySelector('#fdErr').textContent = pr.err.slice(0, 4).join(' · '); return; }
          var cnt = pr.rules.ligs ? pr.rules.ligs.length : Object.keys(pr.rules.map).length; if (!cnt) { b.querySelector('#fdErr').textContent = T('قاعده‌ای وارد نشده', 'No rules entered'); return; }
          try {
            if (edit) { existing.rules = pr.rules; existing.dirty = true; L[edit.kind].dirty = true; }
            else {
              var tag = (b.querySelector('#fdTag').value.trim() + '    ').slice(0, 4), tags = Array.from(b.querySelectorAll('.fdS')).filter(function (c) { return c.checked; }).map(function (c) { return c.value; });
              var li = FS.layout.addLookup(L.GSUB, type, pr.rules); FS.layout.addFeature(L.GSUB, tag, [li], tags);
            }
            touch(); A.closeModal(); renderFeatures(); A.toast(T('انجام شد', 'Done'));
          } catch (e) { b.querySelector('#fdErr').textContent = e.message; }
        };
      });
  }
  function joiningWizard() {
    var forms = FS.layout.suggestJoining(S.font), tags = ['isol', 'init', 'medi', 'fina'], cnt = tags.map(function (t) { return Object.keys(forms[t]).length; });
    var total = cnt.reduce(function (a, b) { return a + b; }, 0);
    A.modal('<h3>' + T('اتصال خودکار حروف', 'Auto joining forms') + '</h3><p class="muted">' + T('گلیف‌هایی که نامشان «نام.isol / .init / .medi / .fina» است با گلیف پایه هم‌نام جفت می‌شوند و ویژگی‌های عربی/فارسی ساخته می‌شود.', 'Glyphs named “name.isol/.init/.medi/.fina” are paired with the base glyph and the Arabic features are built.') + '</p>' +
      '<div class="card">' + tags.map(function (t, i) { return '<div class="row"><b dir="ltr">' + t + '</b><span class="grow"></span><span>' + cnt[i] + '</span></div>'; }).join('') + '</div>' +
      (total ? '<div class="row"><button class="b p" id="jgOk">' + T('ساخت ویژگی‌ها', 'Build features') + '</button><button class="b" id="jgNo">' + T('انصراف', 'Cancel') + '</button></div>' : '<div class="warn">' + T('گلیفی با این نام‌گذاری پیدا نشد. نام فرم‌ها را مثلاً uni0628.init بگذارید.', 'No matching glyph names. Name forms like uni0628.init.') + '</div><button class="b" id="jgNo">OK</button>'),
      function (b) {
        b.querySelector('#jgNo').onclick = A.closeModal; var ok = b.querySelector('#jgOk'); if (!ok) return;
        ok.onclick = function () {
          var L = FS.layout.open(S.font);
          tags.forEach(function (t) { if (!Object.keys(forms[t]).length) return; var map = {}; Object.keys(forms[t]).forEach(function (k) { map[k] = forms[t][k]; }); var li = FS.layout.addLookup(L.GSUB, 1, { map: map }); FS.layout.addFeature(L.GSUB, t, [li], ['arab', 'DFLT']); });
          touch(); A.closeModal(); renderFeatures(); A.toast(T('ویژگی‌ها ساخته شد؛ در تب «آزمایش» ببینید', 'Features built; check the Test tab'));
        };
      });
  }

  /* =========================== ردیابی تصویر =========================== */
  var TR = { img: null, canvas: null, bin: null, cs: null };
  function traceDialog() {
    var f = S.font, g = f.glyphs[S.gi];
    A.modal('<h3>📷 ' + T('ردیابی تصویر ← گلیف', 'Trace image → glyph') + '</h3>' +
      '<div class="row"><button class="b p" id="trPick">' + T('انتخاب تصویر (PNG/JPG/WebP)', 'Pick image') + '</button></div>' +
      '<canvas id="trCv" style="width:100%;max-height:260px;background:#fff;border:1px solid var(--line);border-radius:10px;margin:6px 0"></canvas>' +
      '<div class="row"><label class="chk"><input type="checkbox" id="trAuto" checked> ' + T('آستانهٔ خودکار', 'Auto threshold') + '</label><label class="chk"><input type="checkbox" id="trInv"> ' + T('معکوس (سفید روی سیاه)', 'Invert') + '</label></div>' +
      '<label class="f">' + T('آستانه', 'Threshold') + ' <span id="trThV">128</span><input id="trTh" type="range" min="1" max="254" value="128"></label>' +
      '<div class="row"><label class="f">' + T('نرمی', 'Smooth') + '<input id="trSm" type="number" value="2" min="0" max="8"></label><label class="f">' + T('دقت منحنی (px)', 'Tolerance') + '<input id="trTol" type="number" value="1.1" step="0.1"></label><label class="f">' + T('زاویهٔ گوشه°', 'Corner°') + '<input id="trCor" type="number" value="55"></label><label class="f">' + T('حذف لکه (px²)', 'Speckle') + '<input id="trSp" type="number" value="8"></label></div>' +
      '<label class="f">' + T('حالت', 'Mode') + '<select id="trMode"><option value="one">' + T('یک گلیف ← گلیف فعلی', 'One glyph → current glyph') + '</option><option value="sheet">' + T('برگهٔ حروف (چند گلیف)', 'Character sheet (many glyphs)') + '</option></select></label>' +
      '<div id="trOne"><div class="row"><label class="f">' + T('ارتفاع شکل', 'Shape height') + '<input id="trH" type="number" value="' + Math.round(f.upm * .7) + '"></label><label class="f">' + T('کف (y)', 'Bottom y') + '<input id="trY" type="number" value="0"></label><label class="f">LSB<input id="trL" type="number" value="' + Math.round(f.upm * .05) + '"></label></div><label class="chk"><input type="checkbox" id="trRep" checked> ' + T('جایگزین طرح فعلی', 'Replace current outline') + '</label></div>' +
      '<div id="trSheet" hidden><div class="row"><label class="f">' + T('ردیف', 'Rows') + '<input id="trR" type="number" value="1"></label><label class="f">' + T('ستون', 'Cols') + '<input id="trC" type="number" value="4"></label></div><label class="f">' + T('نویسه‌ها به ترتیب (چپ‌به‌راست، بالا به پایین)', 'Characters in order') + '<input id="trChars" placeholder="ABCD"></label><div class="row"><label class="f">' + T('ارتفاع سلول (واحد)', 'Cell height (units)') + '<input id="trCH" type="number" value="' + Math.round(f.upm * 1) + '"></label><label class="f">' + T('خط پایه (٪ از پایین سلول)', 'Baseline % from bottom') + '<input id="trBF" type="number" value="20"></label><label class="f">LSB<input id="trL2" type="number" value="' + Math.round(f.upm * .05) + '"></label></div></div>' +
      '<div class="muted" id="trInfo"></div><div class="row"><button class="b" id="trPrev">' + T('پیش‌نمایش ردیابی', 'Preview') + '</button><button class="b p" id="trGo">' + T('اعمال روی فونت', 'Apply') + '</button><button class="b" id="trNo">' + T('بستن', 'Close') + '</button></div>',
      function (b) {
        var q = function (id) { return b.querySelector('#' + id); }, cv = q('trCv');
        function opts() { return { auto: q('trAuto').checked, threshold: +q('trTh').value, invert: q('trInv').checked, smooth: +q('trSm').value, tolerance: +q('trTol').value, cornerAngle: +q('trCor').value, minArea: +q('trSp').value }; }
        function binarize() { if (!TR.img) return null; var o = opts(), bn = FS.trace.toBinary(TR.img, o); q('trThV').textContent = o.auto ? bn.thr + ' (auto)' : o.threshold; TR.bin = bn; return bn; }
        function paint(withTrace) {
          if (!TR.img) return; var bn = TR.bin || binarize(), w = TR.img.width, h = TR.img.height; cv.width = w; cv.height = h; var ctx = cv.getContext('2d'), id = ctx.createImageData(w, h);
          for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) { var ink = bn.bin[(y + 1) * bn.w + x + 1], i = (y * w + x) * 4, v = ink ? 40 : 255; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; }
          ctx.putImageData(id, 0, 0);
          if (withTrace && TR.cs) { ctx.save(); ctx.strokeStyle = '#ef4444'; ctx.lineWidth = Math.max(1, w / 300); ctx.stroke(new Path2D(FS.geom.pathD(TR.cs, false, 0, 0, 1))); ctx.restore(); }
        }
        q('trPick').onclick = async function () {
          try { var fl = await Host.pickFiles({}); if (!fl.length) return; var u8 = await Host.fetchBytes(fl[0].url || fl[0]), bmp = await createImageBitmap(new Blob([u8])); var sc = Math.min(1, 1600 / Math.max(bmp.width, bmp.height)), c = document.createElement('canvas'); c.width = Math.round(bmp.width * sc); c.height = Math.round(bmp.height * sc); c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height); TR.img = c.getContext('2d').getImageData(0, 0, c.width, c.height); TR.cs = null; binarize(); paint(false); q('trInfo').textContent = c.width + '×' + c.height; } catch (e) { A.fail(e); }
        };
        ['trAuto', 'trInv', 'trTh'].forEach(function (id) { q(id).oninput = function () { TR.cs = null; binarize(); paint(false); }; });
        q('trMode').onchange = function () { q('trOne').hidden = this.value !== 'one'; q('trSheet').hidden = this.value !== 'sheet'; };
        function runTrace() {
          var bn = binarize(); if (!bn) { A.toast(T('اول تصویر را انتخاب کنید', 'Pick an image first')); return null; }
          var copy = { bin: bn.bin.slice(), w: bn.w, h: bn.h }, cs = FS.trace.traceBinary(copy, opts()); TR.cs = cs; paint(true); var pts = 0; cs.forEach(function (c) { pts += c.length; }); q('trInfo').textContent = cs.length + ' ' + T('مسیر', 'contours') + ' · ' + pts + ' ' + T('نقطه', 'points'); return bn;
        }
        q('trPrev').onclick = runTrace; q('trNo').onclick = A.closeModal;
        q('trGo').onclick = function () {
          var bn = binarize(); if (!bn) { A.toast(T('اول تصویر را انتخاب کنید', 'Pick an image first')); return; }
          var o = opts();
          if (q('trMode').value === 'one') {
            var r = FS.trace.traceFit({ bin: bn.bin.slice(), w: bn.w, h: bn.h }, o, +q('trH').value || 700, +q('trY').value || 0, +q('trL').value || 0); if (!r.contours.length) { A.toast(T('شکلی پیدا نشد', 'Nothing traced')); return; }
            var gg = S.font.glyphs[S.gi], before = FS.editor.snap(gg); gg.contours = (q('trRep').checked ? [] : gg.contours).concat(r.contours); FS.editor.normalizeGlyph(gg); A.fixDirections(gg); var lsb = +q('trL').value || 0; if (q('trRep').checked || !gg.adv) gg.adv = Math.round(r.width + 2 * lsb);
            A.pushHistory([{ gi: S.gi, before: before, after: FS.editor.snap(gg) }]); A.changed(S.gi, true); A.closeModal(); A.toast(T('طرح اعمال شد', 'Outline applied')); if (S.tab === 'edit') A.go('edit');
          } else {
            var res = FS.trace.traceSheet({ bin: bn.bin.slice(), w: bn.w, h: bn.h }, o, +q('trR').value || 1, +q('trC').value || 1, q('trChars').value, +q('trCH').value || f.upm, (+q('trBF').value || 0) / 100, +q('trL2').value || 0), items = [], added = 0;
            var byU = {}; S.font.glyphs.forEach(function (gx, i) { gx.unicodes.forEach(function (u) { byU[u] = i; }); });
            res.forEach(function (it) {
              var cp = it.ch.codePointAt(0), gi = byU[cp], gx;
              if (gi === undefined) { gx = { name: 'uni' + hex(cp), adv: it.adv, unicodes: [cp], contours: [] }; S.font.glyphs.push(gx); S.font.snapshot.push([]); byU[cp] = S.font.glyphs.length - 1; gi = byU[cp]; added++; }
              gx = S.font.glyphs[gi]; var before = FS.editor.snap(gx); gx.contours = it.contours; gx.adv = it.adv; FS.editor.normalizeGlyph(gx); A.fixDirections(gx); items.push({ gi: gi, before: before, after: FS.editor.snap(gx) });
            });
            if (items.length) A.pushHistory(items); S.ttf = null; S.dirty = true; Host.setUnsaved(true); A.closeModal(); A.toast(res.length + ' ' + T('گلیف ساخته/به‌روز شد', 'glyphs created/updated') + (added ? ' (' + added + ' ' + T('جدید', 'new') + ')' : '')); A.go('glyphs');
          }
        };
      });
  }
  A.afterTools = function (m) {
    var d = document.createElement('details'); d.innerHTML = '<summary>📷 ' + T('ردیابی تصویر (دست‌خط/لوگو ← گلیف)', 'Image tracing (handwriting/logo → glyph)') + '</summary><div class="muted">' + T('عکس یا اسکن حروف را به طرح برداری تبدیل می‌کند؛ هم برای یک گلیف و هم برای یک برگهٔ کامل حروف.', 'Turns a photo/scan into outlines — for one glyph or a whole sheet.') + '</div><button class="b p" id="trOpen">' + T('باز کردن ردیاب', 'Open tracer') + '</button>';
    m.appendChild(d); d.querySelector('#trOpen').onclick = traceDialog;
  };
  A.afterEdit = function () {
    var row = document.createElement('button'); row.className = 'b'; row.textContent = '📷 ' + T('ردیابی تصویر', 'Trace image'); row.onclick = traceDialog; var t = $('tl2'); if (t) t.appendChild(row);
  };
  A.resolveGlyph = resolveGlyph;
})();
