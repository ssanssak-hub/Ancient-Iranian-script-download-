/* رابط استودیو فونت: صفحه‌ها، اتصال به میزبان اندروید، تاریخچه، ذخیرهٔ خودکار */
(function () {
  'use strict';
  var FS = window.FS, H = window.FontStudioHost;
  var $ = function (id) { return document.getElementById(id); };

  /* ---------- میزبان (روی دسکتاپ بدون اندروید هم کار می‌کند؛ برای آزمایش) ---------- */
  var Host = H || (function () {
    var mem = {};
    return {
      info: { lang: 'fa', dark: false, colors: {}, launch: { action: 'none' }, apiVersion: 0 },
      pickFiles: function () { return new Promise(function (res) { var i = document.createElement('input'); i.type = 'file'; i.onchange = function () { var f = i.files[0]; if (!f) return res([]); res([{ name: f.name, size: f.size, _file: f }]); }; i.click(); }); },
      fetchBytes: function (u) { return u._file.arrayBuffer().then(function (b) { return new Uint8Array(b); }); },
      saveFile: function (data, name, mime) { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: mime })); a.download = name; a.click(); return Promise.resolve({ saved: true, name: name }); },
      shareFile: function () { return Promise.resolve(false); },
      appFonts: { list: function () { return []; }, exportToStudio: function () { return Promise.reject(new Error('no host')); }, install: function () { return Promise.reject(new Error('no host')); } },
      ws: { list: function (d) { return Object.keys(mem).filter(function (k) { return k.indexOf((d ? d + '/' : '')) === 0; }).map(function (k) { return { name: k.split('/').pop(), isDir: false, size: mem[k].length, modified: 0 }; }); }, stat: function (p) { return { exists: !!mem[p] }; }, remove: function (p) { delete mem[p]; return true; }, put: function (p, d) { mem[p] = d; return Promise.resolve(true); }, read: function (p) { return Promise.resolve(mem[p]); }, putText: function () { return true; }, getText: function () { return null; } },
      toast: function (m) { toast(m); }, copyText: function (t) { navigator.clipboard && navigator.clipboard.writeText(t); }, openExternal: function (u) { window.open(u); }, haptic: function () { }, setUnsaved: function () { }, setBackHandler: function () { }, close: function () { }, openManager: function () { }, keepScreenOn: function () { }, on: function () { }
    };
  })();
  var fa = (Host.info.lang || 'fa') === 'fa';
  function T(a, b) { return fa ? a : (b || a); }
  document.documentElement.dir = fa ? 'rtl' : 'ltr'; document.documentElement.lang = fa ? 'fa' : 'en';
  if (Host.info.dark) document.documentElement.setAttribute('data-dark', '1');
  (function () { var c = Host.info.colors || {}, r = document.documentElement.style; if (c.background) r.setProperty('--bg', c.background); })();

  /* ---------- وضعیت ---------- */
  var S = { font: null, name: '', meta: {}, hist: [], redo: [], tab: 'start', dirty: false, ttf: null, origBytes: null, page: 0, q: '', filter: 'all', ed: null, testGen: 0 };
  var PAGE = 96;

  function toast(m) { var t = $('toast'); t.textContent = m; t.hidden = false; clearTimeout(toast._t); toast._t = setTimeout(function () { t.hidden = true; }, 2600); }
  function busy(msg) { $('busy').hidden = !msg; $('busyMsg').textContent = msg || ''; return new Promise(function (r) { setTimeout(r, 30); }); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function hex(n) { return n.toString(16).toUpperCase().padStart(4, '0'); }
  function modal(html, bind) { $('modalBox').innerHTML = html; $('modal').hidden = false; if (bind) bind($('modalBox')); }
  function closeModal() { $('modal').hidden = true; }
  $('modal').addEventListener('click', function (e) { if (e.target === $('modal')) closeModal(); });
  function ask(msg, yes, no) { return new Promise(function (res) { modal('<p>' + esc(msg) + '</p><div class="row"><button class="b p" id="mY">' + esc(yes || T('بله', 'Yes')) + '</button><button class="b" id="mN">' + esc(no || T('خیر', 'No')) + '</button></div>', function (b) { b.querySelector('#mY').onclick = function () { closeModal(); res(true); }; b.querySelector('#mN').onclick = function () { closeModal(); res(false); }; }); }); }
  function fail(e) { $('busy').hidden = true; console.error(e); modal('<h3 class="err">' + T('خطا', 'Error') + '</h3><p>' + esc(e && e.message || e) + '</p><button class="b" onclick="document.getElementById(\'modal\').hidden=true">' + T('باشه', 'OK') + '</button>'); }

  /* ---------- نام‌ها ---------- */
  function getName(id, lid) { lid = lid || 0x409; var r = S.font.names.filter(function (n) { return n.nid === id && n.pid === 3 && n.lid === lid; })[0]; return r ? r.str : ''; }
  function setName(id, val, lid) {
    lid = lid || 0x409; var f = S.font, r = f.names.filter(function (n) { return n.nid === id && n.pid === 3 && n.lid === lid; })[0];
    if (!val) { if (r) f.names.splice(f.names.indexOf(r), 1); return; }
    if (r) r.str = val; else f.names.push({ pid: 3, eid: 1, lid: lid, nid: id, str: val });
  }
  function fam() { return getName(1) || FS.io.famName(S.font); }

  /* ---------- تاریخچه / تغییر ---------- */
  function pushHistory(items) { S.hist.push(items); if (S.hist.length > 200) S.hist.shift(); S.redo = []; refreshUndo(); }
  function refreshUndo() { $('btnUndo').disabled = !S.hist.length; $('btnRedo').disabled = !S.redo.length; }
  function applyItems(items, useAfter) { items.forEach(function (it) { FS.editor.restore(S.font.glyphs[it.gi], useAfter ? it.after : it.before); }); S.ttf = null; if (S.ed) { S.ed.sel = {}; S.ed.draw(); } changed(items[0].gi, true); }
  function undo() { var it = S.hist.pop(); if (!it) return; S.redo.push(it); applyItems(it.slice().reverse(), false); refreshUndo(); }
  function redo() { var it = S.redo.pop(); if (!it) return; S.hist.push(it); applyItems(it, true); refreshUndo(); }
  $('btnUndo').onclick = undo; $('btnRedo').onclick = redo;
  var asTimer = null, lastAS = 0;
  function changed(gi, structural) {
    S.ttf = null; S.dirty = true; Host.setUnsaved(true); refreshUndo();
    var g = S.font.glyphs[gi]; if (g) { var c = document.getElementById('cell' + gi); if (c) drawThumb(c.querySelector('canvas'), g); }
    if (S.tab === 'edit') updateEdHeader();
    clearTimeout(asTimer); var wait = S.font.glyphs.length > 3000 ? 20000 : 4000; asTimer = setTimeout(autosave, wait);
  }
  async function autosave() {
    if (!S.font || !S.dirty) return;
    try { flushLayout(); await Host.ws.put('autosave/current.dfproj', FS.io.saveProject(S.font, S.meta)); Host.ws.putText('autosave/current.json', JSON.stringify({ name: S.name, family: fam(), glyphs: S.font.glyphs.length, at: Date.now() })); lastAS = Date.now(); } catch (e) { console.warn(e); }
  }
  if (Host.on) { Host.on('pause', function () { clearTimeout(asTimer); autosave(); }); }

  /* ---------- ساخت فونت خروجی (کش‌شده) ---------- */
  function flushLayout() { if (S.font && S.font._layout) { FS.layout.commit(S.font); } }
  function buildTtf() { flushLayout(); if (!S.ttf) S.ttf = FS.sfnt.buildFont(S.font); return S.ttf; }

  /* ---------- باز کردن / ساختن ---------- */
  function openFont(font, name, orig, meta) {
    S.font = font; S.name = name || fam() || 'font'; S.meta = meta || {}; S.hist = []; S.redo = []; S.ttf = null; S.origBytes = orig || null; S.page = 0; S.q = ''; S.dirty = false;
    font.origIds = font.origIds || font.glyphs.map(function (_, i) { return i; });
    refreshUndo(); Host.setUnsaved(false);
    var important = (font.warnings || []).filter(function (w) { return w.indexOf('هینتینگ') < 0; });
    if (important.length) setTimeout(function () { modal('<h3>' + T('نکته', 'Notes') + '</h3><ul>' + important.map(function (w) { return '<li>' + esc(w) + '</li>'; }).join('') + '</ul><button class="b" onclick="document.getElementById(\'modal\').hidden=true">' + T('باشه', 'OK') + '</button>'); }, 200);
    go('glyphs');
  }
  async function openBytes(u8, name) {
    await busy(T('در حال خواندن فونت…', 'Reading font…'));
    try { var r = await FS.io.openAny(u8, name); $('busy').hidden = true; openFont(r.font, (name || 'font').replace(/\.[^.]+$/, ''), r.via === 'project' ? null : u8, r.meta); }
    catch (e) { fail(e); }
  }
  async function pickAndOpen() {
    var files = await Host.pickFiles({ multiple: false }); if (!files.length) return;
    var f = files[0], u8 = await Host.fetchBytes(f.url || f); openBytes(u8, f.name);
  }
  async function openAppFont(name) {
    await busy(T('در حال باز کردن فونت اپلیکیشن…', 'Opening the app font…'));
    try { var r = await Host.appFonts.exportToStudio(name); $('busy').hidden = true; await openBytes(r.bytes, r.name); S.meta.fromApp = name; } catch (e) { fail(e); }
  }

  var PRESETS = [
    ['latin', 'حروف لاتین و اعداد (A–Z, a–z, 0–9, علائم)', function () { var a = []; for (var c = 0x21; c <= 0x7E; c++) a.push(c); return a; }],
    ['arabic', 'حروف عربی/فارسی پایه (۰۶۲۱–۰۶۴۸ …)', function () { var a = [0x0621, 0x0622, 0x0623, 0x0624, 0x0625, 0x0626, 0x0627, 0x0628, 0x0629, 0x062A, 0x062B, 0x062C, 0x062D, 0x062E, 0x062F, 0x0630, 0x0631, 0x0632, 0x0633, 0x0634, 0x0635, 0x0636, 0x0637, 0x0638, 0x0639, 0x063A, 0x0641, 0x0642, 0x0643, 0x0644, 0x0645, 0x0646, 0x0647, 0x0648, 0x0649, 0x064A, 0x067E, 0x0686, 0x0698, 0x06AF, 0x06A9, 0x06CC, 0x060C, 0x061B, 0x061F, 0x200C]; return a; }],
    ['fadigits', 'ارقام فارسی (۰–۹)', function () { var a = []; for (var c = 0x06F0; c <= 0x06F9; c++) a.push(c); return a; }],
    ['pua', 'محدودهٔ کاربر خصوصی (E000–E0FF)', function () { var a = []; for (var c = 0xE000; c <= 0xE0FF; c++) a.push(c); return a; }]
  ];
  function newFontDialog() {
    modal('<h3>' + T('ساخت فونت جدید', 'New font') + '</h3>' +
      '<label class="f">' + T('نام خانواده', 'Family name') + '<input id="nfName" value="MyFont"></label>' +
      '<label class="f">' + T('واحد در em (UPM)', 'Units per em') + '<select id="nfUpm"><option>1000</option><option selected>2048</option><option>1024</option></select></label>' +
      '<div class="muted">' + T('گلیف‌های خالی برای این موارد ساخته می‌شود:', 'Create empty glyphs for:') + '</div>' +
      PRESETS.map(function (p, i) { return '<label class="chk"><input type="checkbox" class="nfp" data-i="' + i + '" ' + (i < 2 ? 'checked' : '') + '> ' + esc(p[1]) + '</label>'; }).join('') +
      '<div class="row"><button class="b p" id="nfOk">' + T('ساخت', 'Create') + '</button><button class="b" id="nfNo">' + T('انصراف', 'Cancel') + '</button></div>',
      function (b) {
        b.querySelector('#nfNo').onclick = closeModal;
        b.querySelector('#nfOk').onclick = function () {
          var upm = +b.querySelector('#nfUpm').value, name = b.querySelector('#nfName').value.trim() || 'MyFont', codes = {};
          b.querySelectorAll('.nfp').forEach(function (c) { if (c.checked) PRESETS[+c.dataset.i][2]().forEach(function (u) { codes[u] = 1; }); });
          closeModal(); openFont(makeNewFont(name, upm, Object.keys(codes).map(Number).sort(function (a, b) { return a - b; })), name);
        };
      });
  }
  function makeNewFont(name, upm, codes) {
    var asc = Math.round(upm * .8), desc = -Math.round(upm * .2), m = Math.round(upm * .05), w = Math.round(upm * .5), s = Math.round(upm * .05);
    var gl = [{ name: '.notdef', adv: w, unicodes: [], contours: [[{ x: m, y: 0, on: true }, { x: m, y: asc, on: true }, { x: w - m, y: asc, on: true }, { x: w - m, y: 0, on: true }], [{ x: m + s, y: s, on: true }, { x: w - m - s, y: s, on: true }, { x: w - m - s, y: asc - s, on: true }, { x: m + s, y: asc - s, on: true }]] },
      { name: 'space', adv: Math.round(upm * .25), unicodes: [0x20, 0xA0], contours: [] }];
    codes.forEach(function (c) { if (c === 0x20 || c === 0xA0) return; gl.push({ name: 'uni' + hex(c), adv: w, unicodes: [c], contours: [] }); });
    var now = Math.floor(Date.now() / 1000) + 2082844800;
    var f = {
      upm: upm, glyphs: gl, flavor: 'ttf', extra: {}, warnings: [], origGlyphCount: gl.length, origNames: gl.map(function (g) { return g.name; }),
      head: { macStyle: 0, flags: 3, revision: 1, created: [0, now], lowestRecPPEM: 8 }, hhea: { asc: asc, desc: desc, gap: 0 }, post: { italicAngle: 0, underlinePosition: -Math.round(upm * .1), underlineThickness: Math.round(upm * .05), isFixedPitch: 0 },
      os2: { weight: 400, width: 5, fsType: 0, typoAsc: asc, typoDesc: desc, typoGap: 0, winAsc: asc, winDesc: -desc, xHeight: Math.round(upm * .5), capHeight: Math.round(upm * .7), useTypo: true, wws: false, vendor: 'NONE', panose: [], unicodeRange: [0, 0, 0, 0], codePage: [1, 0], familyClass: 0 },
      names: []
    };
    [[1, name], [2, 'Regular'], [4, name], [5, 'Version 1.000'], [6, name.replace(/[^A-Za-z0-9]/g, '') + '-Regular']].forEach(function (n) { f.names.push({ pid: 3, eid: 1, lid: 0x409, nid: n[0], str: n[1] }); });
    f.snapshot = gl.map(function (g) { return JSON.parse(JSON.stringify(g.contours)); });
    return f;
  }

  /* ---------- ناوبری ---------- */
  var TABS = [['glyphs', '▦', 'گلیف‌ها', 'Glyphs'], ['edit', '✎', 'ویرایش', 'Edit'], ['test', 'Aa', 'آزمایش', 'Test'], ['layout', '⇄', 'چیدمان', 'Layout'], ['info', 'ℹ', 'اطلاعات', 'Info'], ['tools', '⚙', 'ابزارها', 'Tools'], ['export', '⇪', 'خروجی', 'Export']];
  function go(tab) {
    S.tab = tab; var nav = $('nav'); nav.hidden = tab === 'start';
    nav.innerHTML = TABS.map(function (t) { return '<button data-t="' + t[0] + '" class="' + (t[0] === tab ? 'on' : '') + '"><span>' + t[1] + '</span>' + T(t[2], t[3]) + '</button>'; }).join('');
    nav.querySelectorAll('button').forEach(function (b) { b.onclick = function () { go(b.dataset.t); }; });
    $('sub').textContent = S.font ? fam() + ' · ' + S.font.glyphs.length + ' ' + T('گلیف', 'glyphs') : '';
    var m = $('main'); m.innerHTML = ''; m.scrollTop = 0; S.ed = null;
    ({ start: viewStart, glyphs: viewGlyphs, edit: viewEdit, test: viewTest, layout: function () { return window.StudioApp.viewLayout(); }, info: viewInfo, tools: viewTools, export: viewExport })[tab]();
  }
  Host.setBackHandler && Host.setBackHandler(function () { if (!$('modal').hidden) { closeModal(); return true; } if (S.tab === 'edit') { go('glyphs'); return true; } if (S.tab !== 'glyphs' && S.tab !== 'start' && S.font) { go('glyphs'); return true; } return false; });
  $('btnMenu').onclick = function () {
    modal('<h3>' + T('منو', 'Menu') + '</h3><div class="row">' +
      '<button class="b" id="mNew">🆕 ' + T('فونت جدید', 'New font') + '</button><button class="b" id="mOpen">📂 ' + T('باز کردن فایل', 'Open file') + '</button>' +
      '<button class="b" id="mSaveP">💾 ' + T('ذخیرهٔ پروژه', 'Save project') + '</button><button class="b" id="mHome">🏠 ' + T('صفحهٔ شروع', 'Start page') + '</button>' +
      '<button class="b" id="mMgr">🧰 ' + T('مدیریت استودیو', 'Studio manager') + '</button><button class="b d" id="mClose">✖ ' + T('بستن', 'Close') + '</button></div>',
      function (b) {
        b.querySelector('#mNew').onclick = function () { closeModal(); newFontDialog(); }; b.querySelector('#mOpen').onclick = function () { closeModal(); pickAndOpen(); };
        b.querySelector('#mSaveP').onclick = function () { closeModal(); if (S.font) saveProject(); }; b.querySelector('#mHome').onclick = function () { closeModal(); go('start'); };
        b.querySelector('#mMgr').onclick = function () { closeModal(); Host.openManager(); }; b.querySelector('#mClose').onclick = function () { closeModal(); Host.close(); };
      });
  };

  /* ---------- شروع ---------- */
  async function viewStart() {
    var m = $('main'); $('sub').textContent = '';
    var fonts = []; try { fonts = Host.appFonts.list().filter(function (f) { return f.exportable; }); } catch (e) { }
    var projects = []; try { projects = Host.ws.list('projects').filter(function (x) { return /\.dfproj$/.test(x.name); }); } catch (e) { }
    var as = null; try { if (Host.ws.stat('autosave/current.dfproj').exists) as = JSON.parse(Host.ws.getText('autosave/current.json') || '{}'); } catch (e) { }
    m.innerHTML = '<div class="hero"><div style="font-size:46px">🅰️</div><h2>' + T('استودیو ساخت و ویرایش فونت', 'Font Creation & Editing Studio') + '</h2><div class="muted">' + T('ساخت فونت تازه یا ویرایش فونت موجود', 'Create a new font or edit an existing one') + '</div></div>' +
      '<div class="card"><div class="row"><button class="b p grow" id="sNew">🆕 ' + T('ساخت فونت جدید', 'New font') + '</button><button class="b grow" id="sOpen">📂 ' + T('باز کردن فایل (TTF · OTF · WOFF · dfproj · fcp)', 'Open file (TTF · OTF · WOFF · dfproj · fcp)') + '</button></div></div>' +
      (as ? '<div class="card"><h3>♻️ ' + T('بازیابی خودکار', 'Auto-recovery') + '</h3><div class="muted">' + esc(as.family || as.name || '') + ' · ' + (as.glyphs || '?') + ' ' + T('گلیف', 'glyphs') + (as.at ? ' · ' + new Date(as.at).toLocaleString() : '') + '</div><button class="b" id="sRestore">' + T('بازیابی', 'Restore') + '</button></div>' : '') +
      (fonts.length ? '<div class="card"><h3>' + T('فونت‌های اپلیکیشن', 'App fonts') + '</h3><div class="row">' + fonts.map(function (f) { return '<button class="b appf" data-n="' + esc(f.name) + '">' + (f.isSelected ? '★ ' : '') + esc(f.display) + '</button>'; }).join('') + '</div></div>' : '') +
      (projects.length ? '<div class="card"><h3>' + T('پروژه‌های ذخیره‌شده', 'Saved projects') + '</h3><div class="row">' + projects.map(function (p) { return '<button class="b prj" data-n="' + esc(p.name) + '">📁 ' + esc(p.name.replace(/\.dfproj$/, '')) + '</button>'; }).join('') + '</div></div>' : '');
    $('sNew').onclick = newFontDialog; $('sOpen').onclick = pickAndOpen;
    if ($('sRestore')) $('sRestore').onclick = async function () { try { var b = await Host.ws.read('autosave/current.dfproj'); openBytes(b, as.name || 'recovered.dfproj'); } catch (e) { fail(e); } };
    m.querySelectorAll('.appf').forEach(function (b) { b.onclick = function () { openAppFont(b.dataset.n); }; });
    m.querySelectorAll('.prj').forEach(function (b) { b.onclick = async function () { try { openBytes(await Host.ws.read('projects/' + b.dataset.n), b.dataset.n); } catch (e) { fail(e); } }; });
  }
  async function saveProject() {
    try {
      flushLayout(); var data = FS.io.saveProject(S.font, S.meta), base = FS.io.slug(S.name || fam());
      await Host.ws.put('projects/' + base + '.dfproj', data); S.dirty = false; Host.setUnsaved(false); toast(T('پروژه در فضای کاری ذخیره شد', 'Project saved to workspace'));
    } catch (e) { fail(e); }
  }

  /* ---------- گلیف‌ها ---------- */
  function drawThumb(cv, g) {
    var f = S.font, d = 72, ctx = cv.getContext('2d'); if (!cv._init) { cv.width = d * 2; cv.height = d * 2; cv._init = 1; }
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height);
    var asc = Math.max(f.hhea.asc, f.upm * .8), desc = Math.min(f.hhea.desc, -f.upm * .2), s = cv.height * .8 / (asc - desc);
    var ox = (cv.width - g.adv * s) / 2, oy = cv.height * .1 + asc * s;
    ctx.strokeStyle = 'rgba(128,128,128,.35)'; ctx.beginPath(); ctx.moveTo(0, oy); ctx.lineTo(cv.width, oy); ctx.stroke();
    if (!g.contours.length) return;
    ctx.setTransform(s, 0, 0, -s, ox, oy); ctx.fillStyle = getComputedStyle(document.body).color; ctx.fill(new Path2D(FS.geom.pathD(g.contours, false)), 'nonzero');
  }
  function matchGlyphs() {
    var f = S.font, q = S.q.trim(), res = [];
    var qc = null; if (q.length === 1) qc = q.codePointAt(0); else if (/^(u\+|0x)?[0-9a-f]{4,6}$/i.test(q)) qc = parseInt(q.replace(/^(u\+|0x)/i, ''), 16);
    f.glyphs.forEach(function (g, i) {
      var ok = true;
      if (S.filter === 'mapped') ok = g.unicodes.length > 0; else if (S.filter === 'unmapped') ok = g.unicodes.length === 0; else if (S.filter === 'empty') ok = g.contours.length === 0 && g.unicodes.length > 0; else if (S.filter === 'filled') ok = g.contours.length > 0;
      if (ok && q) ok = (qc !== null && g.unicodes.indexOf(qc) >= 0) || g.name.toLowerCase().indexOf(q.toLowerCase()) >= 0 || String(i) === q;
      if (ok) res.push(i);
    });
    return res;
  }
  function viewGlyphs() {
    var m = $('main'), list = matchGlyphs(), pages = Math.max(1, Math.ceil(list.length / PAGE)); S.page = Math.min(S.page, pages - 1);
    m.innerHTML = '<div class="row"><input id="gq" class="grow" placeholder="' + T('جستجو: نام، حرف، کد (مثلاً 0628) یا شمارهٔ گلیف', 'Search: name, char, hex code or glyph index') + '" value="' + esc(S.q) + '">' +
      '<select id="gf"><option value="all">' + T('همه', 'All') + '</option><option value="mapped">' + T('دارای کد یونیکد', 'Mapped') + '</option><option value="unmapped">' + T('بدون کد', 'Unmapped') + '</option><option value="empty">' + T('خالی', 'Empty') + '</option><option value="filled">' + T('دارای طرح', 'Drawn') + '</option></select>' +
      '<button class="b p" id="gAdd">＋</button></div><div class="muted" style="margin:6px 2px">' + list.length + ' ' + T('گلیف', 'glyphs') + '</div><div class="grid" id="gg"></div>' +
      '<div class="pager"><button class="b" id="gp">‹</button><span>' + (S.page + 1) + ' / ' + pages + '</span><button class="b" id="gn">›</button></div>';
    $('gf').value = S.filter;
    var gg = $('gg'), slice = list.slice(S.page * PAGE, (S.page + 1) * PAGE);
    slice.forEach(function (i) {
      var g = S.font.glyphs[i], c = document.createElement('div'); c.className = 'cell' + (g.contours.length ? '' : ' empty'); c.id = 'cell' + i;
      c.innerHTML = '<canvas></canvas><small>' + (g.unicodes.length ? 'U+' + hex(g.unicodes[0]) : esc(g.name)) + '</small>'; drawThumb(c.firstChild, g);
      c.onclick = function () { S.gi = i; go('edit'); }; gg.appendChild(c);
    });
    var t; $('gq').oninput = function () { clearTimeout(t); var v = this.value; t = setTimeout(function () { S.q = v; S.page = 0; viewGlyphs(); var q = $('gq'); q.focus(); q.setSelectionRange(v.length, v.length); }, 350); };
    $('gf').onchange = function () { S.filter = this.value; S.page = 0; viewGlyphs(); };
    $('gp').onclick = function () { if (S.page > 0) { S.page--; viewGlyphs(); } }; $('gn').onclick = function () { if (S.page < pages - 1) { S.page++; viewGlyphs(); } };
    $('gAdd').onclick = addGlyphDialog;
  }
  function addGlyphDialog() {
    modal('<h3>' + T('افزودن گلیف', 'Add glyph') + '</h3><label class="f">' + T('کد یونیکد (هگز، مثل 0628) یا یک نویسه', 'Unicode (hex, e.g. 0628) or a character') + '<input id="agC"></label><label class="f">' + T('نام گلیف (اختیاری)', 'Glyph name (optional)') + '<input id="agN"></label><div class="row"><button class="b p" id="agOk">' + T('افزودن', 'Add') + '</button><button class="b" id="agNo">' + T('انصراف', 'Cancel') + '</button></div>', function (b) {
      b.querySelector('#agNo').onclick = closeModal;
      b.querySelector('#agOk').onclick = function () {
        var v = b.querySelector('#agC').value.trim(), nm = b.querySelector('#agN').value.trim(), cp = null;
        if (v) { if ([].concat(Array.from(v)).length === 1 && !/^[0-9a-f]$/i.test(v)) cp = v.codePointAt(0); else cp = parseInt(v.replace(/^(u\+|0x)/i, ''), 16); if (isNaN(cp)) { toast(T('کد نامعتبر', 'Invalid code')); return; } }
        if (cp !== null && S.font.glyphs.some(function (g) { return g.unicodes.indexOf(cp) >= 0; })) { toast(T('این کد قبلاً گلیف دارد', 'That code already has a glyph')); return; }
        var g = { name: nm || (cp !== null ? 'uni' + hex(cp) : 'glyph' + S.font.glyphs.length), adv: Math.round(S.font.upm * .5), unicodes: cp !== null ? [cp] : [], contours: [] };
        S.font.glyphs.push(g); S.font.snapshot.push([]); S.ttf = null; S.dirty = true; closeModal(); S.gi = S.font.glyphs.length - 1; go('edit');
      };
    });
  }

  /* ---------- ویرایش ---------- */
  S.gi = 0;
  function colors() { var cs = getComputedStyle(document.documentElement), dark = document.documentElement.getAttribute('data-dark') === '1'; return { bg: dark ? '#17181c' : '#ffffff', grid: dark ? 'rgba(255,255,255,.07)' : 'rgba(0,0,0,.07)', fill: dark ? 'rgba(180,160,255,.28)' : 'rgba(109,40,217,.18)', stroke: dark ? '#e5e5ee' : '#111', on: dark ? '#e5e5ee' : '#222' }; }
  function updateEdHeader() {
    var g = S.font.glyphs[S.gi]; if (!g || !$('edName')) return;
    $('edName').value = g.name; $('edUni').value = g.unicodes.map(hex).join(','); $('edAdv').value = g.adv;
    var b = FS.sfnt.bboxOf(g.contours); $('edLsb').value = b ? b.x0 : 0; $('edRsb').value = b ? g.adv - b.x1 : 0; $('edTitle').textContent = '#' + S.gi + ' · ' + g.name;
    $('btnPrev').disabled = S.gi <= 0; $('btnNext').disabled = S.gi >= S.font.glyphs.length - 1; $('edSel').textContent = S.ed ? S.ed.selKeys().length : 0;
  }
  function viewEdit() {
    var m = $('main'), f = S.font;
    m.innerHTML = '<div class="row"><button class="b" id="btnPrev">‹</button><b id="edTitle" class="grow" style="text-align:center"></b><button class="b" id="btnNext">›</button></div>' +
      '<div id="edWrap"><canvas id="cv"></canvas></div>' +
      '<div class="tools" id="tl1"></div><div class="tools" id="tl2"></div>' +
      '<details open><summary>' + T('مشخصات گلیف', 'Glyph properties') + '</summary><div class="row">' +
      '<label class="f grow">' + T('نام', 'Name') + '<input id="edName"></label><label class="f grow">' + T('یونیکد (هگز، با ویرگول)', 'Unicode (hex, comma)') + '<input id="edUni" dir="ltr"></label></div><div class="row">' +
      '<label class="f">' + T('عرض (advance)', 'Advance') + '<input id="edAdv" type="number"></label><label class="f">LSB<input id="edLsb" type="number"></label><label class="f">RSB<input id="edRsb" type="number"></label></div>' +
      '<div class="row"><button class="b" id="edDup">⎘ ' + T('کپی گلیف', 'Duplicate') + '</button><button class="b d" id="edDel">🗑 ' + T('حذف گلیف', 'Delete glyph') + '</button><button class="b" id="edClr">' + T('پاک‌کردن طرح', 'Clear outline') + '</button></div></details>' +
      '<details><summary>' + T('تبدیل‌ها (روی نقاط انتخاب‌شده؛ بدون انتخاب = کل گلیف)', 'Transform (selection; none = whole glyph)') + ' · <span id="edSel">0</span></summary>' +
      '<div class="row"><label class="f">X<input id="trX" type="number" value="0"></label><label class="f">Y<input id="trY" type="number" value="0"></label><button class="b" id="trMove">' + T('جابه‌جایی', 'Move') + '</button></div>' +
      '<div class="row"><label class="f">% X<input id="trSX" type="number" value="100"></label><label class="f">% Y<input id="trSY" type="number" value="100"></label><button class="b" id="trScale">' + T('مقیاس', 'Scale') + '</button></div>' +
      '<div class="row"><label class="f">' + T('زاویه°', 'Angle°') + '<input id="trRot" type="number" value="0"></label><button class="b" id="trRotB">' + T('چرخش', 'Rotate') + '</button><label class="f">' + T('کج°', 'Skew°') + '<input id="trSk" type="number" value="0"></label><button class="b" id="trSkB">' + T('کج‌کردن', 'Skew') + '</button></div>' +
      '<div class="row"><button class="b" id="trFH">⇆ ' + T('قرینه افقی', 'Flip H') + '</button><button class="b" id="trFV">⇅ ' + T('قرینه عمودی', 'Flip V') + '</button><button class="b" id="trRev">↻ ' + T('معکوس جهت', 'Reverse') + '</button><button class="b" id="trRound">' + T('گردکردن', 'Round') + '</button><button class="b" id="trExt">' + T('نقاط حدی', 'Extrema') + '</button></div></details>';
    var cv = $('cv'), ed = S.ed = new FS.editor.GlyphEditor(cv, { font: function () { return S.font; }, colors: colors, changed: changed, pushHistory: pushHistory, advChanged: function (a) { $('edAdv').value = a; }, selChanged: function () { updateEdHeader(); } });
    function resize() { ed.resize(); } setTimeout(function () { ed.resize(); ed.open(S.gi); updateEdHeader(); }, 30); window.onresize = resize;
    var tools = [['select', '⬚', 'انتخاب', 'Select'], ['hand', '✋', 'جابه‌جایی نما', 'Pan'], ['pen', '✒', 'قلم', 'Pen'], ['insert', '＋', 'افزودن نقطه', 'Add pt'], ['delete', '✖', 'حذف نقطه', 'Del pt']];
    $('tl1').innerHTML = tools.map(function (t) { return '<button class="b' + (ed.tool === t[0] ? ' on' : '') + '" data-t="' + t[0] + '">' + t[1] + ' ' + T(t[2], t[3]) + '</button>'; }).join('');
    $('tl1').querySelectorAll('button').forEach(function (b) { b.onclick = function () { ed.setTool(b.dataset.t); $('tl1').querySelectorAll('button').forEach(function (x) { x.classList.toggle('on', x === b); }); }; });
    function tg(id, label, get, set) { var b = document.createElement('button'); b.className = 'b' + (get() ? ' on' : ''); b.textContent = label; b.onclick = function () { set(!get()); b.classList.toggle('on', get()); ed.draw(); }; $('tl2').appendChild(b); }
    tg('multi', T('چندانتخابی', 'Multi'), function () { return ed.multi; }, function (v) { ed.multi = v; });
    tg('off', T('قلم: نقطهٔ کنترل', 'Pen: off-curve'), function () { return ed.penOff; }, function (v) { ed.penOff = v; });
    tg('snap', T('چسبیدن به شبکه', 'Snap'), function () { return ed.snapOn; }, function (v) { ed.snapOn = v; });
    tg('grid', T('شبکه', 'Grid'), function () { return ed.showGrid; }, function (v) { ed.showGrid = v; });
    tg('orig', T('طرح اصلی', 'Original'), function () { return ed.showOrig; }, function (v) { ed.showOrig = v; });
    tg('nums', T('شماره‌ها', 'Numbers'), function () { return ed.showNums; }, function (v) { ed.showNums = v; });
    var act = [['⟲', 'روشن/خاموش منحنی', 'On/Off curve', function () { ed.toggleOn(); }], ['▣', 'انتخاب همه', 'Select all', function () { ed.selectAll(); updateEdHeader(); }], ['⌫', 'حذف انتخاب', 'Delete sel.', function () { ed.removeKeys(ed.selKeys()); }], ['⎘', 'کپی', 'Copy', function () { toast(ed.copySel() + ' ' + T('مسیر کپی شد', 'contours copied')); }], ['⎗', 'چسباندن', 'Paste', function () { ed.paste(); }], ['⊡', 'فیت', 'Fit', function () { ed.fit(); ed.draw(); }]];
    act.forEach(function (a) { var b = document.createElement('button'); b.className = 'b'; b.textContent = a[0] + ' ' + T(a[1], a[2]); b.onclick = a[3]; $('tl2').appendChild(b); });
    function num(id) { return parseFloat($(id).value) || 0; }
    $('trMove').onclick = function () { var dx = num('trX'), dy = num('trY'); ed.transform(function (x, y) { return [x + dx, y + dy]; }); };
    $('trScale').onclick = function () { var a = num('trSX') / 100, b = num('trSY') / 100; ed.transform(function (x, y) { return [x * a, y * b]; }); };
    $('trRotB').onclick = function () { var r = num('trRot') * Math.PI / 180, c = Math.cos(r), s = Math.sin(r); ed.transform(function (x, y) { return [x * c - y * s, x * s + y * c]; }); };
    $('trSkB').onclick = function () { var k = Math.tan(num('trSk') * Math.PI / 180); ed.transform(function (x, y) { return [x + y * k, y]; }); };
    $('trFH').onclick = function () { ed.transform(function (x, y) { return [-x, y]; }); }; $('trFV').onclick = function () { ed.transform(function (x, y) { return [x, -y]; }); };
    $('trRev').onclick = function () { ed.reverse(); }; $('trRound').onclick = function () { ed.roundAll(); }; $('trExt').onclick = function () { ed.addExtrema(); };
    if (window.StudioApp.afterEdit) window.StudioApp.afterEdit(ed);
    $('btnPrev').onclick = function () { if (S.gi > 0) { S.gi--; ed.open(S.gi); updateEdHeader(); } }; $('btnNext').onclick = function () { if (S.gi < f.glyphs.length - 1) { S.gi++; ed.open(S.gi); updateEdHeader(); } };
    function metaEdit(fn) { var g = f.glyphs[S.gi], before = FS.editor.snap(g); fn(g); var after = FS.editor.snap(g); if (JSON.stringify(before) !== JSON.stringify(after)) { pushHistory([{ gi: S.gi, before: before, after: after }]); changed(S.gi, true); } ed.draw(); updateEdHeader(); }
    $('edName').onchange = function () { var v = this.value.replace(/[^A-Za-z0-9._]/g, '_').slice(0, 63) || 'glyph' + S.gi; metaEdit(function (g) { g.name = v; }); };
    $('edUni').onchange = function () {
      var arr = this.value.split(/[,\s]+/).filter(Boolean).map(function (s) { return parseInt(s.replace(/^(u\+|0x)/i, ''), 16); }).filter(function (n) { return !isNaN(n) && n > 0 && n <= 0x10FFFF; });
      var dup = arr.filter(function (c) { return f.glyphs.some(function (g, i) { return i !== S.gi && g.unicodes.indexOf(c) >= 0; }); });
      if (dup.length) { toast(T('کد تکراری با گلیف دیگر: U+', 'Duplicate code: U+') + hex(dup[0])); updateEdHeader(); return; }
      metaEdit(function (g) { g.unicodes = arr.sort(function (a, b) { return a - b; }); });
    };
    $('edAdv').onchange = function () { var v = Math.max(0, Math.round(+this.value || 0)); metaEdit(function (g) { g.adv = v; }); };
    $('edLsb').onchange = function () { var v = Math.round(+this.value || 0); metaEdit(function (g) { var b = FS.sfnt.bboxOf(g.contours); if (!b) return; var dx = v - b.x0; g.contours.forEach(function (c) { c.forEach(function (p) { p.x += dx; }); }); g.adv += dx; }); };
    $('edRsb').onchange = function () { var v = Math.round(+this.value || 0); metaEdit(function (g) { var b = FS.sfnt.bboxOf(g.contours); if (b) g.adv = Math.max(0, b.x1 + v); }); };
    $('edClr').onclick = function () { metaEdit(function (g) { g.contours = []; }); };
    $('edDup').onclick = function () { var g = f.glyphs[S.gi], ng = { name: g.name + '.copy', adv: g.adv, unicodes: [], contours: JSON.parse(JSON.stringify(g.contours)) }; f.glyphs.push(ng); f.snapshot.push([]); S.ttf = null; S.gi = f.glyphs.length - 1; go('edit'); toast(T('کپی ساخته شد (بدون کد یونیکد)', 'Copy created (no Unicode)')); };
    $('edDel').onclick = async function () {
      if (S.gi === 0) { toast(T('.notdef قابل حذف نیست', '.notdef cannot be deleted')); return; }
      if (!(await ask(T('این گلیف حذف شود؟ جدول‌های جانبی (GSUB/GPOS/kern) که به ترتیب گلیف‌ها وابسته‌اند هنگام خروجی کنار گذاشته می‌شوند و تاریخچه پاک می‌شود.', 'Delete this glyph? Glyph-order dependent tables (GSUB/GPOS/kern) will be dropped on export, and undo history is cleared.')))) return;
      f.glyphs.splice(S.gi, 1); f.snapshot.splice(S.gi, 1); f.origIds.splice(S.gi, 1); f.reordered = true; S.hist = []; S.redo = []; S.ttf = null; S.dirty = true; S.gi = Math.max(0, S.gi - 1); go('glyphs');
    };
  }

  /* ---------- آزمایش ---------- */
  async function loadFace(fname, bytes) {
    var face = new FontFace(fname, bytes.slice().buffer); await face.load();
    document.fonts.forEach(function (x) { if (x.family === fname) document.fonts.delete(x); }); document.fonts.add(face);
  }
  function viewTest() {
    var m = $('main'), sample = S.testText || 'ابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهیء ۰۱۲۳۴۵۶۷۸۹\nThe quick brown fox jumps over the lazy dog 0123456789';
    m.innerHTML = '<div class="card"><div class="test" id="tOut" contenteditable="true" spellcheck="false"></div>' +
      '<label class="f">' + T('اندازه', 'Size') + ' <span id="tSzV">40</span><input id="tSz" type="range" min="12" max="160" value="40"></label>' +
      '<div class="row"><label class="chk"><input type="checkbox" id="tRtl" ' + (fa ? 'checked' : '') + '> RTL</label><label class="chk"><input type="checkbox" id="tOrig"> ' + T('مقایسه با فونت اصلی (زیر)', 'Compare with original (below)') + '</label></div>' +
      '<label class="f">' + T('ویژگی‌های OpenType (مثل "liga" 0, "ss01")', 'OpenType features (e.g. "liga" 0, "ss01")') + '<input id="tFeat" dir="ltr" placeholder=\'"calt" 1\'></label>' +
      '<div class="muted" id="tNote"></div><div class="test" id="tOrigOut" hidden contenteditable="false" style="margin-top:8px;opacity:.75"></div></div>';
    var out = $('tOut'), oo = $('tOrigOut'); out.textContent = sample;
    function style() { var sz = $('tSz').value + 'px', dir = $('tRtl').checked ? 'rtl' : 'ltr', ft = $('tFeat').value.trim(); $('tSzV').textContent = $('tSz').value;[out, oo].forEach(function (el) { el.style.fontSize = sz; el.style.direction = dir; el.style.fontFeatureSettings = ft || 'normal'; }); }
    ['tSz', 'tRtl', 'tFeat'].forEach(function (id) { $(id).oninput = style; }); style();
    out.oninput = function () { S.testText = out.innerText; oo.textContent = out.innerText; };
    async function build() {
      var gen = ++S.testGen; $('tNote').textContent = T('در حال ساخت فونت آزمایشی…', 'Building test font…');
      await new Promise(function (r) { setTimeout(r, 20); });
      try { var ttf = buildTtf(); await loadFace('StudioTest', ttf); if (gen !== S.testGen) return; out.style.fontFamily = '"StudioTest"'; $('tNote').textContent = T('این متن با فونت در حال ویرایش نمایش داده می‌شود.', 'This text uses the font being edited.') + (S.font.lastDropped && S.font.lastDropped.length ? ' ⚠ ' + T('جدول‌های حذف‌شده: ', 'Dropped tables: ') + S.font.lastDropped.join(', ') : ''); }
      catch (e) { $('tNote').textContent = '⚠ ' + e.message; }
    }
    $('tOrig').onchange = async function () { oo.hidden = !this.checked; if (this.checked) { oo.textContent = out.innerText; if (S.origBytes) { try { await loadFace('StudioOrig', S.origBytes); oo.style.fontFamily = '"StudioOrig"'; } catch (e) { oo.textContent = '⚠ ' + e.message; } } else oo.textContent = T('فونت اصلی در دسترس نیست (پروژه یا فونت تازه).', 'No original font available.'); } };
    build();
  }

  /* ---------- اطلاعات ---------- */
  var NAME_FIELDS = [[1, 'خانوادهٔ فونت (Family)', 'Family'], [2, 'زیرخانواده (Subfamily)', 'Subfamily'], [4, 'نام کامل', 'Full name'], [6, 'نام PostScript (بدون فاصله)', 'PostScript name'], [5, 'نسخه', 'Version'], [0, 'حق کپی‌رایت', 'Copyright'], [8, 'سازنده', 'Manufacturer'], [9, 'طراح', 'Designer'], [10, 'توضیحات', 'Description'], [11, 'نشانی سازنده', 'Vendor URL'], [12, 'نشانی طراح', 'Designer URL'], [13, 'مجوز', 'License'], [14, 'نشانی مجوز', 'License URL']];
  function viewInfo() {
    var m = $('main'), f = S.font, o = f.os2;
    m.innerHTML = '<div class="card"><h3>' + T('نام‌ها', 'Names') + '</h3>' + NAME_FIELDS.map(function (n) { return '<label class="f">' + T(n[1], n[2]) + '<input class="nm" data-id="' + n[0] + '" value="' + esc(getName(n[0])) + '"></label>'; }).join('') +
      '<label class="f">' + T('نام فارسی خانواده (اختیاری)', 'Persian family name (optional)') + '<input class="nm" data-id="1" data-lid="1065" value="' + esc(getName(1, 0x429)) + '"></label></div>' +
      '<div class="card"><h3>' + T('اندازه‌ها و فاصله‌های عمودی', 'Metrics') + '</h3><div class="row">' +
      mi('upm', 'UPM', f.upm, true) + mi('asc', 'Ascent (hhea)', f.hhea.asc) + mi('desc', 'Descent (hhea)', f.hhea.desc) + mi('gap', 'LineGap', f.hhea.gap) +
      mi('tasc', 'Typo Ascender', o.typoAsc) + mi('tdesc', 'Typo Descender', o.typoDesc) + mi('tgap', 'Typo LineGap', o.typoGap) + mi('wasc', 'Win Ascent', o.winAsc) + mi('wdesc', 'Win Descent', o.winDesc) + mi('xh', 'x-Height', o.xHeight) + mi('ch', 'Cap Height', o.capHeight) + '</div>' +
      '<div class="row"><button class="b" id="iAuto">⚙ ' + T('محاسبهٔ خودکار از طرح گلیف‌ها', 'Auto-calc from glyph outlines') + '</button></div><div class="muted">' + T('تغییر UPM فقط عدد را عوض می‌کند؛ برای تغییر مقیاس طرح‌ها از «ابزارها» استفاده کنید.', 'Changing UPM only changes the number; use Tools to rescale outlines.') + '</div></div>' +
      '<div class="card"><h3>' + T('سبک و ویژگی‌ها', 'Style & flags') + '</h3><div class="row">' + mi('wt', T('وزن (۱۰۰–۹۰۰)', 'Weight (100–900)'), o.weight) + mi('wd', T('عرض (۱–۹)', 'Width (1–9)'), o.width) + mi('ia', T('زاویهٔ کج (ایتالیک)', 'Italic angle'), f.post.italicAngle) + mi('up', 'Underline pos', f.post.underlinePosition) + mi('ut', 'Underline thick', f.post.underlineThickness) + '</div>' +
      '<label class="chk"><input type="checkbox" id="iBold" ' + (f.head.macStyle & 1 ? 'checked' : '') + '> Bold</label><label class="chk"><input type="checkbox" id="iItal" ' + (f.head.macStyle & 2 ? 'checked' : '') + '> Italic</label><label class="chk"><input type="checkbox" id="iMono" ' + (f.post.isFixedPitch ? 'checked' : '') + '> ' + T('تک‌فاصله (Monospace)', 'Monospace') + '</label><label class="chk"><input type="checkbox" id="iTypo" ' + (o.useTypo ? 'checked' : '') + '> USE_TYPO_METRICS</label>' +
      '<label class="f">' + T('مجوز جاسازی (fsType)', 'Embedding (fsType)') + '<select id="iFs"><option value="0">0 — ' + T('نصب و جاسازی آزاد', 'Installable') + '</option><option value="2">2 — ' + T('محدود', 'Restricted') + '</option><option value="4">4 — Preview &amp; Print</option><option value="8">8 — ' + T('قابل‌ویرایش', 'Editable') + '</option></select></label></div>';
    function mi(id, label, val, ro) { return '<label class="f">' + label + '<input type="number" class="mt" id="mt_' + id + '" value="' + val + '"' + (ro ? ' readonly' : '') + '></label>'; }
    m.querySelectorAll('.nm').forEach(function (i) { i.onchange = function () { setName(+i.dataset.id, i.value.trim(), i.dataset.lid ? +i.dataset.lid : 0x409); S.dirty = true; S.ttf = null; if (i.dataset.id === '1') $('sub').textContent = fam(); }; });
    var map = { asc: function (v) { f.hhea.asc = v; }, desc: function (v) { f.hhea.desc = v; }, gap: function (v) { f.hhea.gap = v; }, tasc: function (v) { o.typoAsc = v; }, tdesc: function (v) { o.typoDesc = v; }, tgap: function (v) { o.typoGap = v; }, wasc: function (v) { o.winAsc = Math.max(0, v); }, wdesc: function (v) { o.winDesc = Math.max(0, v); }, xh: function (v) { o.xHeight = v; }, ch: function (v) { o.capHeight = v; }, wt: function (v) { o.weight = v; }, wd: function (v) { o.width = v; }, ia: function (v) { f.post.italicAngle = v; }, up: function (v) { f.post.underlinePosition = v; }, ut: function (v) { f.post.underlineThickness = v; } };
    m.querySelectorAll('.mt').forEach(function (i) { i.onchange = function () { var k = i.id.slice(3); if (map[k]) { map[k](+i.value || 0); S.dirty = true; S.ttf = null; } }; });
    function flag(id, fn) { $(id).onchange = function () { fn(this.checked); S.dirty = true; S.ttf = null; }; }
    flag('iBold', function (v) { f.head.macStyle = v ? f.head.macStyle | 1 : f.head.macStyle & ~1; }); flag('iItal', function (v) { f.head.macStyle = v ? f.head.macStyle | 2 : f.head.macStyle & ~2; });
    flag('iMono', function (v) { f.post.isFixedPitch = v ? 1 : 0; }); flag('iTypo', function (v) { o.useTypo = v; });
    $('iFs').value = String(o.fsType & 14 || 0); $('iFs').onchange = function () { o.fsType = +this.value; S.dirty = true; S.ttf = null; };
    $('iAuto').onclick = function () {
      var top = 0, bot = 0, xh = 0, ch = 0;
      f.glyphs.forEach(function (g) { var b = FS.sfnt.bboxOf(g.contours); if (!b || !g.unicodes.length) return; top = Math.max(top, b.y1); bot = Math.min(bot, b.y0); if (g.unicodes[0] === 0x78) xh = b.y1; if (g.unicodes[0] === 0x48) ch = b.y1; });
      f.hhea.asc = top; f.hhea.desc = bot; o.typoAsc = top; o.typoDesc = bot; o.winAsc = top; o.winDesc = Math.abs(bot); if (xh) o.xHeight = xh; if (ch) o.capHeight = ch; S.dirty = true; S.ttf = null; viewInfo(); toast(T('محاسبه شد', 'Calculated'));
    };
  }

  /* ---------- ابزارها ---------- */
  function scope() {
    var v = ($('scope') && $('scope').value) || 'all', r = ($('scopeR') && $('scopeR').value || '').trim(), res = [];
    var ranges = r ? r.split(/[,\s]+/).map(function (x) { var p = x.split('-').map(function (y) { return parseInt(y, 16); }); return [p[0], isNaN(p[1]) ? p[0] : p[1]]; }) : null;
    S.font.glyphs.forEach(function (g, i) {
      if (v === 'mapped' && !g.unicodes.length) return; if (v === 'filled' && !g.contours.length) return;
      if (ranges && !g.unicodes.some(function (u) { return ranges.some(function (rg) { return u >= rg[0] && u <= rg[1]; }); })) return;
      res.push(i);
    });
    return res;
  }
  function batch(label, fn) {
    var ids = scope(); if (!ids.length) { toast(T('گلیفی در این محدوده نیست', 'No glyphs in scope')); return; }
    var items = []; ids.forEach(function (i) { var g = S.font.glyphs[i], b = FS.editor.snap(g); fn(g, i); var a = FS.editor.snap(g); if (JSON.stringify(a) !== JSON.stringify(b)) items.push({ gi: i, before: b, after: a }); });
    if (items.length) { pushHistory(items); S.ttf = null; S.dirty = true; Host.setUnsaved(true); }
    toast(label + ': ' + items.length + ' ' + T('گلیف تغییر کرد', 'glyphs changed'));
  }
  function inside(pt, poly) { var c = false; for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) { var a = poly[i], b = poly[j]; if ((a.y > pt.y) !== (b.y > pt.y) && pt.x < (b.x - a.x) * (pt.y - a.y) / (b.y - a.y) + a.x) c = !c; } return c; }
  function fixDirections(g) {
    var cs = g.contours; cs.forEach(function (c, i) { var depth = 0; cs.forEach(function (o, j) { if (i !== j && inside(c[0], o)) depth++; }); var area = FS.editor.signedArea(c), wantCW = depth % 2 === 0; if ((wantCW && area > 0) || (!wantCW && area < 0)) { var f = c[0], r = c.slice(1).reverse(); r.unshift(f); r.forEach(function (p, k) { c[k] = p; }); } });
  }
  function validate() {
    var f = S.font, res = [], seen = {};
    if (!f.glyphs[0] || f.glyphs[0].name !== '.notdef') res.push(['err', '.notdef اولین گلیف نیست']); else if (!f.glyphs[0].contours.length) res.push(['warn', '.notdef خالی است (بهتر است یک مستطیل باشد)']);
    if (!getName(1)) res.push(['err', 'نام خانواده (Family) خالی است']); if (!getName(6)) res.push(['warn', 'نام PostScript خالی است']);
    f.glyphs.forEach(function (g, i) {
      g.unicodes.forEach(function (u) { if (seen[u] !== undefined) res.push(['err', 'U+' + hex(u) + ' به دو گلیف داده شده: #' + seen[u] + ' و #' + i]); seen[u] = i; });
      var b = FS.sfnt.bboxOf(g.contours);
      if (b && (b.x0 < -f.upm * 2 || b.x1 > f.upm * 4 || b.y0 < -f.upm * 2 || b.y1 > f.upm * 3)) res.push(['warn', '#' + i + ' ' + g.name + ': طرح بسیار دور از محدودهٔ معمول است']);
      g.contours.forEach(function (c) { if (c.length < 3) res.push(['warn', '#' + i + ' ' + g.name + ': مسیر با کمتر از ۳ نقطه']); });
      if (b && g.adv < b.x1 - 1) res.push(['warn', '#' + i + ' ' + g.name + ': عرض (advance) از لبهٔ راست طرح کمتر است']);
      if (g.unicodes.length && !g.contours.length && [0x20, 0xA0, 0x200B, 0x200C, 0x200D, 0x200E, 0x200F, 0x2009, 0x2003, 0x2002].indexOf(g.unicodes[0]) < 0) res.push(['warn', '#' + i + ' ' + g.name + ': کد دارد ولی خالی است']);
      var bad = false; if (g.contours.length) { var big = g.contours.reduce(function (a, c) { return Math.abs(FS.editor.signedArea(c)) > Math.abs(FS.editor.signedArea(a)) ? c : a; }); if (FS.editor.signedArea(big) > 0) bad = true; } if (bad) res.push(['warn', '#' + i + ' ' + g.name + ': جهت مسیر بیرونی ساعت‌گرد نیست']);
    });
    return res;
  }
  var BLOCKS = [['لاتین پایه', 0x20, 0x7E], ['لاتین ۱', 0xA0, 0xFF], ['لاتین گسترده A/B', 0x100, 0x24F], ['عربی/فارسی', 0x600, 0x6FF], ['عربی تکمیلی', 0x750, 0x77F], ['عربی گسترده A', 0x8A0, 0x8FF], ['اشکال نمایشی عربی A', 0xFB50, 0xFDFF], ['اشکال نمایشی عربی B', 0xFE70, 0xFEFF], ['عبری (مثلاً پهلوی کتابی)', 0x590, 0x5FF], ['گرجی تکمیلی (دبیره سینک)', 0x2D00, 0x2D2F], ['فاصله‌ها و نشانه‌ها', 0x2000, 0x206F], ['محدودهٔ خصوصی (PUA)', 0xE000, 0xF8FF]];
  var FA_ESSENTIAL = [0x0621, 0x0622, 0x0623, 0x0624, 0x0625, 0x0626, 0x0627, 0x0628, 0x0629, 0x062A, 0x062B, 0x062C, 0x062D, 0x062E, 0x062F, 0x0630, 0x0631, 0x0632, 0x0633, 0x0634, 0x0635, 0x0636, 0x0637, 0x0638, 0x0639, 0x063A, 0x0641, 0x0642, 0x0644, 0x0645, 0x0646, 0x0647, 0x0648, 0x067E, 0x0686, 0x0698, 0x06A9, 0x06AF, 0x06CC, 0x06F0, 0x06F1, 0x06F2, 0x06F3, 0x06F4, 0x06F5, 0x06F6, 0x06F7, 0x06F8, 0x06F9, 0x060C, 0x061B, 0x061F, 0x200C];
  function viewTools() {
    var m = $('main');
    m.innerHTML = '<details open><summary>' + T('عملیات گروهی', 'Batch operations') + '</summary><div class="row"><label class="f">' + T('روی', 'Scope') + '<select id="scope"><option value="all">' + T('همهٔ گلیف‌ها', 'All glyphs') + '</option><option value="mapped">' + T('گلیف‌های دارای کد', 'Mapped') + '</option><option value="filled">' + T('گلیف‌های دارای طرح', 'Drawn') + '</option></select></label><label class="f grow">' + T('محدودهٔ یونیکد (هگز، مثل 0600-06FF,FB50-FDFF)', 'Unicode ranges (hex)') + '<input id="scopeR" dir="ltr"></label></div>' +
      '<div class="row"><label class="f">% <input id="bScale" type="number" value="100"></label><button class="b" id="bScaleB">' + T('تغییر مقیاس طرح‌ها', 'Scale outlines') + '</button><label class="f">Y<input id="bShift" type="number" value="0"></label><button class="b" id="bShiftB">' + T('جابه‌جایی عمودی', 'Shift vertically') + '</button></div>' +
      '<div class="row"><label class="f">LSB<input id="bL" type="number" value="50"></label><label class="f">RSB<input id="bR" type="number" value="50"></label><button class="b" id="bSB">' + T('تنظیم فاصلهٔ کناری', 'Set side bearings') + '</button><label class="f">' + T('عرض ثابت', 'Fixed adv') + '<input id="bAdv" type="number" value="600"></label><button class="b" id="bAdvB">' + T('اعمال', 'Apply') + '</button></div>' +
      '<div class="row"><button class="b" id="bRound">' + T('گردکردن مختصات', 'Round coords') + '</button><button class="b" id="bDir">' + T('اصلاح جهت مسیرها', 'Fix directions') + '</button><button class="b" id="bExt">' + T('افزودن نقاط حدی', 'Add extrema') + '</button><button class="b" id="bCtr">' + T('وسط‌چین کردن طرح در عرض', 'Center in advance') + '</button></div></details>' +
      '<details><summary>' + T('نگاشت یونیکد (cmap)', 'Unicode map (cmap)') + '</summary><div class="row"><input id="cmQ" class="grow" placeholder="' + T('فیلتر: کد یا نام', 'Filter: code or name') + '"><button class="b" id="cmCsv">CSV ⇩</button><button class="b" id="cmImp">CSV ⇧</button></div><div class="row"><label class="f">' + T('کد', 'Code') + '<input id="cmC" dir="ltr" placeholder="06CC"></label><label class="f">' + T('نام یا شمارهٔ گلیف', 'Glyph name/index') + '<input id="cmG" dir="ltr"></label><button class="b" id="cmAdd">' + T('نگاشت', 'Map') + '</button></div><div class="list" id="cmL"></div></details>' +
      '<details><summary>' + T('بررسی کیفیت فونت', 'Font validation') + '</summary><button class="b p" id="vRun">' + T('بررسی', 'Run') + '</button><div class="list" id="vL" style="margin-top:6px"></div></details>' +
      '<details><summary>' + T('پوشش یونیکد (فارسی/عربی/پهلوی…)', 'Unicode coverage') + '</summary><div id="covL"></div></details>' +
      '<details><summary>' + T('ورود طرح از SVG به گلیف فعلی', 'Import SVG into current glyph') + '</summary><textarea id="svD" dir="ltr" placeholder="M10 10 L90 10 …  یا محتوای فایل .svg"></textarea><div class="row"><button class="b" id="svFile">' + T('انتخاب فایل SVG', 'Pick SVG file') + '</button><label class="f">' + T('ارتفاع', 'Height') + '<input id="svH" type="number" value="' + Math.round(S.font.upm * .7) + '"></label><label class="f">' + T('کف (y)', 'Bottom y') + '<input id="svY" type="number" value="0"></label><label class="f">LSB<input id="svL" type="number" value="' + Math.round(S.font.upm * .05) + '"></label></div><button class="b p" id="svGo">' + T('وارد کن به گلیف #', 'Import into glyph #') + S.gi + '</button></details>' +
      '<details><summary>' + T('وارد کردن گلیف‌ها از فونت دیگر', 'Import glyphs from another font') + '</summary><div class="muted">' + T('گلیف‌ها بر اساس کد یونیکد جایگزین/افزوده می‌شوند و در صورت تفاوت UPM مقیاس می‌گیرند.', 'Glyphs are matched by Unicode and rescaled if UPM differs.') + '</div><label class="f">' + T('محدودهٔ یونیکد (خالی = همه)', 'Unicode ranges (empty = all)') + '<input id="mgR" dir="ltr" placeholder="0600-06FF"></label><label class="chk"><input type="checkbox" id="mgRep" checked> ' + T('جایگزینی گلیف‌های موجود', 'Replace existing') + '</label><button class="b p" id="mgGo">' + T('انتخاب فونت و ادغام', 'Pick font and merge') + '</button></details>';
    $('bScaleB').onclick = function () { var k = (+$('bScale').value || 100) / 100; batch(T('مقیاس', 'Scale'), function (g) { g.contours.forEach(function (c) { c.forEach(function (p) { p.x = Math.round(p.x * k); p.y = Math.round(p.y * k); }); }); g.adv = Math.round(g.adv * k); }); };
    $('bShiftB').onclick = function () { var dy = Math.round(+$('bShift').value || 0); batch(T('جابه‌جایی', 'Shift'), function (g) { g.contours.forEach(function (c) { c.forEach(function (p) { p.y += dy; }); }); }); };
    $('bSB').onclick = function () { var l = Math.round(+$('bL').value || 0), r = Math.round(+$('bR').value || 0); batch(T('فاصله کناری', 'Bearings'), function (g) { var b = FS.sfnt.bboxOf(g.contours); if (!b) return; var dx = l - b.x0; g.contours.forEach(function (c) { c.forEach(function (p) { p.x += dx; }); }); g.adv = b.x1 + dx + r; }); };
    $('bAdvB').onclick = function () { var a = Math.round(+$('bAdv').value || 0); batch(T('عرض ثابت', 'Fixed advance'), function (g) { g.adv = a; }); };
    $('bRound').onclick = function () { batch(T('گردکردن', 'Round'), function (g) { g.contours.forEach(function (c) { c.forEach(function (p) { p.x = Math.round(p.x); p.y = Math.round(p.y); }); }); }); };
    $('bDir').onclick = function () { batch(T('اصلاح جهت', 'Directions'), function (g) { FS.editor.normalizeGlyph(g); fixDirections(g); }); };
    $('bExt').onclick = function () { batch(T('نقاط حدی', 'Extrema'), function (g) { FS.editor.addExtrema(g); }); };
    $('bCtr').onclick = function () { batch(T('وسط‌چین', 'Center'), function (g) { var b = FS.sfnt.bboxOf(g.contours); if (!b) return; var dx = Math.round((g.adv - (b.x1 - b.x0)) / 2 - b.x0); g.contours.forEach(function (c) { c.forEach(function (p) { p.x += dx; }); }); }); };
    function cmapList() {
      var q = $('cmQ').value.trim().toLowerCase(), rows = []; S.font.glyphs.forEach(function (g, i) { g.unicodes.forEach(function (u) { if (!q || hex(u).toLowerCase().indexOf(q.replace(/^u\+/, '')) >= 0 || g.name.toLowerCase().indexOf(q) >= 0) rows.push([u, i, g.name]); }); });
      rows.sort(function (a, b) { return a[0] - b[0]; }); var L = $('cmL'); L.innerHTML = rows.slice(0, 300).map(function (r) { return '<div><span dir="ltr">U+' + hex(r[0]) + ' ' + esc(String.fromCodePoint(r[0] < 0x20 ? 0xB7 : r[0])) + '</span><span dir="ltr">#' + r[1] + ' ' + esc(r[2]) + '</span><button class="b d cmDel" data-u="' + r[0] + '" data-g="' + r[1] + '">✖</button></div>'; }).join('') + (rows.length > 300 ? '<div class="muted">… ' + (rows.length - 300) + '</div>' : '');
      L.querySelectorAll('.cmDel').forEach(function (b) { b.onclick = function () { var g = S.font.glyphs[+b.dataset.g]; g.unicodes = g.unicodes.filter(function (u) { return u !== +b.dataset.u; }); S.ttf = null; S.dirty = true; cmapList(); }; });
    }
    cmapList(); $('cmQ').oninput = cmapList;
    function findGlyph(s) { s = s.trim(); if (/^#?\d+$/.test(s)) return +s.replace('#', ''); return S.font.glyphs.findIndex(function (g) { return g.name === s; }); }
    $('cmAdd').onclick = function () { var u = parseInt($('cmC').value.replace(/^(u\+|0x)/i, ''), 16), gi = findGlyph($('cmG').value); if (isNaN(u) || gi < 0 || !S.font.glyphs[gi]) { toast(T('ورودی نامعتبر', 'Invalid input')); return; } S.font.glyphs.forEach(function (g) { g.unicodes = g.unicodes.filter(function (x) { return x !== u; }); }); var g = S.font.glyphs[gi]; g.unicodes.push(u); g.unicodes.sort(function (a, b) { return a - b; }); S.ttf = null; S.dirty = true; cmapList(); };
    $('cmCsv').onclick = function () { var rows = ['unicode,glyph']; S.font.glyphs.forEach(function (g) { g.unicodes.forEach(function (u) { rows.push(hex(u) + ',' + g.name); }); }); Host.saveFile(rows.join('\n'), FS.io.slug(fam()) + '-cmap.csv', 'text/csv'); };
    $('cmImp').onclick = async function () { var fl = await Host.pickFiles({}); if (!fl.length) return; var u8 = await Host.fetchBytes(fl[0].url || fl[0]), n = 0; new TextDecoder().decode(u8).split(/\r?\n/).forEach(function (ln) { var p = ln.split(','); var u = parseInt(p[0], 16), gi = p[1] ? S.font.glyphs.findIndex(function (g) { return g.name === p[1].trim(); }) : -1; if (!isNaN(u) && gi >= 0) { S.font.glyphs.forEach(function (g) { g.unicodes = g.unicodes.filter(function (x) { return x !== u; }); }); S.font.glyphs[gi].unicodes.push(u); n++; } }); S.ttf = null; S.dirty = true; cmapList(); toast(n + ' ' + T('نگاشت وارد شد', 'mappings imported')); };
    $('vRun').onclick = function () {
      var r = validate(); $('vL').innerHTML = r.length ? r.slice(0, 400).map(function (x) { return '<div class="' + x[0] + '">' + (x[0] === 'err' ? '✖ ' : '⚠ ') + esc(x[1]) + '</div>'; }).join('') + (r.length > 400 ? '<div class="muted">… ' + (r.length - 400) + '</div>' : '') : '<div class="ok">✔ ' + T('مشکلی پیدا نشد', 'No problems found') + '</div>';
    };
    var have = {}; S.font.glyphs.forEach(function (g) { g.unicodes.forEach(function (u) { have[u] = 1; }); });
    var miss = FA_ESSENTIAL.filter(function (u) { return !have[u]; });
    $('covL').innerHTML = BLOCKS.map(function (b) { var n = 0; for (var u in have) if (+u >= b[1] && +u <= b[2]) n++; var tot = b[2] - b[1] + 1; return '<div class="row"><span class="grow">' + esc(b[0]) + ' <small class="muted" dir="ltr">' + hex(b[1]) + '–' + hex(b[2]) + '</small></span><b>' + n + '</b><span class="muted">/ ' + tot + '</span></div>'; }).join('') +
      '<div class="card" style="margin-top:8px"><b>' + T('حروف ضروری فارسی', 'Essential Persian') + ':</b> ' + (miss.length ? '<span class="warn">' + T('کم: ', 'Missing: ') + miss.map(function (u) { return String.fromCodePoint(u) + ' (' + hex(u) + ')'; }).join('، ') + '</span>' : '<span class="ok">✔ ' + T('کامل', 'complete') + '</span>') + '</div>';
    if (window.StudioApp.afterTools) window.StudioApp.afterTools(m);
    $('svFile').onclick = async function () { var fl = await Host.pickFiles({}); if (!fl.length) return; var u8 = await Host.fetchBytes(fl[0].url || fl[0]); $('svD').value = new TextDecoder().decode(u8); };
    $('svGo').onclick = function () {
      var txt = $('svD').value.trim(); if (!txt) return; var d = /<svg|<path|<rect|<circle/i.test(txt) ? FS.svg.pathsFromSvg(txt) : txt; if (!d) { toast(T('مسیری پیدا نشد', 'No path found')); return; }
      var r = FS.svg.toGlyphContours(d, +$('svH').value || S.font.upm * .7, +$('svY').value || 0, +$('svL').value || 0), g = S.font.glyphs[S.gi], before = FS.editor.snap(g);
      if (!r.contours.length) { toast(T('شکلی ساخته نشد', 'Nothing created')); return; }
      g.contours = g.contours.concat(r.contours); FS.editor.normalizeGlyph(g); fixDirections(g); if (!g.adv || g.adv < r.width) g.adv = Math.round(r.width + 2 * (+$('svL').value || 0));
      pushHistory([{ gi: S.gi, before: before, after: FS.editor.snap(g) }]); S.ttf = null; S.dirty = true; toast(T('وارد شد؛ در تب ویرایش ببینید', 'Imported; see Edit tab'));
    };
    $('mgGo').onclick = async function () {
      try {
        var fl = await Host.pickFiles({}); if (!fl.length) return; await busy(T('در حال خواندن و ادغام…', 'Merging…')); var u8 = await Host.fetchBytes(fl[0].url || fl[0]), r = await FS.io.openAny(u8, fl[0].name), src = r.font;
        var rs = $('mgR').value.trim(), ranges = rs ? rs.split(/[,\s]+/).map(function (x) { var p = x.split('-').map(function (y) { return parseInt(y, 16); }); return [p[0], isNaN(p[1]) ? p[0] : p[1]]; }) : null, k = S.font.upm / src.upm, n = 0, added = 0, rep = $('mgRep').checked;
        var byU = {}; S.font.glyphs.forEach(function (g, i) { g.unicodes.forEach(function (u) { byU[u] = i; }); });
        var items = [];
        src.glyphs.forEach(function (sg) {
          sg.unicodes.forEach(function (u) {
            if (ranges && !ranges.some(function (x) { return u >= x[0] && u <= x[1]; })) return;
            var cs = sg.contours.map(function (c) { return c.map(function (p) { return { x: Math.round(p.x * k), y: Math.round(p.y * k), on: p.on }; }); });
            if (byU[u] !== undefined) { if (!rep) return; var g = S.font.glyphs[byU[u]], b = FS.editor.snap(g); g.contours = cs; g.adv = Math.round(sg.adv * k); items.push({ gi: byU[u], before: b, after: FS.editor.snap(g) }); n++; }
            else { S.font.glyphs.push({ name: sg.name, adv: Math.round(sg.adv * k), unicodes: [u], contours: cs }); S.font.snapshot.push([]); byU[u] = S.font.glyphs.length - 1; added++; }
          });
        });
        if (items.length) pushHistory(items); S.ttf = null; S.dirty = true; $('busy').hidden = true; toast(T('جایگزین: ', 'Replaced: ') + n + T('، افزوده: ', ', added: ') + added);
      } catch (e) { fail(e); }
    };
  }

  /* ---------- خروجی ---------- */
  function viewExport() {
    var m = $('main'), base = FS.io.slug(fam());
    m.innerHTML = '<div class="card"><label class="f">' + T('نام فایل خروجی (بدون پسوند)', 'Output file name') + '<input id="xName" dir="ltr" value="' + esc(base) + '"></label><div class="muted" id="xNote"></div></div>' +
      '<div class="card"><h3>' + T('فایل فونت', 'Font files') + '</h3><div class="row">' +
      '<button class="b p" data-x="ttf">TTF</button><button class="b" data-x="woff">WOFF</button><button class="b" data-x="woff2">WOFF2</button><button class="b" data-x="eot">EOT</button><button class="b" data-x="svg">SVG Font</button></div>' +
      '<div class="muted">' + T('خروجی TrueType (glyf) است. WOFF2 بدون فشرده‌سازی Brotli نوشته می‌شود (معتبر و سازگار، ولی کم‌حجم‌ترین نیست؛ برای کم‌ترین حجم از WOFF استفاده کنید).', 'TrueType (glyf) output. WOFF2 is written without Brotli compression (valid, but not the smallest—use WOFF for smaller files).') + '</div></div>' +
      '<div class="card"><h3>' + T('بسته‌ها', 'Packages') + '</h3><div class="row"><button class="b" data-x="web">🌐 ' + T('بستهٔ وب‌فونت (ZIP: TTF+WOFF+WOFF2+EOT+SVG+CSS+دمو)', 'Web-font package (ZIP)') + '</button><button class="b" data-x="android">🤖 ' + T('بستهٔ اندروید (res/font)', 'Android package (res/font)') + '</button></div></div>' +
      '<div class="card"><h3>' + T('پروژه', 'Project') + '</h3><div class="row"><button class="b" data-x="proj">💾 ' + T('ذخیرهٔ پروژه (.dfproj) روی گوشی', 'Save project (.dfproj)') + '</button><button class="b" data-x="projws">📁 ' + T('ذخیره در فضای کاری استودیو', 'Save in studio workspace') + '</button></div><div class="muted">' + T('پروژه همهٔ ویرایش‌ها و جدول‌های جانبی را نگه می‌دارد و بعداً دوباره باز می‌شود. برای ویرایش، فایل پروژه لازم نیست؛ خود فونت (TTF/OTF/WOFF) هم باز می‌شود.', 'The project keeps all edits; you can also edit a plain font file without any project.') + '</div></div>' +
      '<div class="card"><h3>' + T('اپلیکیشن', 'App') + '</h3><div class="row"><button class="b p" data-x="install">📲 ' + T('افزودن این فونت به فونت‌های اپلیکیشن', 'Add this font to the app') + '</button><button class="b" data-x="share">↗ ' + T('اشتراک‌گذاری TTF', 'Share TTF') + '</button></div></div>';
    var f = S.font; if (!f.glyphs.length) return;
    $('xNote').textContent = f.glyphs.length + ' ' + T('گلیف', 'glyphs') + (S.font.lastDropped && S.font.lastDropped.length ? ' · ⚠ ' + T('جدول‌های ترتیب‌وابسته حذف می‌شوند: ', 'dropped: ') + S.font.lastDropped.join(', ') : '');
    m.querySelectorAll('button[data-x]').forEach(function (b) { b.onclick = function () { doExport(b.dataset.x); }; });
  }
  async function doExport(kind) {
    var name = ($('xName') && $('xName').value.trim()) || FS.io.slug(fam());
    try {
      await busy(T('در حال ساخت…', 'Building…'));
      if (kind === 'proj' || kind === 'projws') {
        flushLayout(); var pj = FS.io.saveProject(S.font, S.meta);
        if (kind === 'projws') { await Host.ws.put('projects/' + name + '.dfproj', pj); S.dirty = false; Host.setUnsaved(false); $('busy').hidden = true; toast(T('ذخیره شد', 'Saved')); return; }
        $('busy').hidden = true; var r0 = await Host.saveFile(pj, name + '.dfproj', 'application/octet-stream'); if (r0.saved) { S.dirty = false; Host.setUnsaved(false); toast(T('ذخیره شد', 'Saved')); } return;
      }
      var ttf = buildTtf(), data, ext, mime = 'application/octet-stream';
      if (kind === 'ttf') { data = ttf; ext = 'ttf'; mime = 'font/ttf'; }
      else if (kind === 'woff') { data = await FS.io.toWoff(ttf); ext = 'woff'; mime = 'font/woff'; }
      else if (kind === 'woff2') { data = FS.io.toWoff2(ttf); ext = 'woff2'; mime = 'font/woff2'; }
      else if (kind === 'eot') { data = FS.io.toEot(ttf, S.font); ext = 'eot'; }
      else if (kind === 'svg') { data = FS.io.toSvgFont(S.font); ext = 'svg'; mime = 'image/svg+xml'; }
      else if (kind === 'web') { data = await FS.io.buildWebPackage(S.font, ttf); ext = 'zip'; name += '-webfont'; mime = 'application/zip'; }
      else if (kind === 'android') { data = FS.io.buildAndroidPackage(S.font, ttf); ext = 'zip'; name += '-android'; mime = 'application/zip'; }
      else if (kind === 'share') { $('busy').hidden = true; await Host.shareFile(ttf, name + '.ttf', 'font/ttf'); return; }
      else if (kind === 'install') {
        $('busy').hidden = true; if (!(await ask(T('این فونت به فونت‌های اپلیکیشن اضافه می‌شود (و ممکن است به‌عنوان فونت انتخاب‌شدهٔ استودیوها تنظیم شود). ادامه؟', 'Add this font to the app fonts (it may also become the selected font). Continue?')))) return;
        await busy(T('در حال افزودن…', 'Installing…')); var r = await Host.appFonts.install(ttf, name + '.ttf'); $('busy').hidden = true; toast(r && r.ok ? T('به اپلیکیشن اضافه شد ✔', 'Added to the app ✔') : T('افزودن ناموفق بود', 'Install failed')); return;
      }
      $('busy').hidden = true; var res = await Host.saveFile(data, name + '.' + ext, mime); if (res.saved) toast(T('ذخیره شد ✔', 'Saved ✔'));
      if (S.font.lastDropped && S.font.lastDropped.length) toast(T('هشدار: جدول‌های حذف‌شده: ', 'Warning, dropped: ') + S.font.lastDropped.join(', '));
    } catch (e) { fail(e); }
  }

  /* ---------- راه‌اندازی ---------- */
  window.addEventListener('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key === 'z') { e.preventDefault(); undo(); } else if ((e.ctrlKey || e.metaKey) && e.key === 'y') { e.preventDefault(); redo(); } else if (S.ed && (e.key === 'Delete' || e.key === 'Backspace') && document.activeElement === document.body) S.ed.removeKeys(S.ed.selKeys()); });
  window.StudioApp = { S: S, T: T, $: $, toast: toast, busy: busy, modal: modal, closeModal: closeModal, ask: ask, fail: fail, esc: esc, hex: hex, go: go, pushHistory: pushHistory, changed: changed, Host: Host, fam: fam, fixDirections: fixDirections, flushLayout: flushLayout, fa: fa };
  window.StudioDebug = { S: S, openBytes: openBytes, go: go, FS: FS };
  go('start');
  var L = Host.info.launch || {};
  if (L.action === 'new') newFontDialog(); else if ((L.action === 'editAppDefault' || L.action === 'editAppFont') && L.fontName) openAppFont(L.fontName); else if (L.action === 'openFile') pickAndOpen();
})();
