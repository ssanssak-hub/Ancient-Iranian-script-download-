/* Font Studio Ultra 3 (1.8.0) — سه ابزار پیشرفتهٔ هندسی
   ۱) تولید ایتالیک/اُبلیق دسته‌ای با تبدیل shear درجه‌یک و حفظ خط پایه
   ۲) مرکزچین‌سازی اپتیکالِ جوهر داخل advance بدون تغییر Unicode/نام
   ۳) درون‌یابی هندسی بین دو master گلیف با توپولوژی یکسان
   همهٔ تغییرات قابل Undo هستند و به پل اپ نیاز ندارند. */
(function (root) {
'use strict';
var FS = root.FS = root.FS || {};
var A = root.StudioApp;
if (!A) return;
var S = A.S;

function T(a,b){ return A.T ? A.T(a,b) : a; }
function esc(s){ return A.esc ? A.esc(s) : String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
function num(v,d){ var x=Number(v); return Number.isFinite(x)?x:d; }
function scopeIdx(f, mode, rg, gi){
  var out=[], n=f.glyphs.length, a, b;
  if(mode==='cur') return [gi];
  if(mode==='range'){
    a=Math.max(0,Math.min(n-1,Math.floor(num((rg||'').split('-')[0],0))));
    b=Math.max(a,Math.min(n-1,Math.floor(num((rg||'').split('-')[1],n-1))));
    for(var i=a;i<=b;i++) out.push(i);
    return out;
  }
  for(var j=0;j<n;j++) out.push(j);
  return out;
}
function bbox(g){ return FS.sfnt.bboxOf(g.contours); }
function touch(gi){
  S.ttf=null; S.dirty=true;
  try{ A.Host && A.Host.setUnsaved && A.Host.setUnsaved(true); }catch(_){}
  try{ if(S.ed){ S.ed.sel={}; S.ed.draw(); } }catch(_){}
  if(A.changed && S.font && S.font.glyphs.length) A.changed(Math.max(0,Math.min(gi|0,S.font.glyphs.length-1)),true);
}
function runBatch(idx, fn, msg){
  return (async function(){
    var items=[], info=[], errors=[], t0=Date.now();
    for(var k=0;k<idx.length;k++){
      var gi=idx[k], g=S.font.glyphs[gi], before=FS.editor.snap(g), r=null;
      try{
        r=fn(g,gi);
        if(r) info.push({gi:gi,r:r});
        var after=FS.editor.snap(g);
        if(JSON.stringify(before)!==JSON.stringify(after)) items.push({gi:gi,before:before,after:after});
      }catch(e){
        try{ FS.editor.restore(g,before); }catch(_){
          /* restore is part of the editor API; if it is unavailable, stop rather than leave a partial glyph */
          throw e;
        }
        errors.push({gi:gi,error:e&&e.message?e.message:String(e)});
      }
      if(Date.now()-t0>400 && k%8===7){ await A.busy(msg+' '+(k+1)+'/'+idx.length); t0=Date.now(); }
    }
    await A.busy('');
    if(items.length){ A.pushHistory(items); touch(items[0].gi); }
    return {changed:items.length,info:info,errors:errors};
  })();
}
function guard(fn){ return function(){ var self=this,args=arguments; Promise.resolve().then(function(){return fn.apply(self,args);}).catch(function(e){try{A.busy('');}catch(_){} A.fail(e);});}; }
function card(title, desc, body, out){
  return '<section class="card ul-card"><h3>'+title+'</h3><div class="muted">'+desc+'</div>'+body+(out?'<div class="ul-out" id="'+out+'"></div>':'')+'</section>';
}
function field(id,label,value,attrs){
  return '<label class="f">'+esc(label)+'<input id="'+id+'" type="number" dir="ltr" value="'+esc(value)+'" '+(attrs||'')+'></label>';
}
function chk(id,label,on){
  return '<label class="chk"><input id="'+id+'" type="checkbox" '+(on?'checked':'')+'>'+esc(label)+'</label>';
}
function scopeHTML(p, def){
  return '<div class="row"><label class="f">'+T('محدوده','Scope')+'<select id="'+p+'Sc"><option value="all"'+(def==='all'?' selected':'')+'>'+T('همهٔ گلیف‌ها','All glyphs')+'</option><option value="cur"'+(def==='cur'?' selected':'')+'>'+T('گلیف فعلی','Current glyph')+'</option><option value="range">'+T('بازه','Range')+'</option></select></label><label class="f">'+T('بازه','Range')+'<input id="'+p+'Rg" dir="ltr" placeholder="0-100" style="width:110px"></label></div>';
}
function openLab(){
  var f=S.font;
  if(!f){ A.toast(T('ابتدا یک فونت باز کنید','Open a font first')); return; }
  var m=document.createElement('div'); m.className='fs-lab ul-lab';
  m.innerHTML='<div class="fs-lab-head"><div><h2>🧬 Font Studio Ultra 3</h2><div class="muted">'+esc(A.fam())+' · UPM '+f.upm+' · '+f.glyphs.length+' glyphs</div></div><button class="b" id="u3Close">✕</button></div><div id="u3Body"></div>';
  document.body.appendChild(m);
  var body=m.querySelector('#u3Body');
  body.innerHTML=
    card('✒️ '+T('تولید ایتالیک / اُبلیق هوشمند','Batch Italic / Oblique Generator'),
      T('بر پایهٔ shear هندسی انجام می‌شود؛ خط پایه ثابت می‌ماند و advance به‌صورت انتخابی دست‌نخورده یا متناسب با برون‌زدگی تنظیم می‌شود. برای حروف فارسی و لاتین قابل استفاده است.','Applies a geometric shear while keeping the baseline fixed. Advance can be preserved or expanded to contain the transformed ink. Works for Latin and Persian glyphs.'),
      scopeHTML('i','all')+
      '<div class="row">'+field('iAng',T('زاویهٔ اُبلیق (درجه)','Oblique angle (deg)'),-12,'step="0.5" min="-45" max="45"')+
      field('iBase',T('خط پایه','Baseline'),0,'step="1"')+'</div>'+
      '<div class="row">'+chk('iAdv',T('افزایش advance برای جلوگیری از برش','Expand advance to avoid clipping'),true)+
      chk('iKeep',T('حفظ سمت چپ (جابجایی کل طرح)','Preserve left sidebearing (translate outline)'),false)+'</div>'+
      '<div class="row"><button class="b p" id="iGo">'+T('اعمال اُبلیق','Apply oblique')+'</button></div>','iOut')+
    card('🎯 '+T('مرکزچین‌سازی اپتیکال','Optical Ink Centering'),
      T('جوهر هر گلیف را در محدودهٔ advance به‌صورت هندسی مرکز می‌کند؛ Unicode، نام و advance تغییر نمی‌کنند. گلیف‌های بدون طرح و markهای advance=0 رد می‌شوند.','Centers each glyph’s ink inside its advance width without changing Unicode, name, or advance. Empty glyphs and zero-advance marks are skipped.'),
      scopeHTML('c','all')+
      '<div class="row">'+field('cMin',T('حداقل عرض advance','Minimum advance'),20,'min="0" step="1"')+
      field('cTol',T('حداقل جابه‌جایی','Minimum shift'),1,'min="0" step="0.5"')+'</div>'+
      '<div class="row"><button class="b p" id="cGo">'+T('مرکزچین‌سازی','Center ink')+'</button></div>','cOut')+
    card('🧩 '+T('درون‌یابی دو master گلیف','Two-Master Glyph Interpolation'),
      T('دو گلیف با توپولوژی یکسان را به‌عنوان master انتخاب کنید و فرم میانی را روی محدودهٔ هدف اعمال کنید. تعداد کانتور و تعداد نقاط هر کانتور باید دقیقاً برابر باشد؛ در غیر این صورت آن گلیف امنانه رد می‌شود.','Choose two glyphs with identical topology and apply an interpolated outline to the target scope. Contour and point counts must match exactly; incompatible glyphs are safely skipped.'),
      '<div class="row">'+
      '<label class="f">'+T('Master A','Master A')+'<select id="pA" dir="ltr"></select></label>'+
      '<label class="f">'+T('Master B','Master B')+'<select id="pB" dir="ltr"></select></label>'+
      '</div>'+
      '<div class="row">'+field('pT',T('درصد از A → B','Percent A → B'),50,'min="0" max="100" step="1"')+
      '<label class="f">'+T('هدف','Target')+'<select id="pSc"><option value="cur">'+T('گلیف فعلی','Current glyph')+'</option><option value="all">'+T('همه','All')+'</option><option value="range">'+T('بازه','Range')+'</option></select></label>'+
      '<label class="f">'+T('بازه','Range')+'<input id="pRg" dir="ltr" placeholder="0-100" style="width:110px"></label></div>'+
      '<div class="row">'+chk('pAdv',T('درون‌یابی advance هم انجام شود','Interpolate advance too'),true)+
      chk('pOn',T('وضعیت on/off از A حفظ شود','Keep on/off state from A'),true)+'</div>'+
      '<div class="row"><button class="b p" id="pGo">'+T('درون‌یابی و اعمال','Interpolate & apply')+'</button></div>','pOut'
    );

  function say(id,txt){ var q=m.querySelector('#'+id); if(q) q.textContent=txt; if(txt) A.toast(String(txt).split('\\n')[0]); }
  function fillMasters(){
    var a=m.querySelector('#pA'), b=m.querySelector('#pB'), html='';
    for(var i=0;i<f.glyphs.length;i++) html+='<option value="'+i+'">'+i+' · '+esc(f.glyphs[i].name||('#'+i))+'</option>';
    a.innerHTML=html; b.innerHTML=html;
    a.value=String(Math.max(0,Math.min(S.gi,f.glyphs.length-1)));
    b.value=String(Math.min(f.glyphs.length-1,Math.max(0,S.gi+1)));
  }
  fillMasters();
  m.querySelector('#u3Close').onclick=function(){m.remove();};

  m.querySelector('#iGo').onclick=guard(async function(){
    var idx=scopeIdx(f,m.querySelector('#iSc').value,m.querySelector('#iRg').value,S.gi);
    var ang=num(m.querySelector('#iAng').value,-12), base=num(m.querySelector('#iBase').value,0), sh=Math.tan(ang*Math.PI/180), expand=m.querySelector('#iAdv').checked, keep=m.querySelector('#iKeep').checked;
    var res=await runBatch(idx,function(g){
      if(!g.contours || !g.contours.length) return null;
      var oldb=bbox(g), minX=Infinity,maxX=-Infinity;
      if(!oldb) return null;
      g.contours.forEach(function(c){ c.forEach(function(p){ p.x += sh*(p.y-base); minX=Math.min(minX,p.x); maxX=Math.max(maxX,p.x); }); });
      if(keep){ var dx=oldb.x0-minX; g.contours.forEach(function(c){c.forEach(function(p){p.x+=dx;});}); minX+=dx; maxX+=dx; }
      /* The advance is the right boundary of the glyph's origin box. The old
         right-side-bearing formula was wrong when the transformed left edge
         moved, and could still leave the rightmost point beyond advance. */
      if(expand && Number.isFinite(maxX)) g.adv=Math.max(g.adv,Math.ceil(maxX));
      FS.editor.normalizeGlyph(g);
      return {angle:ang};
    },T('تولید اُبلیق…','Generating oblique…'));
    say('iOut',res.changed+' '+T('گلیف اُبلیق شد ✔','glyphs obliqued ✔')+' · '+T('زاویه','angle')+' '+ang+'°'+(res.errors.length?' · '+res.errors.length+' '+T('خطا','errors'):'') );
  });

  m.querySelector('#cGo').onclick=guard(async function(){
    var idx=scopeIdx(f,m.querySelector('#cSc').value,m.querySelector('#cRg').value,S.gi), minAdv=Math.max(0,num(m.querySelector('#cMin').value,20)), tol=Math.max(0,num(m.querySelector('#cTol').value,1));
    var skipped=0, moved=0;
    var res=await runBatch(idx,function(g){
      if(!g.contours || !g.contours.length || g.adv<minAdv){skipped++;return null;}
      var b=bbox(g); if(!b) return null;
      var target=(g.adv-(b.x1-b.x0))/2, dx=Math.round(target-b.x0);
      if(Math.abs(dx)<tol) return null;
      g.contours.forEach(function(c){c.forEach(function(p){p.x+=dx;});});
      moved+=dx;
      FS.editor.normalizeGlyph(g);
      return {dx:dx};
    },T('مرکزچین‌سازی اپتیکال…','Optically centering…'));
    say('cOut',res.changed+' '+T('گلیف مرکزچین شد ✔','glyphs centered ✔')+' · '+skipped+' '+T('گلیف رد شد','skipped glyphs')+(res.errors.length?' · '+res.errors.length+' '+T('خطا','errors'):''));
  });

  m.querySelector('#pGo').onclick=guard(async function(){
    var ai=Number(m.querySelector('#pA').value), bi=Number(m.querySelector('#pB').value), t=Math.max(0,Math.min(1,num(m.querySelector('#pT').value,50)/100));
    if(ai===bi){say('pOut',T('Master A و B باید متفاوت باشند','Master A and B must differ'));return;}
    var ga=f.glyphs[ai], gb=f.glyphs[bi];
    function topo(a,b){
      if(a.contours.length!==b.contours.length)return false;
      for(var i=0;i<a.contours.length;i++) if(a.contours[i].length!==b.contours[i].length)return false;
      return true;
    }
    var mode=m.querySelector('#pSc').value, idx=mode==='cur'?[S.gi]:mode==='all'?scopeIdx(f,'all','',S.gi):scopeIdx(f,'range',m.querySelector('#pRg').value,S.gi);
    var skipped=0;
    var res=await runBatch(idx,function(g,gi){
      if(gi===ai||gi===bi||!topo(ga,g)||!topo(gb,g)){skipped++;return null;}
      for(var ci=0;ci<g.contours.length;ci++){
        for(var pi=0;pi<g.contours[ci].length;pi++){
          var pa=ga.contours[ci][pi], pb=gb.contours[ci][pi], p=g.contours[ci][pi];
          p.x=pa.x+(pb.x-pa.x)*t; p.y=pa.y+(pb.y-pa.y)*t;
          if(!m.querySelector('#pOn').checked) p.on=(t<0.5?!!pa.on:!!pb.on);
        }
      }
      if(m.querySelector('#pAdv').checked) g.adv=ga.adv+(gb.adv-ga.adv)*t;
      FS.editor.normalizeGlyph(g);
      return {t:t};
    },T('درون‌یابی گلیف‌ها…','Interpolating glyphs…'));
    say('pOut',res.changed+' '+T('گلیف درون‌یابی شد ✔','glyphs interpolated ✔')+' · '+skipped+' '+T('گلیف ناسازگار/منبع رد شد','incompatible/source glyphs skipped')+' · '+Math.round(t*100)+'%'+(res.errors.length?' · '+res.errors.length+' '+T('خطا','errors'):''));
  });
}
function panel(mm){
  var d=document.createElement('details');
  d.innerHTML='<summary>🧬 '+T('Font Studio Ultra 3 — ایتالیک، مرکزچین اپتیکال و درون‌یابی','Font Studio Ultra 3 — Italic, Optical Centering & Interpolation')+'</summary><div class="muted">'+T('سه ابزار هندسی جدید؛ بدون نیاز به تغییر اپ و بدون کتابخانهٔ خارجی.','Three new geometric tools; no app update and no external libraries.')+'</div><button class="b p" id="u3Open">🧬 '+T('باز کردن Ultra 3','Open Ultra 3')+'</button>';
  mm.appendChild(d); d.querySelector('#u3Open').onclick=openLab;
}
var old=A.afterTools; A.afterTools=function(mm){if(old)old(mm);panel(mm);};
root.StudioUltra3={open:openLab,oblique:function(g,a,b){var s=Math.tan(a*Math.PI/180);g.contours.forEach(function(c){c.forEach(function(p){p.x+=s*(p.y-b);});});},centerInk:function(g){var b=bbox(g);if(!b||!g.adv)return 0;var dx=(g.adv-(b.x1-b.x0))/2-b.x0;g.contours.forEach(function(c){c.forEach(function(p){p.x+=dx;});});return dx;}};
})(window);
