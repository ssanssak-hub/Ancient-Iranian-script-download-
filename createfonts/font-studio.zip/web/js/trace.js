/* ردیابی تصویر ← طرح گلیف (منحنی درجه‌دو TrueType) */
(function (root) {
  'use strict';
  var FS = root.FS = root.FS || {};

  /* ---------- دودویی‌سازی ---------- */
  function gray(img) {
    var w = img.width, h = img.height, d = img.data, g = new Uint8Array(w * h);
    for (var i = 0; i < w * h; i++) { var a = d[i * 4 + 3] / 255; g[i] = Math.round((0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2]) * a + 255 * (1 - a)); }
    return g;
  }
  function otsu(g) {
    var hist = new Array(256).fill(0); for (var i = 0; i < g.length; i++) hist[g[i]]++;
    var total = g.length, sum = 0; for (var t = 0; t < 256; t++) sum += t * hist[t];
    var sB = 0, wB = 0, best = 0, thr = 128;
    for (t = 0; t < 256; t++) { wB += hist[t]; if (!wB) continue; var wF = total - wB; if (!wF) break; sB += t * hist[t]; var mB = sB / wB, mF = (sum - sB) / wF, v = wB * wF * (mB - mF) * (mB - mF); if (v > best) { best = v; thr = t; } }
    return thr;
  }
  /* خروجی: {bin (با حاشیهٔ ۱ پیکسلی), w, h, thr}. ink=1 */
  function toBinary(img, o) {
    o = o || {}; var g = gray(img), thr = o.auto === false && o.threshold != null ? o.threshold : otsu(g), w = img.width, h = img.height, W = w + 2, H = h + 2, bin = new Uint8Array(W * H);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) { var dark = g[y * w + x] <= thr; bin[(y + 1) * W + x + 1] = (o.invert ? !dark : dark) ? 1 : 0; }
    return { bin: bin, w: W, h: H, thr: thr };
  }
  function crop(b, x0, y0, x1, y1) {
    var w = x1 - x0, h = y1 - y0, W = w + 2, H = h + 2, out = new Uint8Array(W * H);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) { var sx = x0 + x + 1, sy = y0 + y + 1; if (sx >= 1 && sx < b.w - 1 && sy >= 1 && sy < b.h - 1) out[(y + 1) * W + x + 1] = b.bin[sy * b.w + sx]; }
    return { bin: out, w: W, h: H };
  }

  /* ---------- پاک‌سازی لکه‌ها ---------- */
  function despeckle(b, minArea) {
    if (!minArea) return;
    var w = b.w, h = b.h, bin = b.bin, seen = new Uint8Array(w * h), stack = [];
    function flood(sx, sy, val, conn8) {
      var cells = [], touchesBorder = false; stack.length = 0; stack.push(sy * w + sx); seen[sy * w + sx] = 1;
      while (stack.length) {
        var p = stack.pop(), x = p % w, y = (p / w) | 0; cells.push(p); if (x === 0 || y === 0 || x === w - 1 || y === h - 1) touchesBorder = true;
        for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue; if (!conn8 && dx && dy) continue; var nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
          var q = ny * w + nx; if (!seen[q] && bin[q] === val) { seen[q] = 1; stack.push(q); }
        }
      }
      return { cells: cells, border: touchesBorder };
    }
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) { var p = y * w + x; if (seen[p]) continue; var v = bin[p]; var r = flood(x, y, v, v === 1); if (r.cells.length < minArea && (v === 1 || !r.border)) r.cells.forEach(function (c) { bin[c] = v ? 0 : 1; }); }
  }

  /* ---------- دنبال‌کردن مرزها ---------- */
  function loopsOf(b) {
    var w = b.w, h = b.h, bin = b.bin, V = w + 1, edges = [], byStart = {};
    function add(x0, y0, x1, y1) { var e = { x0: x0, y0: y0, x1: x1, y1: y1, used: false }; edges.push(e); var k = y0 * V + x0; (byStart[k] = byStart[k] || []).push(e); }
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
      if (!bin[y * w + x]) continue;
      if (y === 0 || !bin[(y - 1) * w + x]) add(x, y, x + 1, y);
      if (x === w - 1 || !bin[y * w + x + 1]) add(x + 1, y, x + 1, y + 1);
      if (y === h - 1 || !bin[(y + 1) * w + x]) add(x + 1, y + 1, x, y + 1);
      if (x === 0 || !bin[y * w + x - 1]) add(x, y + 1, x, y);
    }
    var loops = [];
    edges.forEach(function (e0) {
      if (e0.used) return; var pts = [], e = e0, guard = 0;
      while (e && !e.used && guard++ < 4000000) {
        e.used = true; pts.push({ x: e.x0, y: e.y0 });
        var cands = (byStart[e.y1 * V + e.x1] || []).filter(function (c) { return !c.used; });
        if (!cands.length) break;
        if (cands.length > 1) { var dx = e.x1 - e.x0, dy = e.y1 - e.y0, rx = -dy, ry = dx; var right = cands.filter(function (c) { return (c.x1 - c.x0) === rx && (c.y1 - c.y0) === ry; }); e = right.length ? right[0] : cands[0]; }
        else e = cands[0];
      }
      if (pts.length >= 4) loops.push(pts);
    });
    return loops;
  }

  /* ---------- هندسهٔ کمکی ---------- */
  function smooth(pts, r) {
    if (r <= 0) return pts.map(function (p) { return { x: p.x, y: p.y }; });
    var n = pts.length, out = [];
    for (var i = 0; i < n; i++) { var sx = 0, sy = 0; for (var k = -r; k <= r; k++) { var q = pts[(i + k + n * 4) % n]; sx += q.x; sy += q.y; } out.push({ x: sx / (2 * r + 1), y: sy / (2 * r + 1) }); }
    return out;
  }
  function distSeg(p, a, b) { var dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy; if (!l2) return Math.hypot(p.x - a.x, p.y - a.y); var t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2)); return Math.hypot(p.x - a.x - t * dx, p.y - a.y - t * dy); }
  function dp(pts, eps) {
    if (pts.length < 3) return pts.slice();
    var keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1; var stack = [[0, pts.length - 1]];
    while (stack.length) { var s = stack.pop(), a = s[0], b = s[1], md = 0, mi = -1; for (var i = a + 1; i < b; i++) { var d = distSeg(pts[i], pts[a], pts[b]); if (d > md) { md = d; mi = i; } } if (md > eps && mi > 0) { keep[mi] = 1; stack.push([a, mi], [mi, b]); } }
    return pts.filter(function (_, i) { return keep[i]; });
  }
  function turn(a, b, c) { var v1x = b.x - a.x, v1y = b.y - a.y, v2x = c.x - b.x, v2y = c.y - b.y, n = Math.hypot(v1x, v1y) * Math.hypot(v2x, v2y); if (!n) return 0; return Math.acos(Math.max(-1, Math.min(1, (v1x * v2x + v1y * v2y) / n))) * 180 / Math.PI; }

  /* یک حلقه (نقاط مرزی واحد) ← contour با نقاط on/off در مختصات پیکسل */
  function fitLoop(raw, o) {
    var n = raw.length, sm = smooth(raw, o.smooth), k = Math.max(3, Math.round(o.cornerSpan)), ang = new Array(n), corners = [];
    for (var i = 0; i < n; i++) ang[i] = turn(sm[(i - k + n * 2) % n], sm[i], sm[(i + k) % n]);
    for (i = 0; i < n; i++) { if (ang[i] < o.cornerAngle) continue; var ok = true; for (var j = -k; j <= k; j++) { if (j && ang[(i + j + n * 2) % n] > ang[i] + 1e-9) { ok = false; break; } if (j && ang[(i + j + n * 2) % n] === ang[i] && j < 0) { ok = false; break; } } if (ok) corners.push(i); }
    var out = [];
    function run(a, b) { /* نقاط smoothed از a تا b (شامل) به‌صورت چرخشی */
      var seg = [], idx = a; for (;;) { seg.push(sm[idx]); if (idx === b) break; idx = (idx + 1) % n; if (seg.length > n + 1) break; } return seg;
    }
    if (!corners.length) {
      var closed = sm.concat([sm[0]]), simp = dp(closed, o.tolerance); simp.pop();
      if (simp.length < 3) { var step = Math.max(1, Math.floor(n / 8)); simp = []; for (var q = 0; q < n; q += step) simp.push(sm[q]); }
      simp.forEach(function (p) { out.push({ x: p.x, y: p.y, on: false }); });
      return out;
    }
    for (var c = 0; c < corners.length; c++) {
      var a = corners[c], b = corners[(c + 1) % corners.length], seg2 = dp(run(a, b), o.tolerance);
      out.push({ x: raw[a].x, y: raw[a].y, on: true });
      for (var m = 1; m < seg2.length - 1; m++) out.push({ x: seg2[m].x, y: seg2[m].y, on: false });
    }
    return out;
  }

  var DEF = { threshold: 128, auto: true, invert: false, minArea: 6, smooth: 2, tolerance: 1.1, cornerAngle: 55, cornerSpan: 5 };
  /* b: {bin,w,h}. خروجی: contourها با مختصات پیکسل (y رو به پایین، بدون حاشیه) */
  function traceBinary(b, opt) {
    var o = Object.assign({}, DEF, opt || {}); despeckle(b, o.minArea);
    var loops = loopsOf(b), res = [];
    loops.forEach(function (l) { if (l.length < 8) return; var c = fitLoop(l, o); c.forEach(function (p) { p.x -= 1; p.y -= 1; }); res.push(c); });
    return res;
  }

  /* نگاشت پیکسل ← واحد فونت. opts: {unitsPerPx, baselinePx (y پیکسل کف)، xPx0 (مبدأ x)، lsb} */
  function toFont(contours, m) {
    return contours.map(function (c) { return c.map(function (p) { return { x: Math.round((p.x - m.x0) * m.k + m.lsb), y: Math.round((m.baseY - p.y) * m.k), on: p.on }; }); });
  }
  function bbox(contours) { var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; contours.forEach(function (c) { c.forEach(function (p) { x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y); }); }); return x1 < x0 ? null : { x0: x0, y0: y0, x1: x1, y1: y1 }; }

  /* حالت تک‌گلیف: ارتفاع کل شکل = height واحد و کف شکل روی yBottom */
  function traceFit(b, opt, height, yBottom, lsb) {
    var cs = traceBinary(b, opt), bb = bbox(cs); if (!bb) return { contours: [], width: 0 };
    var k = height / Math.max(1, bb.y1 - bb.y0), fonts = toFont(cs, { x0: bb.x0, k: k, lsb: lsb, baseY: bb.y1 });
    fonts.forEach(function (c) { c.forEach(function (p) { p.y += yBottom; }); });
    return { contours: fonts, width: Math.round((bb.x1 - bb.x0) * k) };
  }
  /* حالت برگهٔ حروف: شبکهٔ rows×cols؛ cellHeightUnits = ارتفاع سلول بر حسب واحد فونت؛ baselineFrac = فاصلهٔ خط پایه تا لبهٔ پایین سلول (کسری از ارتفاع سلول) */
  function traceSheet(b, opt, rows, cols, chars, cellHeightUnits, baselineFrac, lsb) {
    var cw = (b.w - 2) / cols, ch = (b.h - 2) / rows, k = cellHeightUnits / ch, res = [], i = 0, list = Array.from(chars);
    for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++, i++) {
      var ch0 = list[i]; if (!ch0 || /\s/.test(ch0)) continue;
      var sub = crop(b, Math.round(c * cw), Math.round(r * ch), Math.round((c + 1) * cw), Math.round((r + 1) * ch)), cs = traceBinary(sub, opt), bb = bbox(cs); if (!bb) { res.push({ ch: ch0, contours: [], adv: Math.round(cw * k * 0.5) }); continue; }
      var baseY = Math.round((r + 1) * ch) - Math.round(r * ch) - baselineFrac * ch, f = toFont(cs, { x0: bb.x0, k: k, lsb: lsb, baseY: baseY });
      res.push({ ch: ch0, contours: f, adv: Math.round((bb.x1 - bb.x0) * k + 2 * lsb) });
    }
    return res;
  }
  FS.trace = { toBinary: toBinary, crop: crop, traceBinary: traceBinary, traceFit: traceFit, traceSheet: traceSheet, DEF: DEF, otsu: otsu };
  if (typeof module !== 'undefined') module.exports = FS;
})(typeof window !== 'undefined' ? window : globalThis);
