/* موتور جدول‌های چیدمان OpenType (GSUB / GPOS)
   روش: جدول اصلی دست‌نخورده می‌ماند؛ ویژگی‌ها/اسکریپت‌ها از نو نوشته می‌شوند، lookupهای ویرایش‌نشده همان‌جا می‌مانند
   و lookupهای تازه/ویرایش‌شده با «لفافِ Extension» به انتهای جدول اضافه می‌شوند (ایمن برای فونت‌های بزرگ). */
(function (root) {
  'use strict';
  var FS = root.FS = root.FS || {};

  /* ---------- نویسندهٔ بایت ---------- */
  function BW() { this.b = new Uint8Array(256); this.n = 0; }
  BW.prototype.ens = function (k) { if (this.n + k > this.b.length) { var nb = new Uint8Array(Math.max(this.b.length * 2, this.n + k)); nb.set(this.b.subarray(0, this.n)); this.b = nb; } };
  BW.prototype.u16 = function (v) { if (v < 0 || v > 65535) throw new Error('OVF16'); this.ens(2); this.b[this.n++] = v >> 8; this.b[this.n++] = v & 255; };
  BW.prototype.i16 = function (v) { v = Math.max(-32768, Math.min(32767, Math.round(v))); this.u16(v & 0xFFFF); };
  BW.prototype.u32 = function (v) { this.ens(4); this.b[this.n++] = (v >>> 24) & 255; this.b[this.n++] = (v >>> 16) & 255; this.b[this.n++] = (v >>> 8) & 255; this.b[this.n++] = v & 255; };
  BW.prototype.tag = function (t) { this.ens(4); for (var i = 0; i < 4; i++) this.b[this.n++] = (t.charCodeAt(i) || 32) & 255; };
  BW.prototype.bytes = function (u8) { this.ens(u8.length); this.b.set(u8, this.n); this.n += u8.length; };
  BW.prototype.out = function () { return this.b.slice(0, this.n); };

  /* ---------- Coverage / ClassDef ---------- */
  function readCoverage(dv, o) {
    var f = dv.getUint16(o), res = [];
    if (f === 1) { var n = dv.getUint16(o + 2); for (var i = 0; i < n; i++) res.push(dv.getUint16(o + 4 + i * 2)); }
    else if (f === 2) { var rc = dv.getUint16(o + 2); for (var r = 0; r < rc; r++) { var s = dv.getUint16(o + 4 + r * 6), e = dv.getUint16(o + 6 + r * 6); for (var g = s; g <= e && res.length < 70000; g++) res.push(g); } }
    return res;
  }
  function covMap(dv, o) { var m = {}; readCoverage(dv, o).forEach(function (g, i) { m[g] = i; }); return m; }
  function readClassDef(dv, o) {
    var f = dv.getUint16(o), m = {};
    if (f === 1) { var s = dv.getUint16(o + 2), n = dv.getUint16(o + 4); for (var i = 0; i < n; i++) { var c = dv.getUint16(o + 6 + i * 2); if (c) m[s + i] = c; } }
    else if (f === 2) { var rc = dv.getUint16(o + 2); for (var r = 0; r < rc; r++) { var a = dv.getUint16(o + 4 + r * 6), b = dv.getUint16(o + 6 + r * 6), c2 = dv.getUint16(o + 8 + r * 6); if (c2) for (var g = a; g <= b; g++) m[g] = c2; } }
    return m;
  }
  function serCoverage(gids) {
    gids = Array.from(new Set(gids)).sort(function (a, b) { return a - b; });
    var ranges = [], i = 0; while (i < gids.length) { var j = i; while (j + 1 < gids.length && gids[j + 1] === gids[j] + 1) j++; ranges.push([gids[i], gids[j], i]); i = j + 1; }
    var w = new BW();
    if (4 + 6 * ranges.length < 4 + 2 * gids.length) { w.u16(2); w.u16(ranges.length); ranges.forEach(function (r) { w.u16(r[0]); w.u16(r[1]); w.u16(r[2]); }); }
    else { w.u16(1); w.u16(gids.length); gids.forEach(function (g) { w.u16(g); }); }
    return w.out();
  }

  /* ---------- خواندن ---------- */
  function parseTable(bytes, kind) {
    var m = { kind: kind, bytes: bytes || null, scripts: [], features: [], lookups: [], lookupListStart: 0, lookupHdrSize: 0, dirty: false };
    if (!bytes || bytes.length < 10) return m;
    var dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), EXT = kind === 'GSUB' ? 7 : 9;
    var sl = dv.getUint16(4), fl = dv.getUint16(6), ll = dv.getUint16(8);
    function langsys(o) { var req = dv.getUint16(o + 2), n = dv.getUint16(o + 4), f = []; for (var i = 0; i < n; i++) f.push(dv.getUint16(o + 6 + i * 2)); return { req: req, feats: f }; }
    if (sl) { var sc = dv.getUint16(sl); for (var i = 0; i < sc; i++) {
      var tag = FS.sfnt.tagStr(dv, sl + 2 + i * 6), so = sl + dv.getUint16(sl + 6 + i * 6), dl = dv.getUint16(so), lc = dv.getUint16(so + 2), s = { tag: tag, def: dl ? langsys(so + dl) : null, langs: [] };
      for (var k = 0; k < lc; k++) s.langs.push({ tag: FS.sfnt.tagStr(dv, so + 4 + k * 6), ls: langsys(so + dv.getUint16(so + 8 + k * 6)) });
      m.scripts.push(s);
    } }
    if (fl) { var fc = dv.getUint16(fl); for (var q = 0; q < fc; q++) { var fo = fl + dv.getUint16(fl + 2 + q * 6 + 4), n2 = dv.getUint16(fo + 2), lk = []; for (var z = 0; z < n2; z++) lk.push(dv.getUint16(fo + 4 + z * 2)); m.features.push({ tag: FS.sfnt.tagStr(dv, fl + 2 + q * 6), lookups: lk, oldIdx: q }); } }
    if (ll) {
      m.lookupListStart = ll; var n = dv.getUint16(ll); m.lookupHdrSize = 2 + 2 * n;
      for (var li = 0; li < n; li++) {
        var lo = ll + dv.getUint16(ll + 2 + li * 2), type = dv.getUint16(lo), flag = dv.getUint16(lo + 2), cnt = dv.getUint16(lo + 4), subs = [], ext = type === EXT, eff = type;
        for (var j = 0; j < cnt; j++) { var so2 = lo + dv.getUint16(lo + 6 + j * 2); if (ext) { eff = dv.getUint16(so2 + 2); subs.push(so2 + dv.getUint32(so2 + 4)); } else subs.push(so2); }
        var markSet = (flag & 0x10) ? dv.getUint16(lo + 6 + cnt * 2) : null;
        var L = { old: true, idx: li, off: lo, type: eff, flag: flag, markSet: markSet, subs: subs, dirty: false, rules: null, editable: false, evals: null };
        try { readRules(dv, kind, L); } catch (e) { L.rules = null; L.editable = false; }
        m.lookups.push(L);
      }
    }
    m._dv = dv; return m;
  }
  function readRules(dv, kind, L) {
    var t = L.type, subs = L.subs;
    if (kind === 'GSUB') {
      if (t === 1) { var map = {}; subs.forEach(function (o) { var f = dv.getUint16(o), cov = readCoverage(dv, o + dv.getUint16(o + 2)); if (f === 1) { var d = dv.getInt16(o + 4); cov.forEach(function (g) { map[g] = (g + d) & 0xFFFF; }); } else if (f === 2) { var n = dv.getUint16(o + 4); cov.forEach(function (g, i) { if (i < n) map[g] = dv.getUint16(o + 6 + i * 2); }); } else throw 0; }); L.rules = { map: map }; L.editable = true; }
      else if (t === 2 || t === 3) { var mm = {}; subs.forEach(function (o) { if (dv.getUint16(o) !== 1) throw 0; var cov = readCoverage(dv, o + dv.getUint16(o + 2)), n = dv.getUint16(o + 4); cov.forEach(function (g, i) { if (i >= n) return; var so = o + dv.getUint16(o + 6 + i * 2), c = dv.getUint16(so), arr = []; for (var k = 0; k < c; k++) arr.push(dv.getUint16(so + 2 + k * 2)); mm[g] = arr; }); }); L.rules = { map: mm }; L.editable = true; }
      else if (t === 4) { var ligs = []; subs.forEach(function (o) { if (dv.getUint16(o) !== 1) throw 0; var cov = readCoverage(dv, o + dv.getUint16(o + 2)), n = dv.getUint16(o + 4); cov.forEach(function (g, i) { if (i >= n) return; var lso = o + dv.getUint16(o + 6 + i * 2), lc = dv.getUint16(lso); for (var k = 0; k < lc; k++) { var lo = lso + dv.getUint16(lso + 2 + k * 2), out = dv.getUint16(lo), cc = dv.getUint16(lo + 2), comps = [g]; for (var c = 0; c < cc - 1; c++) comps.push(dv.getUint16(lo + 4 + c * 2)); ligs.push({ comps: comps, out: out }); } }); }); L.rules = { ligs: ligs }; L.editable = true; }
    } else if (kind === 'GPOS' && t === 2) {
      var evals = [], simple = true, pairs = {};
      subs.forEach(function (o) {
        var f = dv.getUint16(o), cov = covMap(dv, o + dv.getUint16(o + 2)), v1 = dv.getUint16(o + 4), v2 = dv.getUint16(o + 6), s1 = 2 * pc(v1), s2 = 2 * pc(v2), xo = 2 * pc(v1 & 3);
        if (f === 1) {
          var pn = dv.getUint16(o + 8);
          evals.push({ f: 1, cov: cov, get: function (a, b) { var ci = cov[a]; if (ci === undefined || ci >= pn) return null; var ps = o + dv.getUint16(o + 10 + ci * 2), c = dv.getUint16(ps), lo = 0, hi = c - 1, rs = 2 + s1 + s2; while (lo <= hi) { var mid = (lo + hi) >> 1, r = ps + 2 + mid * rs, g2 = dv.getUint16(r); if (g2 === b) return (v1 & 4) ? dv.getInt16(r + 2 + xo) : 0; if (g2 < b) lo = mid + 1; else hi = mid - 1; } return null; } });
          if (!((v1 === 4 || v1 === 0) && v2 === 0)) simple = false;
          else { var pc2 = pn; Object.keys(cov).forEach(function (a) { var ci = cov[a]; if (ci >= pc2) return; var ps = o + dv.getUint16(o + 10 + ci * 2), c = dv.getUint16(ps); for (var k = 0; k < c; k++) { var r = ps + 2 + k * (2 + s1 + s2); pairs[(+a) * 65536 + dv.getUint16(r)] = (v1 & 4) ? dv.getInt16(r + 2) : 0; } }); }
        } else if (f === 2) {
          simple = false; var cd1 = readClassDef(dv, o + dv.getUint16(o + 8)), cd2 = readClassDef(dv, o + dv.getUint16(o + 10)), c1n = dv.getUint16(o + 12), c2n = dv.getUint16(o + 14), rs2 = s1 + s2, base = o + 16;
          evals.push({ f: 2, cov: cov, get: function (a, b) { if (cov[a] === undefined) return null; var c1 = cd1[a] || 0, c2 = cd2[b] || 0; if (c1 >= c1n || c2 >= c2n) return null; var p = base + (c1 * c2n + c2) * rs2; return (v1 & 4) ? dv.getInt16(p + xo) : 0; } });
        } else throw 0;
      });
      L.evals = evals; if (simple && subs.length) { L.rules = { pairs: pairs }; L.editable = true; }
    }
  }
  function pc(v) { var c = 0; while (v) { c += v & 1; v >>= 1; } return c; }

  /* ---------- نوشتن ---------- */
  function chunk(arr, size) { var r = []; for (var i = 0; i < arr.length; i += size) r.push(arr.slice(i, i + size)); return r; }
  function serSingle(map) {
    var ins = Object.keys(map).map(Number).sort(function (a, b) { return a - b; }), res = [];
    chunk(ins, 4000).forEach(function (part) {
      var d0 = (map[part[0]] - part[0]) & 0xFFFF, same = part.every(function (g) { return ((map[g] - g) & 0xFFFF) === d0; }), w = new BW(), cov = serCoverage(part);
      if (same) { w.u16(1); w.u16(6); w.i16(d0 > 32767 ? d0 - 65536 : d0); w.bytes(cov); }
      else { w.u16(2); w.u16(6 + 2 * part.length); w.u16(part.length); part.forEach(function (g) { w.u16(map[g]); }); w.bytes(cov); }
      res.push(w.out());
    });
    return res;
  }
  function serSeq(map) {
    var ins = Object.keys(map).map(Number).sort(function (a, b) { return a - b; }), res = [];
    chunk(ins, 3000).forEach(function (part) {
      var w = new BW(), n = part.length, hdr = 6 + 2 * n, offs = [], pos = hdr; part.forEach(function (g) { offs.push(pos); pos += 2 + 2 * map[g].length; });
      w.u16(1); w.u16(pos); w.u16(n); offs.forEach(function (o) { w.u16(o); });
      part.forEach(function (g) { w.u16(map[g].length); map[g].forEach(function (x) { w.u16(x); }); }); w.bytes(serCoverage(part)); res.push(w.out());
    });
    return res;
  }
  function serLig(ligs) {
    var by = {}; ligs.forEach(function (l) { if (l.comps.length >= 2) (by[l.comps[0]] = by[l.comps[0]] || []).push(l); });
    var firsts = Object.keys(by).map(Number).sort(function (a, b) { return a - b; }), groups = [], cur = [], est = 0;
    firsts.forEach(function (g) { var sz = 4 + by[g].reduce(function (s, l) { return s + 6 + 2 * l.comps.length; }, 0); if (est + sz > 45000 && cur.length) { groups.push(cur); cur = []; est = 0; } cur.push(g); est += sz + 2; });
    if (cur.length) groups.push(cur);
    return groups.map(function (part) {
      var w = new BW(), n = part.length, pos = 6 + 2 * n, setBytes = [], offs = [];
      part.forEach(function (g) {
        var L = by[g].slice().sort(function (a, b) { return b.comps.length - a.comps.length; }), sw = new BW(), lp = 2 + 2 * L.length, lo = [];
        L.forEach(function (l) { lo.push(lp); lp += 4 + 2 * (l.comps.length - 1); });
        sw.u16(L.length); lo.forEach(function (o) { sw.u16(o); });
        L.forEach(function (l) { sw.u16(l.out); sw.u16(l.comps.length); for (var i = 1; i < l.comps.length; i++) sw.u16(l.comps[i]); });
        var b = sw.out(); offs.push(pos); pos += b.length; setBytes.push(b);
      });
      w.u16(1); w.u16(pos); w.u16(n); offs.forEach(function (o) { w.u16(o); }); setBytes.forEach(function (b) { w.bytes(b); }); w.bytes(serCoverage(part)); return w.out();
    });
  }
  function serPairs(pairs) {
    var by = {}; Object.keys(pairs).forEach(function (k) { var a = Math.floor(k / 65536), b = k % 65536; if (pairs[k]) (by[a] = by[a] || []).push([b, pairs[k]]); });
    var firsts = Object.keys(by).map(Number).sort(function (a, b) { return a - b; }), groups = [], cur = [], cnt = 0;
    firsts.forEach(function (a) { if (cnt + by[a].length > 6000 && cur.length) { groups.push(cur); cur = []; cnt = 0; } cur.push(a); cnt += by[a].length; });
    if (cur.length) groups.push(cur);
    return groups.map(function (part) {
      var w = new BW(), n = part.length, pos = 10 + 2 * n, offs = [];
      part.forEach(function (a) { offs.push(pos); pos += 2 + 4 * by[a].length; });
      w.u16(1); w.u16(pos); w.u16(4); w.u16(0); w.u16(n); offs.forEach(function (o) { w.u16(o); });
      part.forEach(function (a) { var L = by[a].sort(function (x, y) { return x[0] - y[0]; }); w.u16(L.length); L.forEach(function (p) { w.u16(p[0]); w.i16(p[1]); }); });
      w.bytes(serCoverage(part)); return w.out();
    });
  }
  function serAnchor(a) { var w=new BW(); w.u16(1); w.i16(a.x||0); w.i16(a.y||0); return w.out(); }
  function serMarkBase(r) {
    var marks=Object.keys(r.marks||{}).map(Number).sort(function(a,b){return a-b;}), bases=Object.keys(r.bases||{}).map(Number).sort(function(a,b){return a-b;}), cc=Math.max(1,r.classCount||1);
    var markCov=serCoverage(marks), baseCov=serCoverage(bases), markArrs=[], baseArrs=[], pos=12+2+marks.length*4+2+bases.length*cc*2;
    marks.forEach(function(g){var a=r.marks[g]||{cls:0,x:0,y:0};markArrs.push({cls:a.cls||0,a:a});});
    bases.forEach(function(g){var arr=[],m=r.bases[g]||{};for(var c=0;c<cc;c++)arr.push(m[c]||null);baseArrs.push(arr);});
    var markPos=pos, markBytes=[]; markBytes.push((function(){var w=new BW();w.u16(marks.length);var p=2+marks.length*4,offs=[];markArrs.forEach(function(x){offs.push(p);p+=4;});markArrs.forEach(function(x,i){w.u16(x.cls);w.u16(offs[i]);});markArrs.forEach(function(x){w.bytes(serAnchor(x.a));});return w.out();})());
    pos += markBytes[0].length; if(pos&1)pos++; var basePos=pos, bw=new BW(); bw.u16(bases.length); var bo=[],bp=2+bases.length*cc*2; baseArrs.forEach(function(arr){bo.push(bp);bp+=2*cc;}); baseArrs.forEach(function(arr,i){for(var c=0;c<cc;c++){var a=arr[c];bw.u16(a?bo[i]+0:0);}});
    var baseRec=[]; baseArrs.forEach(function(arr,i){var rw=new BW();arr.forEach(function(a){if(a)rw.bytes(serAnchor(a));});baseRec.push(rw.out());});
    var baseLen=2+bases.length*cc*2; baseRec.forEach(function(x){baseLen+=x.length;});
    var out=new BW();out.u16(1);out.u16(12);out.u16(12+markBytes[0].length);out.u16(cc);out.u16(0);out.u16(0);
    /* offsets above are relative to subtable; rebuild exact arrays */
    var hdr=12, mc=serCoverage(marks), bc=serCoverage(bases), markOff=hdr, baseOff=hdr+mc.length, maOff=baseOff+bc.length;
    var maw=new BW();maw.u16(marks.length);var mp=2+marks.length*4;markArrs.forEach(function(x){maw.u16(x.cls);maw.u16(mp);mp+=4;});markArrs.forEach(function(x){maw.bytes(serAnchor(x.a));});var mab=maw.out();
    var baw=new BW();baw.u16(bases.length);var baseHeader=2+bases.length*cc*2, cur=baseHeader, offs=[];baseRec=[];baseArrs.forEach(function(arr){offs.push(cur);var rw=new BW();arr.forEach(function(a){if(a)rw.bytes(serAnchor(a));});var rb=rw.out();baseRec.push(rb);cur+=rb.length;});baseArrs.forEach(function(arr,i){for(var c=0;c<cc;c++){var a=arr[c];baw.u16(a?offs[i]+(arr.slice(0,c).filter(Boolean).reduce(function(q,z){return q+4;q;},0)):0);}});baseRec.forEach(function(x){baw.bytes(x);});var bab=baw.out();
    var fin=new BW();fin.u16(1);fin.u16(markOff);fin.u16(baseOff);fin.u16(cc);fin.u16(maOff);fin.u16(maOff+mab.length);fin.bytes(mc);fin.bytes(bc);fin.bytes(mab);fin.bytes(bab);return [fin.out()];
  }
  function serLookupSubs(L, kind) {
    var r = L.rules; if (!r) throw new Error('lookup بدون قاعده');
    if (kind === 'GSUB') { if (L.type === 1) return serSingle(r.map); if (L.type === 2 || L.type === 3) return serSeq(r.map); if (L.type === 4) return serLig(r.ligs); }
    else { if (L.type === 2) return serPairs(r.pairs); if (L.type === 4) return serMarkBase(r); }
    throw new Error('نوع lookup پشتیبانی نمی‌شود');
  }

  function build(m) {
    var kind = m.kind, B = m.bytes, EXT = kind === 'GSUB' ? 7 : 9;
    /* ویژگی‌ها: حذف‌شده‌ها کنار، مرتب بر اساس برچسب، نگاشت اندیس قدیمی→جدید */
    var feats = m.features.filter(function (f) { return !f.deleted; });
    var order = feats.map(function (f, i) { return i; }).sort(function (a, b) { return feats[a].tag < feats[b].tag ? -1 : feats[a].tag > feats[b].tag ? 1 : a - b; });
    var newIndexOf = new Map(); order.forEach(function (oi, ni) { newIndexOf.set(feats[oi], ni); });
    var remap = {}; m.features.forEach(function (f, oi) { if (!f.deleted) remap[oi] = newIndexOf.get(f); });
    var sortedF = order.map(function (i) { return feats[i]; });
    function mapList(l) { return l.map(function (i) { return remap[i]; }).filter(function (x) { return x !== undefined; }).sort(function (a, b) { return a - b; }); }
    /* ScriptList */
    var sw = new BW(), scripts = m.scripts.slice().sort(function (a, b) { return a.tag < b.tag ? -1 : a.tag > b.tag ? 1 : 0; });
    function lsBytes(ls) { var w = new BW(); w.u16(0); w.u16(ls.req === 0xFFFF || remap[ls.req] === undefined ? 0xFFFF : remap[ls.req]); var l = mapList(ls.feats); w.u16(l.length); l.forEach(function (x) { w.u16(x); }); return w.out(); }
    var sBlobs = scripts.map(function (s) {
      var langs = s.langs.slice().sort(function (a, b) { return a.tag < b.tag ? -1 : a.tag > b.tag ? 1 : 0; }), w = new BW(), hdr = 4 + 6 * langs.length, parts = [], pos = hdr, dOff = 0;
      if (s.def) { var d = lsBytes(s.def); dOff = pos; parts.push(d); pos += d.length; }
      var lo = langs.map(function (l) { var b = lsBytes(l.ls), o = pos; parts.push(b); pos += b.length; return o; });
      w.u16(dOff); w.u16(langs.length); langs.forEach(function (l, i) { w.tag(l.tag); w.u16(lo[i]); }); parts.forEach(function (p) { w.bytes(p); }); return w.out();
    });
    var spos = 2 + 6 * scripts.length; sw.u16(scripts.length); scripts.forEach(function (s, i) { sw.tag(s.tag); sw.u16(spos); spos += sBlobs[i].length; }); sBlobs.forEach(function (b) { sw.bytes(b); });
    var scriptList = sw.out();
    /* FeatureList */
    var fw = new BW(), fpos = 2 + 6 * sortedF.length; fw.u16(sortedF.length);
    var fBlobs = sortedF.map(function (f) { var w = new BW(); w.u16(0); w.u16(f.lookups.length); f.lookups.forEach(function (x) { w.u16(x); }); return w.out(); });
    sortedF.forEach(function (f, i) { fw.tag(f.tag); fw.u16(fpos); fpos += fBlobs[i].length; }); fBlobs.forEach(function (b) { fw.bytes(b); });
    var featureList = fw.out();
    /* Lookupها */
    var n = m.lookups.length, oldList = m.lookupListStart, oldHdr = m.lookupHdrSize, stubs = [], realBlobs = [], items = [];
    m.lookups.forEach(function (L) {
      if (L.old && !L.dirty) { items.push({ keep: true, L: L }); return; }
      var subs = serLookupSubs(L, kind); var it = { keep: false, L: L, subs: subs, realIdx: [] };
      subs.forEach(function (s) { it.realIdx.push(realBlobs.length); realBlobs.push(s); });
      var k = subs.length, hasMs = (L.flag & 0x10) && L.markSet !== null && L.markSet !== undefined; it.stubLen = 6 + (hasMs ? 2 : 0) + 10 * k; it.k = k; it.hasMs = !!hasMs; items.push(it);
    });
    var stubsLen = items.reduce(function (s, it) { return s + (it.keep ? 0 : it.stubLen); }, 0);
    var P_script = 10, P_feat = P_script + scriptList.length, P_ll = P_feat + featureList.length, P_stubs = P_ll + 2 + 2 * n, P_old = P_stubs + stubsLen;
    var oldRegion = (B && oldList) ? B.subarray(oldList + oldHdr) : new Uint8Array(0), P_real = P_old + oldRegion.length; if (P_real & 1) P_real++;
    /* مکان واقعی هر subtable تازه */
    var realPos = [], p = P_real; realBlobs.forEach(function (b) { realPos.push(p); p += b.length; if (p & 1) p++; });
    var total = p, llw = new BW();
    llw.u16(n); var sp = P_stubs;
    items.forEach(function (it) {
      if (it.keep) { var o = (P_old - P_ll) + (it.L.off - (oldList + oldHdr)); if (o > 65535) throw new Error('جدول ' + kind + ' این فونت برای ویرایش بیش‌ازحد بزرگ است (جای کافی برای افزودن lookup نیست).'); llw.u16(o); }
      else { llw.u16(sp - P_ll); sp += it.stubLen; }
    });
    /* نوشتن دقیق stubها (محاسبهٔ آفست‌ها به‌صورت صریح) */
    var stubW = new BW(), cursor = P_stubs;
    items.forEach(function (it) {
      if (it.keep) return; var L = it.L, hdr = 6 + 2 * it.k + (it.hasMs ? 2 : 0), base = cursor;
      stubW.u16(EXT); stubW.u16(L.flag); stubW.u16(it.k); for (var j = 0; j < it.k; j++) stubW.u16(hdr + 8 * j); if (it.hasMs) stubW.u16(L.markSet);
      for (var q = 0; q < it.k; q++) { var extAbs = base + hdr + 8 * q; stubW.u16(1); stubW.u16(L.type); stubW.u32(realPos[it.realIdx[q]] - extAbs); }
      cursor += it.stubLen;
    });
    var res = new Uint8Array(total), hdrW = new BW();
    hdrW.u16(1); hdrW.u16(0); hdrW.u16(P_script); hdrW.u16(P_feat); hdrW.u16(P_ll);
    res.set(hdrW.out(), 0); res.set(scriptList, P_script); res.set(featureList, P_feat); res.set(llw.out(), P_ll); res.set(stubW.out(), P_stubs); res.set(oldRegion, P_old);
    realBlobs.forEach(function (b, i) { res.set(b, realPos[i]); });
    return res;
  }

  /* ---------- API ---------- */
  function open(font) {
    if (!font._layout) { font._layout = { GSUB: parseTable(font.extra.GSUB, 'GSUB'), GPOS: parseTable(font.extra.GPOS, 'GPOS') }; font._layout.GPOS.ownIdx = (font.ownKern && font.ownKern.GPOS != null) ? font.ownKern.GPOS : -1; }
    return font._layout;
  }
  function commit(font) {
    var L = font._layout; if (!L) return;
    ['GSUB', 'GPOS'].forEach(function (k) {
      var m = L[k]; if (!m || !m.dirty) return;
      if (!m.features.some(function (f) { return !f.deleted; }) && !m.lookups.some(function (l) { return l.old; })) { delete font.extra[k]; }
      else font.extra[k] = build(m);
      var own = m.ownIdx; L[k] = parseTable(font.extra[k], k); L[k].ownIdx = own === undefined ? -1 : own;
      if (k === 'GPOS') font.ownKern = { GPOS: L[k].ownIdx };
    });
    font.layoutEdited = true;
  }
  function newModel(kind) { return parseTable(null, kind); }
  function addLookup(m, type, rules) { var L = { old: false, idx: m.lookups.length, type: type, flag: 0, markSet: null, subs: [], dirty: true, rules: rules, editable: true, evals: null }; m.lookups.push(L); m.dirty = true; return L.idx; }
  function ensureScript(m, tag) { var s = m.scripts.filter(function (x) { return x.tag === tag; })[0]; if (!s) { s = { tag: tag, def: { req: 0xFFFF, feats: [] }, langs: [] }; m.scripts.push(s); } if (!s.def) s.def = { req: 0xFFFF, feats: [] }; return s; }
  /* افزودن lookup به یک ویژگی. اگر در اسکریپت مقصد از قبل ویژگی همین برچسب هست، lookup داخل همان ویژگی ادغام می‌شود
     (HarfBuzz برای هر برچسب فقط یک ویژگی را می‌خواند). ویژگی مشترک با اسکریپت‌های دیگر کپی می‌شود تا آن‌ها تغییر نکنند. */
  function addFeature(m, tag, lookupIdxs, scriptTags) {
    var add = lookupIdxs.slice(), tags = scriptTags && scriptTags.length ? scriptTags : (m.scripts.length ? m.scripts.map(function (s) { return s.tag; }) : ['DFLT']);
    var clones = {}, fresh = null, first = -1;
    function merged(l) { var r = l.slice(); add.forEach(function (x) { if (r.indexOf(x) < 0) r.push(x); }); return r.sort(function (a, b) { return a - b; }); }
    tags.forEach(function (t) {
      var s = ensureScript(m, t);
      [s.def].concat(s.langs.map(function (l) { return l.ls; })).forEach(function (ls) {
        var pos = -1, fi = -1;
        ls.feats.forEach(function (x, i) { if (pos < 0 && m.features[x] && m.features[x].tag === tag && !m.features[x].deleted) { pos = i; fi = x; } });
        if (pos >= 0) {
          if (clones[fi] === undefined) { m.features.push({ tag: tag, lookups: merged(m.features[fi].lookups), oldIdx: -1 }); clones[fi] = m.features.length - 1; }
          ls.feats[pos] = clones[fi]; if (first < 0) first = clones[fi];
        } else {
          if (fresh === null) { m.features.push({ tag: tag, lookups: add.slice().sort(function (a, b) { return a - b; }), oldIdx: -1 }); fresh = m.features.length - 1; }
          if (ls.feats.indexOf(fresh) < 0) ls.feats.push(fresh); if (first < 0) first = fresh;
        }
      });
    });
    m.dirty = true; return first;
  }
  function removeFeature(m, fi) { m.features[fi].deleted = true; m.scripts.forEach(function (s) { [s.def].concat(s.langs.map(function (l) { return l.ls; })).forEach(function (ls) { if (ls) ls.feats = ls.feats.filter(function (x) { return x !== fi; }); }); }); m.dirty = true; }

  /* ---------- کرنینگ ---------- */
  function kernLookups(m) { var s = {}; m.features.forEach(function (f) { if (f.tag === 'kern' && !f.deleted) f.lookups.forEach(function (i) { s[i] = 1; }); }); return Object.keys(s).map(Number).sort(function (a, b) { return a - b; }).filter(function (i) { return m.lookups[i] && m.lookups[i].type === 2; }); }
  function lookupValue(L, a, b) {
    if (L.dirty || !L.evals) { var v = L.rules && L.rules.pairs ? L.rules.pairs[a * 65536 + b] : undefined; return v === undefined ? null : v; }
    for (var i = 0; i < L.evals.length; i++) { var r = L.evals[i].get(a, b); if (r !== null) return r; } return null;
  }
  function ourLookup(m) { var i = m.ownIdx; if (i === undefined || i < 0) return -1; var L = m.lookups[i]; return (L && L.editable && L.rules && L.rules.pairs && kernLookups(m).indexOf(i) >= 0) ? i : -1; }
  function getKern(m, a, b) {
    var ours = ourLookup(m), base = 0, own = 0;
    kernLookups(m).forEach(function (i) { var v = lookupValue(m.lookups[i], a, b); if (v === null) return; if (i === ours) own = v; else base += v; });
    return { base: base, own: own, total: base + own };
  }
  function setKern(m, a, b, value) {
    var k = getKern(m, a, b), delta = Math.round(value) - k.base, ours = ourLookup(m);
    if (ours < 0) {
      if (!delta) return;
      var idx = addLookup(m, 2, { pairs: {} }); ours = idx; m.ownIdx = idx;
      var kf = m.features.map(function (f, i) { return f.tag === 'kern' && !f.deleted ? i : -1; }).filter(function (i) { return i >= 0; });
      if (kf.length) kf.forEach(function (i) { m.features[i].lookups.push(idx); }); else addFeature(m, 'kern', [idx], null);
    }
    var L = m.lookups[ours];
    if (!L.rules.pairs) L.rules.pairs = {};
    var key = a * 65536 + b; if (delta) L.rules.pairs[key] = delta; else delete L.rules.pairs[key];
    L.dirty = true; m.dirty = true;
  }
  function ownPairs(m) { var o = ourLookup(m); if (o < 0) return []; var p = m.lookups[o].rules.pairs; return Object.keys(p).map(function (k) { return [Math.floor(k / 65536), k % 65536, p[k]]; }); }

  /* ---------- پیشنهاد اتصال حروف (isol/init/medi/fina) از روی نام گلیف‌ها ---------- */
  function suggestJoining(font) {
    var byName = {}; font.glyphs.forEach(function (g, i) { byName[g.name] = i; });
    var forms = { isol: {}, init: {}, medi: {}, fina: {} };
    font.glyphs.forEach(function (g, i) {
      var mm = /^(.*)\.(isol|init|medi|fina)$/.exec(g.name) || /^(.*)[._-](isolated|initial|medial|final)$/.exec(g.name); if (!mm) return;
      var form = { isolated: 'isol', initial: 'init', medial: 'medi', final: 'fina' }[mm[2]] || mm[2], base = byName[mm[1]]; if (base === undefined || base === i) return;
      forms[form][base] = i;
    });
    return forms;
  }

  FS.layout = { open: open, commit: commit, build: build, parse: parseTable, newModel: newModel, addLookup: addLookup, addFeature: addFeature, removeFeature: removeFeature, getKern: getKern, setKern: setKern, ownPairs: ownPairs, kernLookups: kernLookups, suggestJoining: suggestJoining, ensureScript: ensureScript };
  if (typeof module !== 'undefined') module.exports = FS;
})(typeof window !== 'undefined' ? window : globalThis);
