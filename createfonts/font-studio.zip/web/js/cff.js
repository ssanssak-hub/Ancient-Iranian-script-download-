/* خواندن CFF (OTF) و تبدیل منحنی درجه‌سه به درجه‌دو */
(function (root) {
  'use strict';
  var FS = root.FS = root.FS || {};

  function readIndex(u8, o) {
    var dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength), count = dv.getUint16(o);
    if (count === 0) return { items: [], end: o + 2 };
    var os = u8[o + 2], offs = [], p = o + 3;
    for (var i = 0; i <= count; i++) { var v = 0; for (var k = 0; k < os; k++) v = v * 256 + u8[p++]; offs.push(v); }
    var base = p - 1, items = [];
    for (i = 0; i < count; i++) items.push(u8.subarray(base + offs[i], base + offs[i + 1]));
    return { items: items, end: base + offs[count] };
  }
  function readDict(d) {
    var res = {}, st = [], i = 0;
    while (i < d.length) {
      var b = d[i];
      if (b <= 21) { var op = b; i++; if (b === 12) { op = 1200 + d[i++]; } res[op] = st; st = []; }
      else if (b === 28) { st.push((d[i + 1] << 8 | d[i + 2]) << 16 >> 16); i += 3; }
      else if (b === 29) { st.push((d[i + 1] << 24 | d[i + 2] << 16 | d[i + 3] << 8 | d[i + 4])); i += 5; }
      else if (b === 30) { var s = ''; i++; var done = false; while (!done && i < d.length) { var by = d[i++]; [by >> 4, by & 15].forEach(function (n) { if (done) return; if (n < 10) s += n; else if (n === 10) s += '.'; else if (n === 11) s += 'E'; else if (n === 12) s += 'E-'; else if (n === 14) s += '-'; else if (n === 15) done = true; }); } st.push(parseFloat(s)); }
      else if (b >= 32 && b <= 246) { st.push(b - 139); i++; }
      else if (b >= 247 && b <= 250) { st.push((b - 247) * 256 + d[i + 1] + 108); i += 2; }
      else if (b >= 251 && b <= 254) { st.push(-(b - 251) * 256 - d[i + 1] - 108); i += 2; }
      else i++;
    }
    return res;
  }
  function bias(n) { return n < 1240 ? 107 : n < 33900 ? 1131 : 32768; }

  function runCharstring(cs, gsubrs, lsubrs, defW, nomW) {
    var stack = [], contours = [], cur = null, x = 0, y = 0, nStems = 0, haveWidth = false, width = defW, ended = false;
    function chkW(expected) { if (!haveWidth) { haveWidth = true; if (stack.length > expected) { width = nomW + stack.shift(); } } }
    function move(dx, dy) { if (cur && cur.length) contours.push(cur); x += dx; y += dy; cur = [{ x: x, y: y, on: true, t: 'm' }]; }
    function line(dx, dy) { x += dx; y += dy; cur.push({ x: x, y: y, on: true, t: 'l' }); }
    function curve(a, b, c, d, e, f) { var x1 = x + a, y1 = y + b, x2 = x1 + c, y2 = y1 + d; x = x2 + e; y = y2 + f; cur.push({ x: x1, y: y1, on: false, t: 'c' }, { x: x2, y: y2, on: false, t: 'c' }, { x: x, y: y, on: true, t: 'c' }); }
    function exec(code, depth) {
      var i = 0;
      while (i < code.length && !ended) {
        var b = code[i++];
        if (b >= 32 || b === 28) {
          if (b === 28) { stack.push((code[i] << 8 | code[i + 1]) << 16 >> 16); i += 2; }
          else if (b <= 246) stack.push(b - 139);
          else if (b <= 250) stack.push((b - 247) * 256 + code[i++] + 108);
          else if (b <= 254) stack.push(-(b - 251) * 256 - code[i++] - 108);
          else { stack.push(((code[i] << 24 | code[i + 1] << 16 | code[i + 2] << 8 | code[i + 3])) / 65536); i += 4; }
          continue;
        }
        var s = stack, n;
        switch (b) {
          case 1: case 3: case 18: case 23: chkW(s.length & ~1); nStems += s.length >> 1; stack = []; break;
          case 19: case 20: chkW(s.length & ~1); nStems += s.length >> 1; stack = []; i += (nStems + 7) >> 3; break;
          case 21: chkW(2); move(s[s.length - 2], s[s.length - 1]); stack = []; break;
          case 22: chkW(1); move(s[s.length - 1], 0); stack = []; break;
          case 4: chkW(1); move(0, s[s.length - 1]); stack = []; break;
          case 5: for (n = 0; n + 1 < s.length; n += 2) line(s[n], s[n + 1]); stack = []; break;
          case 6: case 7: { var h = b === 6; for (n = 0; n < s.length; n++) { if (h) line(s[n], 0); else line(0, s[n]); h = !h; } stack = []; break; }
          case 8: for (n = 0; n + 5 < s.length; n += 6) curve(s[n], s[n + 1], s[n + 2], s[n + 3], s[n + 4], s[n + 5]); stack = []; break;
          case 24: for (n = 0; n + 7 < s.length; n += 6) curve(s[n], s[n + 1], s[n + 2], s[n + 3], s[n + 4], s[n + 5]); line(s[n], s[n + 1]); stack = []; break;
          case 25: for (n = 0; n + 7 < s.length; n += 2) line(s[n], s[n + 1]); curve(s[n], s[n + 1], s[n + 2], s[n + 3], s[n + 4], s[n + 5]); stack = []; break;
          case 26: { n = 0; var dx1 = 0; if (s.length & 1) dx1 = s[n++]; for (; n + 3 < s.length; n += 4) { curve(dx1, s[n], s[n + 1], s[n + 2], 0, s[n + 3]); dx1 = 0; } stack = []; break; }
          case 27: { n = 0; var dy1 = 0; if (s.length & 1) dy1 = s[n++]; for (; n + 3 < s.length; n += 4) { curve(s[n], dy1, s[n + 1], s[n + 2], s[n + 3], 0); dy1 = 0; } stack = []; break; }
          case 30: case 31: { var hor = b === 31; n = 0; while (n + 3 < s.length) { var last = (s.length - n === 5) ? s[n + 4] : 0; if (hor) curve(s[n], 0, s[n + 1], s[n + 2], last, s[n + 3]); else curve(0, s[n], s[n + 1], s[n + 2], s[n + 3], last); hor = !hor; n += 4; } stack = []; break; }
          case 10: { var idx = stack.pop() + bias(lsubrs.length); if (lsubrs[idx] && depth < 12) exec(lsubrs[idx], depth + 1); break; }
          case 29: { var gi = stack.pop() + bias(gsubrs.length); if (gsubrs[gi] && depth < 12) exec(gsubrs[gi], depth + 1); break; }
          case 11: return;
          case 14: chkW(s.length >= 4 ? 4 : 0); ended = true; break;
          case 12: {
            var b2 = code[i++];
            if (b2 === 35) { curve(s[0], s[1], s[2], s[3], s[4], s[5]); curve(s[6], s[7], s[8], s[9], s[10], s[11]); }
            else if (b2 === 34) { curve(s[0], 0, s[1], s[2], s[3], 0); curve(s[4], 0, s[5], -s[2], s[6], 0); }
            else if (b2 === 36) { curve(s[0], s[1], s[2], s[3], s[4], 0); curve(s[5], 0, s[6], s[7], s[8], -(s[1] + s[3] + s[7])); }
            else if (b2 === 37) { var dx = s[0] + s[2] + s[4] + s[6] + s[8], dy = s[1] + s[3] + s[5] + s[7] + s[9]; curve(s[0], s[1], s[2], s[3], s[4], s[5]); if (Math.abs(dx) > Math.abs(dy)) curve(s[6], s[7], s[8], s[9], s[10], -dy); else curve(s[6], s[7], s[8], s[9], -dx, s[10]); }
            stack = []; break;
          }
          default: stack = [];
        }
      }
    }
    exec(cs, 0);
    if (cur && cur.length) contours.push(cur);
    return { contours: contours, width: width };
  }

  function parse(t) {
    var u8 = t, hdrSize = u8[2];
    var nameIdx = readIndex(u8, hdrSize), topIdx = readIndex(u8, nameIdx.end), strIdx = readIndex(u8, topIdx.end), gsIdx = readIndex(u8, strIdx.end);
    var top = readDict(topIdx.items[0]), csOff = top[17][0], cs = readIndex(u8, csOff).items;
    var isCID = top[1230] !== undefined, privs = [], fdSelect = null;
    function priv(dict) {
      var p = dict[18]; if (!p) return { subrs: [], defW: 0, nomW: 0 };
      var pd = readDict(u8.subarray(p[1], p[1] + p[0])), subrs = pd[19] ? readIndex(u8, p[1] + pd[19][0]).items : [];
      return { subrs: subrs, defW: pd[20] ? pd[20][0] : 0, nomW: pd[21] ? pd[21][0] : 0 };
    }
    if (isCID) {
      var fda = readIndex(u8, top[1236][0]).items; fda.forEach(function (f) { privs.push(priv(readDict(f))); });
      var fo = top[1237][0], fmt = u8[fo]; fdSelect = new Uint8Array(cs.length);
      if (fmt === 0) for (var i = 0; i < cs.length; i++) fdSelect[i] = u8[fo + 1 + i];
      else { var nr = u8[fo + 1] << 8 | u8[fo + 2], p = fo + 3; for (var r = 0; r < nr; r++) { var first = u8[p] << 8 | u8[p + 1], fd = u8[p + 2], nxt = u8[p + 3] << 8 | u8[p + 4]; for (var g = first; g < nxt && g < cs.length; g++) fdSelect[g] = fd; p += 3; } }
    } else privs.push(priv(top));
    var glyphs = [];
    for (var gi = 0; gi < cs.length; gi++) {
      var pv = privs[fdSelect ? fdSelect[gi] : 0] || privs[0], r2;
      try { r2 = runCharstring(cs[gi], gsIdx.items, pv.subrs, pv.defW, pv.nomW); } catch (e) { r2 = { contours: [], width: 0 }; }
      glyphs.push({ contours: r2.contours, width: r2.width });
    }
    return { glyphs: glyphs, isCID: isCID };
  }

  /* contour شامل نقاط با t: m/l/c ← contour درجه‌دو (on/off) */
  function toQuadratic(contours) {
    var out = [];
    contours.forEach(function (c) {
      if (c.length < 2) return;
      var pts = [], i = 0, cur = c[0];
      pts.push({ x: Math.round(cur.x), y: Math.round(cur.y), on: true });
      i = 1;
      while (i < c.length) {
        var p = c[i];
        if (p.t === 'l') { pts.push({ x: Math.round(p.x), y: Math.round(p.y), on: true }); cur = p; i++; }
        else {
          var c1 = c[i], c2 = c[i + 1], p3 = c[i + 2]; i += 3; if (!c2 || !p3) break;
          cubicToQuads(cur, c1, c2, p3).forEach(function (q) { pts.push({ x: Math.round(q.cx), y: Math.round(q.cy), on: false }, { x: Math.round(q.x), y: Math.round(q.y), on: true }); });
          cur = p3;
        }
      }
      var f = pts[0], l = pts[pts.length - 1];
      if (pts.length > 1 && l.on && f.x === l.x && f.y === l.y) pts.pop();
      if (pts.length >= 2) out.push(pts);
    });
    return out;
  }
  function cubicToQuads(p0, c1, c2, p3) {
    var dx = p3.x - 3 * c2.x + 3 * c1.x - p0.x, dy = p3.y - 3 * c2.y + 3 * c1.y - p0.y, d = Math.sqrt(dx * dx + dy * dy);
    var n = Math.max(1, Math.min(10, Math.ceil(Math.cbrt(0.0481 * d / 0.4)))), res = [];
    function pt(t) { var u = 1 - t; return { x: u * u * u * p0.x + 3 * u * u * t * c1.x + 3 * u * t * t * c2.x + t * t * t * p3.x, y: u * u * u * p0.y + 3 * u * u * t * c1.y + 3 * u * t * t * c2.y + t * t * t * p3.y }; }
    function der(t) { var u = 1 - t; return { x: 3 * u * u * (c1.x - p0.x) + 6 * u * t * (c2.x - c1.x) + 3 * t * t * (p3.x - c2.x), y: 3 * u * u * (c1.y - p0.y) + 6 * u * t * (c2.y - c1.y) + 3 * t * t * (p3.y - c2.y) }; }
    for (var k = 0; k < n; k++) {
      var t0 = k / n, t1 = (k + 1) / n, a = pt(t0), b = pt(t1), da = der(t0), db = der(t1), h = (t1 - t0) / 3;
      var c1x = a.x + da.x * h, c1y = a.y + da.y * h, c2x = b.x - db.x * h, c2y = b.y - db.y * h;
      var q = { cx: (3 * c1x - a.x + 3 * c2x - b.x) / 4, cy: (3 * c1y - a.y + 3 * c2y - b.y) / 4, x: b.x, y: b.y };
      res.push(q);
    }
    return res;
  }
  FS.cff = { parse: parse, toQuadratic: toQuadratic };
  if (typeof module !== 'undefined') module.exports = FS;
})(typeof window !== 'undefined' ? window : globalThis);
