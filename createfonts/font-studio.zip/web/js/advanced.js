(function(root){
  'use strict';
  var A=root.StudioApp, FS=root.FS;
  if(!A || !FS) return;
  var T=A.T, $=A.$, S=A.S;
  function esc(s){ return A.esc(String(s==null?'':s)); }
  function nfmt(n){ return Number(n||0).toLocaleString(); }
  function pct(a,b){ return b ? Math.round(a*1000/b)/10 : 0; }
  function hex(n){ return 'U+'+Number(n).toString(16).toUpperCase().padStart(4,'0'); }
  function analyze(){
    var f=S.font, out={errors:[],warnings:[],info:[],counts:{glyphs:f.glyphs.length, mapped:0, contours:0, points:0, empty:0, duplicateUnicode:0, duplicateNames:0}};
    if(!f) return out;
    var seenU={}, seenN={};
    f.glyphs.forEach(function(g,i){
      var name=(g.name||'').trim();
      if(!name) out.errors.push('Glyph #'+i+' has no name.');
      else if(seenN[name]!==undefined){ out.errors.push('Duplicate glyph name: '+name+' (#'+seenN[name]+' and #'+i+').'); out.counts.duplicateNames++; }
      else seenN[name]=i;
      var us=Array.isArray(g.unicodes)?g.unicodes:[];
      if(us.length) out.counts.mapped += us.length; else if(i!==0 && name!=='.notdef') out.warnings.push('Unmapped glyph: '+(name||('#'+i)));
      us.forEach(function(u){ if(seenU[u]!==undefined){ out.errors.push('Duplicate Unicode '+hex(u)+' in #'+seenU[u]+' and #'+i+'.'); out.counts.duplicateUnicode++; } else seenU[u]=i; });
      var cs=Array.isArray(g.contours)?g.contours:[]; out.counts.contours+=cs.length; if(!cs.length) out.counts.empty++;
      cs.forEach(function(c,ci){ if(!Array.isArray(c)||c.length<2) out.errors.push((name||('#'+i))+' contour '+ci+' has fewer than 2 points.'); out.counts.points += Array.isArray(c)?c.length:0; (Array.isArray(c)?c:[]).forEach(function(p,pi){ if(!Number.isFinite(p.x)||!Number.isFinite(p.y)) out.errors.push((name||('#'+i))+' has invalid point '+ci+':'+pi+'.'); }); });
      if(!Number.isFinite(g.adv) || g.adv<0) out.errors.push((name||('#'+i))+' has invalid advance width.');
    });
    if(!f.glyphs.some(function(g,i){return i===0 || g.name==='.notdef';})) out.errors.push('Missing .notdef glyph.');
    if(!f.upm || f.upm<16 || f.upm>16384) out.warnings.push('Unusual units-per-em: '+f.upm+'.');
    if(f.flavor && String(f.flavor).toLowerCase()!=='ttf') out.info.push('Source flavor: '+f.flavor+'. Export is TrueType/glyf.');
    if(f.variable || f.fvar || f.axes) out.warnings.push('Variable-font data is present; current editor workflow may flatten it to a static font.');
    if(f.lastDropped && f.lastDropped.length) out.warnings.push('Pending dropped OpenType tables: '+f.lastDropped.join(', ')+'.');
    var latin=0, pers=0, arab=0, digits=0;
    Object.keys(seenU).forEach(function(k){var u=+k; if(u>=0x20&&u<=0x7e)latin++; if(u>=0x600&&u<=0x6ff)arab++; if(u>=0x670&&u<=0x6ff)pers++; if((u>=0x30&&u<=0x39)||(u>=0x660&&u<=0x669)||(u>=0x6f0&&u<=0x6f9))digits++;});
    out.info.push('Unicode mappings: '+nfmt(out.counts.mapped)+'.');
    out.info.push('Coverage: Latin '+latin+' · Arabic '+arab+' · Persian/Arabic extensions '+pers+' · digits '+digits+'.');
    var forms={isol:0,init:0,medi:0,fina:0}; f.glyphs.forEach(function(g){var m=String(g.name||'').match(/\.(isol|init|medi|fina)$/); if(m) forms[m[1]]++;});
    out.info.push('Joining-form glyphs: isol '+forms.isol+' · init '+forms.init+' · medi '+forms.medi+' · fina '+forms.fina+'.');
    if((forms.init||forms.medi||forms.fina||forms.isol) && !f._layout) out.warnings.push('Joining-form glyphs exist but layout data is not currently opened/committed.');
    return out;
  }
  function badge(kind,text){ return '<span class="fsbadge '+kind+'">'+esc(text)+'</span>'; }
  function renderReport(out){
    var html='<div class="fs-summary">'+badge(out.errors.length?'bad':'ok',out.errors.length?out.errors.length+' خطا':'بدون خطای پایه')+badge(out.warnings.length?'warn':'ok',out.warnings.length+' هشدار')+badge('info',out.counts.glyphs+' گلیف')+'</div>';
    function list(arr,cls){return arr.length?'<div class="fs-list '+cls+'">'+arr.map(function(x){return '<div>• '+esc(x)+'</div>';}).join('')+'</div>':'<div class="muted">'+T('موردی پیدا نشد.','Nothing found.')+'</div>';}
    html+='<div class="fs-cols"><div><h4>🔴 '+T('خطاها','Errors')+'</h4>'+list(out.errors,'badbox')+'</div><div><h4>🟡 '+T('هشدارها','Warnings')+'</h4>'+list(out.warnings,'warnbox')+'</div></div>';
    html+='<div class="card fs-inner"><h4>📊 '+T('آمار','Statistics')+'</h4><div class="fs-stats">'+Object.keys(out.counts).map(function(k){return '<div><b>'+nfmt(out.counts[k])+'</b><span>'+esc(k)+'</span></div>';}).join('')+'</div>'+list(out.info,'infobox')+'</div>';
    return html;
  }
  function reportJson(out){return JSON.stringify({generatedAt:new Date().toISOString(),family:A.fam(),upm:S.font.upm,analysis:out},null,2);}
  function previewCard(){
    return '<div class="card"><h3>🧪 '+T('آزمایشگاه زنده فونت','Live Font Lab')+'</h3><div class="row"><label class="f grow">'+T('متن آزمایشی','Sample text')+'<textarea id="fsSample" rows="3">سلام دنیا\nکتاب فارسی ۱۲۳\nThe quick brown fox</textarea></label></div><div class="row"><label class="f">'+T('اندازه','Size')+'<input id="fsSize" type="range" min="12" max="180" value="48"></label><label class="f">'+T('فاصله حروف','Letter spacing')+'<input id="fsTrack" type="range" min="-5" max="30" value="0"></label><label class="f">'+T('ارتفاع خط','Line height')+'<input id="fsLead" type="range" min="0.8" max="2.5" step="0.05" value="1.4"></label></div><div id="fsPreview" class="fs-preview">سلام دنیا</div><div class="row"><button class="b p" id="fsBuildPreview">⚡ '+T('ساخت Preview از فونت فعلی','Build preview from current font')+'</button><span id="fsPreviewState" class="muted"></span></div></div>';
  }
  function coverageCard(){
    var f=S.font, cells=[]; for(var u=0x600;u<=0x6ff;u++){ var gi=-1; for(var i=0;i<f.glyphs.length;i++){if((f.glyphs[i].unicodes||[]).indexOf(u)>=0){gi=i;break;}} cells.push('<button class="fs-cov '+(gi>=0?'has':'miss')+'" data-gi="'+gi+'" title="'+hex(u)+'">'+String.fromCodePoint(u)+'</button>'); }
    return '<div class="card"><h3>🧩 '+T('نقشه پوشش عربی/فارسی','Arabic/Persian Coverage Map')+'</h3><div class="muted">'+T('سبز یعنی گلیف متناظر وجود دارد؛ قرمز یعنی هنوز نگاشت نشده است.','Green means a mapped glyph exists; red means it is not mapped yet.')+'</div><div class="fs-coverage">'+cells.join('')+'</div><div class="row"><span class="fsbadge ok">'+T('موجود','Present')+'</span><span class="fsbadge bad">'+T('ناقص','Missing')+'</span></div></div>';
  }
  function installFontPreview(){
    var btn=$('fsBuildPreview'); if(!btn)return;
    btn.onclick=async function(){
      var state=$('fsPreviewState'); state.textContent=T('در حال ساخت فونت…','Building font…');
      try{
        if(S.font._layout) FS.layout.commit(S.font);
        var bytes=FS.sfnt.buildFont(S.font); var blob=new Blob([bytes],{type:'font/ttf'}), url=URL.createObjectURL(blob), fam='FSPreview_'+Date.now();
        var face=new FontFace(fam,'url('+url+')'); await face.load(); document.fonts.add(face);
        $('fsPreview').style.fontFamily='"'+fam+'"'; state.textContent=T('Preview آماده است ✔','Preview ready ✔');
        btn.dataset.url=url;
      }catch(e){state.textContent=T('ساخت Preview ناموفق بود: ','Preview failed: ')+(e.message||e);}
    };
    function sync(){var p=$('fsPreview'); if(!p)return; p.style.fontSize=$('fsSize').value+'px'; p.style.letterSpacing=$('fsTrack').value+'px'; p.style.lineHeight=$('fsLead').value; p.textContent=$('fsSample').value;}
    ['fsSize','fsTrack','fsLead','fsSample'].forEach(function(id){var el=$(id);if(el)el.oninput=sync;}); sync();
  }
  function openLab(){
    var m=document.createElement('div'); m.className='fs-lab'; m.innerHTML='<div class="fs-lab-head"><div><h2>🛠️ '+T('Font Pro Lab','Font Pro Lab')+'</h2><div class="muted">'+esc(A.fam())+' · UPM '+nfmt(S.font.upm)+'</div></div><button class="b" id="fsClose">✕</button></div><div id="fsLabBody">'+previewCard()+coverageCard()+'<div class="card"><h3>🩺 '+T('بررسی پیش از خروجی','Preflight Check')+'</h3><div class="row"><button class="b p" id="fsRun">🔍 '+T('اجرای بررسی کامل','Run full check')+'</button><button class="b" id="fsSave">⬇️ '+T('ذخیره گزارش JSON','Save JSON report')+'</button></div><div id="fsReport" class="fs-report"></div></div></div>';
    document.body.appendChild(m); $('fsClose').onclick=function(){m.remove();};
    function run(){var out=analyze(); $('fsReport').innerHTML=renderReport(out); $('fsSave').onclick=async function(){try{var r=await A.Host.saveFile(new TextEncoder().encode(reportJson(out)),FS.io.slug(A.fam())+'-font-health.json','application/json');if(r.saved)A.toast(T('گزارش ذخیره شد ✔','Report saved ✔'));}catch(e){A.fail(e);}}; document.querySelectorAll('.fs-cov').forEach(function(b){b.onclick=function(){var gi=+b.dataset.gi;if(gi>=0)A.go('edit'); if(gi>=0){S.gi=gi; setTimeout(function(){A.go('edit');},0);}};});}
    $('fsRun').onclick=run; run(); installFontPreview();
  }
  var old= A.afterTools;
  A.afterTools=function(m){ if(old) old(m); var d=document.createElement('details'); d.open=false; d.innerHTML='<summary>🛠️ '+T('Font Pro Lab — ابزارهای حرفه‌ای','Font Pro Lab — Advanced tools')+'</summary><div class="muted">'+T('بررسی سلامت، تست زنده، پوشش فارسی/عربی و گزارش خروجی.','Health checks, live preview, Arabic/Persian coverage and export report.')+'</div><button class="b p" id="fsOpenLab">🚀 '+T('باز کردن آزمایشگاه حرفه‌ای','Open Pro Lab')+'</button>'; m.appendChild(d); d.querySelector('#fsOpenLab').onclick=openLab; };
})(window);
