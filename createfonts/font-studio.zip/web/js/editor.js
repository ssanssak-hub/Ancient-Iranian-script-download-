/* ویرایشگر گلیف روی بوم: انتخاب/جابه‌جایی، قلم، افزودن/حذف نقطه، زوم و جابه‌جایی با لمس */
(function (root) {
  'use strict';
  var FS = root.FS = root.FS || {};

  function snap(g) { return { c: JSON.stringify(g.contours), a: g.adv, u: (g.unicodes || []).slice(), n: g.name }; }
  function restore(g, s) { g.contours = JSON.parse(s.c); g.adv = s.a; g.unicodes = s.u.slice(); g.name = s.n; }
  function normalizeGlyph(g) { var out = []; g.contours.forEach(function (c) { var n = FS.geom.normalized(c); if (n && n.length >= 2) out.push(n.map(function (p) { return { x: Math.round(p.x), y: Math.round(p.y), on: p.on }; })); }); g.contours = out; }

  function GlyphEditor(canvas, host) {
    this.cv = canvas; this.host = host; this.ctx = canvas.getContext('2d');
    this.gi = 0; this.sel = {}; this.tool = 'select'; this.multi = false; this.penOff = false; this.pen = null;
    this.showOrig = false; this.showGrid = true; this.snapOn = false; this.gridSize = 10; this.showNums = false;
    this.v = { s: 0.2, ox: 40, oy: 300 }; this.ptrs = {}; this.mode = null; this.dirty = false;
    var self = this;
    canvas.style.touchAction = 'none';
    canvas.addEventListener('pointerdown', function (e) { self.down(e); });
    canvas.addEventListener('pointermove', function (e) { self.move(e); });
    canvas.addEventListener('pointerup', function (e) { self.up(e); });
    canvas.addEventListener('pointercancel', function (e) { self.up(e); });
    canvas.addEventListener('wheel', function (e) { e.preventDefault(); self.zoomAt(e.offsetX, e.offsetY, e.deltaY < 0 ? 1.15 : 1 / 1.15); }, { passive: false });
  }
  var P = GlyphEditor.prototype;

  P.font = function () { return this.host.font(); };
  P.glyph = function () { var f = this.font(); return f && f.glyphs[this.gi]; };
  P.resize = function () {
    var r = this.cv.getBoundingClientRect(), d = window.devicePixelRatio || 1;
    this.cv.width = Math.max(10, Math.round(r.width * d)); this.cv.height = Math.max(10, Math.round(r.height * d)); this.dpr = d; this.W = r.width; this.H = r.height;
    this.draw();
  };
  P.open = function (gi) {
    this.finishPen(); this.gi = gi; this.sel = {}; var g = this.glyph(); if (!g) return;
    normalizeGlyph(g); this.fit(); this.draw();
  };
  P.fit = function () {
    var f = this.font(), g = this.glyph(); if (!f || !this.W) return;
    var top = Math.max(f.hhea.asc, f.upm * .8), bot = Math.min(f.hhea.desc, -f.upm * .25), h = top - bot;
    var w = Math.max(g ? g.adv : f.upm, f.upm * .5) * 1.3;
    this.v.s = Math.min(this.H / (h * 1.15), this.W / w);
    this.v.ox = (this.W - (g ? g.adv : f.upm) * this.v.s) / 2; this.v.oy = this.H / 2 + (top + bot) / 2 * this.v.s;
  };
  P.X = function (x) { return this.v.ox + x * this.v.s; }; P.Y = function (y) { return this.v.oy - y * this.v.s; };
  P.fx = function (px) { return (px - this.v.ox) / this.v.s; }; P.fy = function (py) { return (this.v.oy - py) / this.v.s; };
  P.zoomAt = function (px, py, k) {
    var ns = Math.max(0.01, Math.min(8, this.v.s * k)), x = this.fx(px), y = this.fy(py);
    this.v.s = ns; this.v.ox = px - x * ns; this.v.oy = py + y * ns; this.draw();
  };
  P.setTool = function (t) { this.finishPen(); this.tool = t; this.draw(); };
  P.finishPen = function () { if (this.pen) { var g = this.glyph(); this.pen = null; if (g) { normalizeGlyph(g); this.sel = {}; this.host.changed(this.gi, true); } } };

  /* ---------- تاریخچه ---------- */
  P.begin = function () { var g = this.glyph(); this._before = g ? snap(g) : null; };
  P.end = function () {
    var g = this.glyph(); if (!g || !this._before) return;
    var after = snap(g);
    if (JSON.stringify(after) !== JSON.stringify(this._before)) this.host.pushHistory([{ gi: this.gi, before: this._before, after: after }]);
    this._before = null; this.host.changed(this.gi, false);
  };

  /* ---------- نقطه‌ها ---------- */
  P.selKeys = function () { return Object.keys(this.sel); };
  P.hasSel = function () { return this.selKeys().length > 0; };
  P.hit = function (px, py) {
    var g = this.glyph(), best = null, bd = 18 * 18; if (!g) return null;
    for (var ci = 0; ci < g.contours.length; ci++) for (var pi = 0; pi < g.contours[ci].length; pi++) {
      var p = g.contours[ci][pi], dx = this.X(p.x) - px, dy = this.Y(p.y) - py, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = ci + ':' + pi; }
    }
    return best;
  };
  P.pt = function (k) { var a = k.split(':'); var g = this.glyph(); return g.contours[+a[0]] && g.contours[+a[0]][+a[1]]; };

  P.segments = function () {
    var g = this.glyph(), segs = [];
    g.contours.forEach(function (c, ci) {
      var n = c.length; for (var i = 0; i < n; i++) {
        if (!c[i].on) continue; var a = c[i], b = c[(i + 1) % n];
        if (b.on) segs.push({ ci: ci, i: i, quad: false, p0: a, p2: b });
        else segs.push({ ci: ci, i: i, quad: true, p0: a, c: b, p2: c[(i + 2) % n] });
      }
    });
    return segs;
  };
  P.insertAt = function (px, py) {
    var g = this.glyph(), segs = this.segments(), best = null, bd = 26 * 26, self = this;
    segs.forEach(function (s) {
      for (var k = 1; k < 24; k++) {
        var t = k / 24, x, y;
        if (s.quad) { var u = 1 - t; x = u * u * s.p0.x + 2 * u * t * s.c.x + t * t * s.p2.x; y = u * u * s.p0.y + 2 * u * t * s.c.y + t * t * s.p2.y; }
        else { x = s.p0.x + (s.p2.x - s.p0.x) * t; y = s.p0.y + (s.p2.y - s.p0.y) * t; }
        var dx = self.X(x) - px, dy = self.Y(y) - py, d = dx * dx + dy * dy;
        if (d < bd) { bd = d; best = { s: s, t: t, x: x, y: y }; }
      }
    });
    if (!best) return;
    this.begin(); var c = g.contours[best.s.ci], s = best.s, t = best.t;
    if (!s.quad) c.splice(s.i + 1, 0, { x: Math.round(best.x), y: Math.round(best.y), on: true });
    else {
      var c1 = { x: Math.round(s.p0.x + (s.c.x - s.p0.x) * t), y: Math.round(s.p0.y + (s.c.y - s.p0.y) * t), on: false };
      var c2 = { x: Math.round(s.c.x + (s.p2.x - s.c.x) * t), y: Math.round(s.c.y + (s.c.y === undefined ? 0 : (s.p2.y - s.c.y)) * t), on: false };
      c2.x = Math.round(s.c.x + (s.p2.x - s.c.x) * t); c2.y = Math.round(s.c.y + (s.p2.y - s.c.y) * t);
      var m = { x: Math.round(best.x), y: Math.round(best.y), on: true };
      c.splice(s.i + 1, 1, c1, m, c2);
    }
    this.sel = {}; this.end(); this.draw();
  };
  P.removeKeys = function (keys) {
    var g = this.glyph(); if (!g || !keys.length) return; this.begin();
    var rm = {}; keys.forEach(function (k) { rm[k] = 1; });
    g.contours = g.contours.map(function (c, ci) { return c.filter(function (_, pi) { return !rm[ci + ':' + pi]; }); }).filter(function (c) { return c.length >= 2; });
    normalizeGlyph(g); this.sel = {}; this.end(); this.draw();
  };
  P.toggleOn = function () {
    var g = this.glyph(), keys = this.selKeys(); if (!g || !keys.length) return; this.begin();
    keys.forEach(function (k) { var a = k.split(':'), p = g.contours[+a[0]][+a[1]]; p.on = !p.on; });
    normalizeGlyph(g); this.sel = {}; this.end(); this.draw();
  };

  /* ---------- تبدیل‌ها (روی انتخاب؛ اگر انتخابی نیست روی کل گلیف) ---------- */
  P.targets = function () {
    var g = this.glyph(), keys = this.selKeys(), res = [], self = this;
    if (keys.length) keys.forEach(function (k) { var p = self.pt(k); if (p) res.push(p); });
    else g.contours.forEach(function (c) { c.forEach(function (p) { res.push(p); }); });
    return res;
  };
  P.center = function (pts) { var b = FS.sfnt.bboxOf([pts]); return b ? { x: (b.x0 + b.x1) / 2, y: (b.y0 + b.y1) / 2 } : { x: 0, y: 0 }; };
  P.transform = function (fn) {
    var g = this.glyph(); if (!g) return; this.begin(); var pts = this.targets(), c = this.center(pts);
    pts.forEach(function (p) { var r = fn(p.x - c.x, p.y - c.y); p.x = Math.round(c.x + r[0]); p.y = Math.round(c.y + r[1]); });
    this.end(); this.draw();
  };
  P.move = function (e) {
    var r = this.cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, p = this.ptrs[e.pointerId];
    if (!p) return; var dx = x - p.x, dy = y - p.y; p.x = x; p.y = y;
    var ids = Object.keys(this.ptrs);
    if (ids.length === 2 && this.mode === 'pinch') {
      var a = this.ptrs[ids[0]], b = this.ptrs[ids[1]], d = Math.hypot(a.x - b.x, a.y - b.y), cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2;
      this.v.ox += cx - this.pinch.cx; this.v.oy += cy - this.pinch.cy; this.zoomAt(cx, cy, d / this.pinch.d); this.pinch = { d: d, cx: cx, cy: cy }; return;
    }
    var g = this.glyph(); if (!g) return;
    if (this.mode === 'pan') { this.v.ox += dx; this.v.oy += dy; this.draw(); }
    else if (this.mode === 'drag') {
      this.acc.x += dx / this.v.s; this.acc.y -= dy / this.v.s; var gs = this.snapOn ? this.gridSize : 1, self = this;
      var mx = Math.round(this.acc.x / gs) * gs, my = Math.round(this.acc.y / gs) * gs;
      this.dragPts.forEach(function (d) { d.p.x = d.x + mx; d.p.y = d.y + my; });
      this.dirty = true; this.draw();
    } else if (this.mode === 'adv') { g.adv = Math.max(0, Math.round(this.fx(x) / (this.snapOn ? this.gridSize : 1)) * (this.snapOn ? this.gridSize : 1)); this.host.advChanged && this.host.advChanged(g.adv); this.draw(); }
    else if (this.mode === 'box') { this.box.x1 = x; this.box.y1 = y; this.draw(); }
  };
  P.down = function (e) {
    this.cv.setPointerCapture(e.pointerId);
    var r = this.cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; this.ptrs[e.pointerId] = { x: x, y: y };
    var ids = Object.keys(this.ptrs), g = this.glyph(); if (!g) return;
    if (ids.length === 2) {
      if (this._before) { this.end(); }
      var a = this.ptrs[ids[0]], b = this.ptrs[ids[1]]; this.mode = 'pinch'; this.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2 }; return;
    }
    var t = this.tool;
    if (t === 'hand') { this.mode = 'pan'; return; }
    if (t === 'insert') { this.insertAt(x, y); return; }
    if (t === 'delete') { var h0 = this.hit(x, y); if (h0) this.removeKeys([h0]); return; }
    if (t === 'pen') { this.penTap(x, y); return; }
    var h = this.hit(x, y);
    if (h) {
      if (!this.sel[h]) { if (!this.multi) this.sel = {}; this.sel[h] = 1; } else if (this.multi) delete this.sel[h];
      this.begin(); this.mode = 'drag'; this.acc = { x: 0, y: 0 }; var self = this;
      this.dragPts = this.selKeys().map(function (k) { var p = self.pt(k); return { p: p, x: p.x, y: p.y }; }); this.draw(); return;
    }
    if (Math.abs(x - this.X(g.adv)) < 16) { this.begin(); this.mode = 'adv'; return; }
    if (!this.multi) this.sel = {};
    this.mode = 'box'; this.box = { x0: x, y0: y, x1: x, y1: y }; this.draw();
  };
  P.up = function (e) {
    delete this.ptrs[e.pointerId];
    if (this.mode === 'pinch') { if (Object.keys(this.ptrs).length < 2) this.mode = null; return; }
    if (this.mode === 'drag' || this.mode === 'adv') { this.end(); }
    else if (this.mode === 'box') {
      var b = this.box, g = this.glyph(), x0 = Math.min(b.x0, b.x1), x1 = Math.max(b.x0, b.x1), y0 = Math.min(b.y0, b.y1), y1 = Math.max(b.y0, b.y1), self = this;
      g.contours.forEach(function (c, ci) { c.forEach(function (p, pi) { var sx = self.X(p.x), sy = self.Y(p.y); if (sx >= x0 && sx <= x1 && sy >= y0 && sy <= y1) self.sel[ci + ':' + pi] = 1; }); });
      this.box = null; this.host.selChanged && this.host.selChanged();
    }
    this.mode = null; this.draw();
  };
  P.penTap = function (px, py) {
    var g = this.glyph(); this.begin();
    var x = Math.round(this.fx(px) / (this.snapOn ? this.gridSize : 1)) * (this.snapOn ? this.gridSize : 1), y = Math.round(this.fy(py) / (this.snapOn ? this.gridSize : 1)) * (this.snapOn ? this.gridSize : 1);
    if (this.pen) {
      var c = g.contours[this.pen.ci], f = c[0];
      if (c.length > 2 && Math.hypot(this.X(f.x) - px, this.Y(f.y) - py) < 18) { this.end(); this.finishPen(); this.draw(); return; }
      c.push({ x: x, y: y, on: !this.penOff });
    } else { g.contours.push([{ x: x, y: y, on: true }]); this.pen = { ci: g.contours.length - 1 }; }
    this.dirty = true; this.end(); this.draw();
  };

  /* ---------- نقاشی ---------- */
  P.draw = function () {
    var ctx = this.ctx, f = this.font(), g = this.glyph(); if (!ctx || !this.W) return;
    var d = this.dpr || 1, col = this.host.colors();
    ctx.setTransform(d, 0, 0, d, 0, 0); ctx.clearRect(0, 0, this.W, this.H);
    ctx.fillStyle = col.bg; ctx.fillRect(0, 0, this.W, this.H);
    if (!f || !g) return;
    var s = this.v.s, self = this;
    function hline(y, color, label, dash) { ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.setLineDash(dash || []); ctx.beginPath(); ctx.moveTo(0, self.Y(y)); ctx.lineTo(self.W, self.Y(y)); ctx.stroke(); ctx.setLineDash([]); if (label) { ctx.fillStyle = color; ctx.font = '10px sans-serif'; ctx.fillText(label, 4, self.Y(y) - 3); } }
    function vline(x, color) { ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(self.X(x), 0); ctx.lineTo(self.X(x), self.H); ctx.stroke(); }
    if (this.showGrid && this.gridSize * s > 6) {
      ctx.strokeStyle = col.grid; ctx.lineWidth = 1; ctx.beginPath();
      var gx0 = Math.floor(this.fx(0) / this.gridSize) * this.gridSize, gx1 = this.fx(this.W), gy0 = Math.floor(this.fy(this.H) / this.gridSize) * this.gridSize, gy1 = this.fy(0);
      for (var x = gx0; x <= gx1; x += this.gridSize) { ctx.moveTo(this.X(x) + .5, 0); ctx.lineTo(this.X(x) + .5, this.H); }
      for (var y = gy0; y <= gy1; y += this.gridSize) { ctx.moveTo(0, this.Y(y) + .5); ctx.lineTo(this.W, this.Y(y) + .5); }
      ctx.stroke();
    }
    hline(0, '#e5534b', 'baseline'); hline(f.hhea.asc, '#3b82f6', 'asc', [4, 4]); hline(f.hhea.desc, '#3b82f6', 'desc', [4, 4]);
    if (f.os2.xHeight) hline(f.os2.xHeight, '#16a34a', 'x', [2, 4]); if (f.os2.capHeight) hline(f.os2.capHeight, '#16a34a', 'cap', [2, 4]);
    vline(0, '#e5534b'); vline(g.adv, '#f59e0b');
    ctx.fillStyle = '#f59e0b'; ctx.fillRect(this.X(g.adv) - 3, this.H / 2 - 16, 6, 32);
    if (this.showOrig && f.snapshot && f.snapshot[this.gi] && this.gi < f.snapshot.length) {
      ctx.save(); ctx.setTransform(d * s, 0, 0, -d * s, d * this.v.ox, d * this.v.oy);
      ctx.strokeStyle = 'rgba(150,150,150,.9)'; ctx.lineWidth = 1.5 / s; ctx.setLineDash([4 / s, 3 / s]); ctx.stroke(new Path2D(FS.geom.pathD(f.snapshot[this.gi], false))); ctx.restore(); ctx.setLineDash([]);
    }
    ctx.save(); ctx.setTransform(d * s, 0, 0, -d * s, d * this.v.ox, d * this.v.oy);
    var path = new Path2D(FS.geom.pathD(g.contours, false));
    ctx.fillStyle = col.fill; ctx.fill(path, 'nonzero'); ctx.strokeStyle = col.stroke; ctx.lineWidth = 1.6 / s; ctx.stroke(path); ctx.restore();
    /* دستگیره‌ها و نقطه‌ها */
    ctx.lineWidth = 1;
    g.contours.forEach(function (c, ci) {
      var n = c.length;
      ctx.strokeStyle = 'rgba(120,120,255,.6)'; ctx.beginPath();
      c.forEach(function (p, pi) { if (!p.on) { [c[(pi + n - 1) % n], c[(pi + 1) % n]].forEach(function (q) { if (q.on) { ctx.moveTo(self.X(p.x), self.Y(p.y)); ctx.lineTo(self.X(q.x), self.Y(q.y)); } }); } });
      ctx.stroke();
      c.forEach(function (p, pi) {
        var px = self.X(p.x), py = self.Y(p.y), sel = !!self.sel[ci + ':' + pi];
        ctx.fillStyle = sel ? '#ef4444' : (p.on ? col.on : '#fff'); ctx.strokeStyle = sel ? '#7f1d1d' : col.on;
        ctx.beginPath(); if (p.on) ctx.rect(px - 4, py - 4, 8, 8); else ctx.arc(px, py, 3.5, 0, 6.3); ctx.fill(); ctx.stroke();
        if (pi === 0) { ctx.strokeStyle = '#22c55e'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(px, py, 8, 0, 6.3); ctx.stroke(); ctx.lineWidth = 1; }
        if (self.showNums) { ctx.fillStyle = col.stroke; ctx.font = '9px sans-serif'; ctx.fillText(pi, px + 6, py - 6); }
      });
    });
    if (this.box) { var b = this.box; ctx.strokeStyle = '#3b82f6'; ctx.fillStyle = 'rgba(59,130,246,.12)'; ctx.fillRect(b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0); ctx.strokeRect(b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0); }
  };

  /* ---------- عملیات ساده روی کل گلیف/انتخاب ---------- */
  P.reverse = function () {
    var g = this.glyph(); this.begin(); var keys = this.selKeys(), cis = {};
    keys.forEach(function (k) { cis[k.split(':')[0]] = 1; }); var all = !keys.length;
    g.contours.forEach(function (c, ci) { if (all || cis[ci]) { var f = c[0]; var r = c.slice(1).reverse(); r.unshift(f); r.forEach(function (p, i) { c[i] = p; }); } });
    this.sel = {}; this.end(); this.draw();
  };
  P.roundAll = function () { var g = this.glyph(); this.begin(); g.contours.forEach(function (c) { c.forEach(function (p) { p.x = Math.round(p.x); p.y = Math.round(p.y); }); }); this.end(); this.draw(); };
  P.addExtrema = function () { var g = this.glyph(); this.begin(); addExtremaTo(g); this.sel = {}; this.end(); this.draw(); };
  P.deleteContourSel = function () {
    var g = this.glyph(), cis = {}; this.selKeys().forEach(function (k) { cis[k.split(':')[0]] = 1; }); if (!Object.keys(cis).length) return;
    this.begin(); g.contours = g.contours.filter(function (_, ci) { return !cis[ci]; }); this.sel = {}; this.end(); this.draw();
  };
  P.selectAll = function () { var g = this.glyph(), self = this; this.sel = {}; g.contours.forEach(function (c, ci) { c.forEach(function (_, pi) { self.sel[ci + ':' + pi] = 1; }); }); this.draw(); };
  P.clipboard = null;
  P.copySel = function () {
    var g = this.glyph(), cis = {}; var keys = this.selKeys(); keys.forEach(function (k) { cis[k.split(':')[0]] = 1; });
    var cs = g.contours.filter(function (_, ci) { return !keys.length || cis[ci]; });
    P.clipboard = JSON.stringify(cs); return cs.length;
  };
  P.paste = function () {
    if (!P.clipboard) return 0; var g = this.glyph(); this.begin(); var cs = JSON.parse(P.clipboard); cs.forEach(function (c) { g.contours.push(c); }); this.sel = {}; this.end(); this.draw(); return cs.length;
  };

  /* افزودن نقطه در نقاط حدی x/y هر قطعهٔ درجه‌دو (رعایت قواعد خوب طراحی فونت) */
  function addExtremaTo(g) {
    g.contours = g.contours.map(function (c) {
      var out = [], n = c.length;
      for (var i = 0; i < n; i++) {
        var a = c[i]; out.push(a);
        if (!a.on) continue; var b = c[(i + 1) % n];
        if (b.on) continue; var e = c[(i + 2) % n], ts = [];
        [['x'], ['y']].forEach(function (ax) { var k = ax[0], den = a[k] - 2 * b[k] + e[k]; if (den !== 0) { var t = (a[k] - b[k]) / den; if (t > 0.02 && t < 0.98) ts.push(t); } });
        if (!ts.length) continue; ts.sort(function (p, q) { return p - q; });
        var cur = { a: a, c: b, e: e }, prev = 0;
        ts.forEach(function (t) {
          var tt = (t - prev) / (1 - prev), A = cur.a, C = cur.c, E = cur.e;
          var c1 = { x: A.x + (C.x - A.x) * tt, y: A.y + (C.y - A.y) * tt }, c2 = { x: C.x + (E.x - C.x) * tt, y: C.y + (E.y - C.y) * tt };
          var m = { x: c1.x + (c2.x - c1.x) * tt, y: c1.y + (c2.y - c1.y) * tt };
          out.push({ x: Math.round(c1.x), y: Math.round(c1.y), on: false }, { x: Math.round(m.x), y: Math.round(m.y), on: true });
          cur = { a: m, c: c2, e: E }; prev = t;
        });
        out.push({ x: Math.round(cur.c.x), y: Math.round(cur.c.y), on: false });
        c[(i + 1) % n] = c[(i + 1) % n]; // نقطهٔ کنترل اصلی جایگزین شد
        i++;                              // نقطهٔ off اصلی را رد کن
      }
      return out;
    });
    normalizeGlyph(g);
  }
  function signedArea(c) { var s = 0, n = c.length; for (var i = 0; i < n; i++) { var a = c[i], b = c[(i + 1) % n]; s += a.x * b.y - b.x * a.y; } return s / 2; }

  FS.editor = { GlyphEditor: GlyphEditor, snap: snap, restore: restore, normalizeGlyph: normalizeGlyph, addExtrema: addExtremaTo, signedArea: signedArea };
  if (typeof module !== 'undefined') module.exports = FS;
})(typeof window !== 'undefined' ? window : globalThis);
