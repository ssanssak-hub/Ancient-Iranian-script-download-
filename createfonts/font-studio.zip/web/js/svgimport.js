/* ورودی مسیر SVG (d=…) و فایل .svg ← contourهای درجه‌دو */
(function (root) {
  'use strict';
  var FS = root.FS = root.FS || {};
  function tokens(d) { var re = /([MmLlHhVvCcSsQqTtAaZz])|(-?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)/g, m, out = []; while ((m = re.exec(d))) out.push(m[1] || parseFloat(m[2])); return out; }
  function arcToCubics(x1, y1, rx, ry, phi, fa, fs, x2, y2) {
    if (rx === 0 || ry === 0) return [[x1, y1, x2, y2, x2, y2]];
    var s = Math.sin(phi * Math.PI / 180), c = Math.cos(phi * Math.PI / 180), dx = (x1 - x2) / 2, dy = (y1 - y2) / 2;
    var xp = c * dx + s * dy, yp = -s * dx + c * dy; rx = Math.abs(rx); ry = Math.abs(ry);
    var l = xp * xp / (rx * rx) + yp * yp / (ry * ry); if (l > 1) { rx *= Math.sqrt(l); ry *= Math.sqrt(l); }
    var sq = Math.max(0, (rx * rx * ry * ry - rx * rx * yp * yp - ry * ry * xp * xp) / (rx * rx * yp * yp + ry * ry * xp * xp)), co = (fa === fs ? -1 : 1) * Math.sqrt(sq);
    var cxp = co * rx * yp / ry, cyp = -co * ry * xp / rx, cx = c * cxp - s * cyp + (x1 + x2) / 2, cy = s * cxp + c * cyp + (y1 + y2) / 2;
    function ang(ux, uy, vx, vy) { var a = Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy); return a; }
    var th1 = ang(1, 0, (xp - cxp) / rx, (yp - cyp) / ry), dth = ang((xp - cxp) / rx, (yp - cyp) / ry, (-xp - cxp) / rx, (-yp - cyp) / ry);
    if (!fs && dth > 0) dth -= 2 * Math.PI; else if (fs && dth < 0) dth += 2 * Math.PI;
    var n = Math.ceil(Math.abs(dth) / (Math.PI / 2)), res = [], d = dth / n, t = 4 / 3 * Math.tan(d / 4);
    for (var i = 0; i < n; i++) {
      var a1 = th1 + i * d, a2 = a1 + d, c1 = Math.cos(a1), s1 = Math.sin(a1), c2 = Math.cos(a2), s2 = Math.sin(a2);
      function P(px, py) { return [c * rx * px - s * ry * py + cx, s * rx * px + c * ry * py + cy]; }
      var p1 = P(c1 - t * s1, s1 + t * c1), p2 = P(c2 + t * s2, s2 - t * c2), p3 = P(c2, s2); res.push([p1[0], p1[1], p2[0], p2[1], p3[0], p3[1]]);
    }
    return res;
  }
  /* خروجی: آرایه‌ای از contour با نقاط {x,y,t:'m'|'l'|'c'} (محور y رو به پایین، مثل SVG) */
  function parsePath(d) {
    var t = tokens(d), i = 0, cmd = '', x = 0, y = 0, sx = 0, sy = 0, lc = null, lq = null, out = [], cur = null;
    function num() { return t[i++]; }
    function mv(nx, ny) { if (cur && cur.length > 1) out.push(cur); x = sx = nx; y = sy = ny; cur = [{ x: x, y: y, t: 'm' }]; }
    function ln(nx, ny) { if (!cur) mv(x, y); x = nx; y = ny; cur.push({ x: x, y: y, t: 'l' }); }
    function cu(a, b, c2, d2, e, f) { if (!cur) mv(x, y); cur.push({ x: a, y: b, t: 'c' }, { x: c2, y: d2, t: 'c' }, { x: e, y: f, t: 'c' }); lc = [c2, d2]; x = e; y = f; }
    while (i < t.length) {
      if (typeof t[i] === 'string') cmd = t[i++];
      var rel = cmd === cmd.toLowerCase(), C = cmd.toUpperCase(), ox = rel ? x : 0, oy = rel ? y : 0, prevC = lc, prevQ = lq; lc = null; lq = null;
      if (C === 'Z') { if (cur) { out.push(cur); cur = null; } x = sx; y = sy; if (typeof t[i] !== 'string' && i < t.length) cmd = 'L'; continue; }
      if (C === 'M') { mv(num() + ox, num() + oy); cmd = rel ? 'l' : 'L'; }
      else if (C === 'L') ln(num() + ox, num() + oy);
      else if (C === 'H') ln(num() + ox, y);
      else if (C === 'V') ln(x, num() + oy);
      else if (C === 'C') { var a = num() + ox, b = num() + oy, c3 = num() + ox, d3 = num() + oy, e = num() + ox, f = num() + oy; cu(a, b, c3, d3, e, f); }
      else if (C === 'S') { var r1 = prevC ? [2 * x - prevC[0], 2 * y - prevC[1]] : [x, y], c4 = num() + ox, d4 = num() + oy, e4 = num() + ox, f4 = num() + oy; cu(r1[0], r1[1], c4, d4, e4, f4); }
      else if (C === 'Q' || C === 'T') {
        var qx, qy; if (C === 'Q') { qx = num() + ox; qy = num() + oy; } else { qx = prevQ ? 2 * x - prevQ[0] : x; qy = prevQ ? 2 * y - prevQ[1] : y; }
        var ex = num() + ox, ey = num() + oy, x0 = x, y0 = y;
        cu(x0 + 2 / 3 * (qx - x0), y0 + 2 / 3 * (qy - y0), ex + 2 / 3 * (qx - ex), ey + 2 / 3 * (qy - ey), ex, ey); lc = null; lq = [qx, qy];
      } else if (C === 'A') {
        var rx = num(), ry = num(), ph = num(), fa = num(), fs = num(), ax = num() + ox, ay = num() + oy;
        arcToCubics(x, y, rx, ry, ph, fa, fs, ax, ay).forEach(function (s) { cu(s[0], s[1], s[2], s[3], s[4], s[5]); }); lc = null;
      } else { i++; }
    }
    if (cur && cur.length > 1) out.push(cur);
    return out;
  }
  /* همهٔ <path d> و شکل‌های ساده را از متن SVG می‌گیرد */
  function pathsFromSvg(text) {
    var ds = [], re = /<path\b[^>]*\sd\s*=\s*("([^"]*)"|'([^']*)')/gi, m;
    while ((m = re.exec(text))) ds.push(m[2] || m[3]);
    var rr = /<rect\b([^>]*)>/gi; while ((m = rr.exec(text))) { var a = m[1], g = function (k) { var q = new RegExp('\\b' + k + '\\s*=\\s*"([^"]*)"').exec(a); return q ? parseFloat(q[1]) : 0; }; ds.push('M' + g('x') + ' ' + g('y') + 'h' + g('width') + 'v' + g('height') + 'h' + (-g('width')) + 'z'); }
    var cr = /<circle\b([^>]*)>/gi; while ((m = cr.exec(text))) { var a2 = m[1], g2 = function (k) { var q = new RegExp('\\b' + k + '\\s*=\\s*"([^"]*)"').exec(a2); return q ? parseFloat(q[1]) : 0; }, cx = g2('cx'), cy = g2('cy'), r = g2('r'); ds.push('M' + (cx - r) + ' ' + cy + 'a' + r + ' ' + r + ' 0 1 0 ' + 2 * r + ' 0a' + r + ' ' + r + ' 0 1 0 ' + (-2 * r) + ' 0z'); }
    return ds.join(' ');
  }
  /* d ← contourهای فونت: ارتفاع کل = height واحد، y برعکس، پایین شکل روی y=yBottom */
  function toGlyphContours(d, height, yBottom, lsb) {
    var cs = parsePath(d); if (!cs.length) return { contours: [], width: 0 };
    var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    cs.forEach(function (c) { c.forEach(function (p) { x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y); }); });
    var k = height / Math.max(1e-6, (y1 - y0));
    var mapped = cs.map(function (c) { return c.map(function (p) { return { x: (p.x - x0) * k + lsb, y: (y1 - p.y) * k + yBottom, t: p.t, on: p.t !== 'c' }; }); });
    var quads = FS.cff.toQuadratic(mapped.map(function (c) { return c.map(function (p) { return { x: p.x, y: p.y, on: p.on, t: p.t }; }); }));
    return { contours: quads, width: (x1 - x0) * k };
  }
  FS.svg = { parsePath: parsePath, pathsFromSvg: pathsFromSvg, toGlyphContours: toGlyphContours };
  if (typeof module !== 'undefined') module.exports = FS;
})(typeof window !== 'undefined' ? window : globalThis);
