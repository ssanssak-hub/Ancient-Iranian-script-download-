/* هستهٔ خواندن/نوشتن فونت (SFNT): TTF / OTF(CFF) / TTC(اولین فونت) / WOFF1
   مدل داخلی: همهٔ ترسیم‌ها به منحنی درجه‌دو (TrueType) تبدیل می‌شوند. */
(function (root) {
  'use strict';
  var FS = root.FS = root.FS || {};
  var td = new TextDecoder('utf-8');

  function tagStr(dv, o) { return String.fromCharCode(dv.getUint8(o), dv.getUint8(o + 1), dv.getUint8(o + 2), dv.getUint8(o + 3)); }
  function tagBytes(t) { return [t.charCodeAt(0), t.charCodeAt(1), t.charCodeAt(2), t.charCodeAt(3)]; }

  /* ---------- جدول‌ها ---------- */
  function readTables(buf) {
    var u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    var dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    var base = 0;
    var sig = tagStr(dv, 0);
    if (sig === 'ttcf') base = dv.getUint32(12);
    var sv = dv.getUint32(base);
    var kind;
    if (sv === 0x00010000 || tagStr(dv, base) === 'true') kind = 'ttf';
    else if (tagStr(dv, base) === 'OTTO') kind = 'cff';
    else throw new Error('این فایل SFNT (TTF/OTF) نیست');
    var n = dv.getUint16(base + 4), tables = {};
    for (var i = 0; i < n; i++) {
      var r = base + 12 + i * 16, tag = tagStr(dv, r), off = dv.getUint32(r + 8), len = dv.getUint32(r + 12);
      if (off + len > u8.byteLength) throw new Error('جدول ' + tag + ' خارج از فایل است');
      tables[tag] = u8.subarray(off, off + len);
    }
    return { kind: kind, tables: tables };
  }

  /* ---------- ساخت فایل از جدول‌ها ---------- */
  function checksum(u8) {
    var s = 0, n = u8.length, i = 0;
    var dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    for (; i + 4 <= n; i += 4) s = (s + dv.getUint32(i)) >>> 0;
    if (i < n) { var v = 0; for (var k = 0; k < 4; k++) v = (v << 8) | (i + k < n ? u8[i + k] : 0); s = (s + (v >>> 0)) >>> 0; }
    return s >>> 0;
  }
  function buildSfnt(tables, flavor) {
    var tags = Object.keys(tables).sort();
    var n = tags.length, hdr = 12 + 16 * n, total = hdr;
    tags.forEach(function (t) { total += (tables[t].length + 3) & ~3; });
    var out = new Uint8Array(total), dv = new DataView(out.buffer);
    dv.setUint32(0, flavor === 'cff' ? 0x4F54544F : 0x00010000);
    var sr = 1, es = 0; while (sr * 2 <= n) { sr *= 2; es++; }
    dv.setUint16(4, n); dv.setUint16(6, sr * 16); dv.setUint16(8, es); dv.setUint16(10, n * 16 - sr * 16);
    var off = hdr, headOff = -1;
    tags.forEach(function (t, i) {
      var d = tables[t], r = 12 + i * 16;
      out.set(tagBytes(t), r);
      dv.setUint32(r + 4, checksum(d)); dv.setUint32(r + 8, off); dv.setUint32(r + 12, d.length);
      out.set(d, off);
      if (t === 'head') headOff = off;
      off += (d.length + 3) & ~3;
    });
    if (headOff >= 0) { dv.setUint32(headOff + 8, 0); dv.setUint32(headOff + 8, (0xB1B0AFBA - checksum(out)) >>> 0); }
    return out;
  }

  /* ---------- نام‌ها ---------- */
  function decodeName(u8, pid) {
    if (pid === 3 || pid === 0) { var s = ''; for (var i = 0; i + 1 < u8.length; i += 2) s += String.fromCharCode((u8[i] << 8) | u8[i + 1]); return s; }
    var t = ''; for (var j = 0; j < u8.length; j++) t += String.fromCharCode(u8[j]); return t;
  }
  function parseName(t) {
    var res = [];
    if (!t) return res;
    var dv = new DataView(t.buffer, t.byteOffset, t.byteLength), fmt = dv.getUint16(0), cnt = dv.getUint16(2), so = dv.getUint16(4);
    for (var i = 0; i < cnt; i++) {
      var r = 6 + i * 12, pid = dv.getUint16(r), eid = dv.getUint16(r + 2), lid = dv.getUint16(r + 4), nid = dv.getUint16(r + 6), len = dv.getUint16(r + 8), off = dv.getUint16(r + 10);
      if (pid !== 3 && pid !== 0 && !(pid === 1 && eid === 0 && lid === 0)) continue;
      res.push({ pid: pid, eid: eid, lid: lid, nid: nid, str: decodeName(t.subarray(so + off, so + off + len), pid) });
    }
    return res;
  }
  function buildName(recs) {
    recs = recs.filter(function (r) { return r.str !== '' && r.str != null; }).map(function (r) {
      var pid = r.pid === 1 ? 3 : r.pid, eid = r.pid === 1 ? 1 : r.eid, lid = r.pid === 1 ? 0x409 : r.lid;
      return { pid: pid, eid: eid, lid: lid, nid: r.nid, str: r.str };
    });
    var seen = {}; recs = recs.filter(function (r) { var k = [r.pid, r.eid, r.lid, r.nid].join(); if (seen[k]) return false; seen[k] = 1; return true; });
    recs.sort(function (a, b) { return a.pid - b.pid || a.eid - b.eid || a.lid - b.lid || a.nid - b.nid; });
    var strs = [], size = 0;
    recs.forEach(function (r) { var b = new Uint8Array(r.str.length * 2); for (var i = 0; i < r.str.length; i++) { var c = r.str.charCodeAt(i); b[i * 2] = c >> 8; b[i * 2 + 1] = c & 255; } r.b = b; r.off = size; size += b.length; });
    var hdr = 6 + recs.length * 12, out = new Uint8Array(hdr + size), dv = new DataView(out.buffer);
    dv.setUint16(2, recs.length); dv.setUint16(4, hdr);
    recs.forEach(function (r, i) { var o = 6 + i * 12; dv.setUint16(o, r.pid); dv.setUint16(o + 2, r.eid); dv.setUint16(o + 4, r.lid); dv.setUint16(o + 6, r.nid); dv.setUint16(o + 8, r.b.length); dv.setUint16(o + 10, r.off); out.set(r.b, hdr + r.off); });
    return out;
  }

  /* ---------- cmap ---------- */
  function parseCmap(t) {
    var map = {};
    if (!t) return map;
    var dv = new DataView(t.buffer, t.byteOffset, t.byteLength), n = dv.getUint16(2), best = -1, bestScore = -1;
    for (var i = 0; i < n; i++) {
      var pid = dv.getUint16(4 + i * 8), eid = dv.getUint16(6 + i * 8), off = dv.getUint32(8 + i * 8);
      var score = (pid === 3 && eid === 10) ? 5 : (pid === 0 && (eid === 4 || eid === 6)) ? 4 : (pid === 3 && eid === 1) ? 3 : (pid === 0) ? 2 : (pid === 3 && eid === 0) ? 1 : 0;
      if (score > bestScore) { bestScore = score; best = off; }
    }
    if (best < 0) return map;
    var f = dv.getUint16(best);
    if (f === 4) {
      var sc = dv.getUint16(best + 6) / 2, endO = best + 14, startO = endO + sc * 2 + 2, deltaO = startO + sc * 2, rangeO = deltaO + sc * 2;
      for (var s = 0; s < sc; s++) {
        var end = dv.getUint16(endO + s * 2), st = dv.getUint16(startO + s * 2), dl = dv.getInt16(deltaO + s * 2), ro = dv.getUint16(rangeO + s * 2);
        for (var c = st; c <= end && c !== 0xFFFF; c++) {
          var g;
          if (ro === 0) g = (c + dl) & 0xFFFF;
          else { var p = rangeO + s * 2 + ro + (c - st) * 2; if (p + 2 > t.length) continue; g = dv.getUint16(p); if (g) g = (g + dl) & 0xFFFF; }
          if (g) map[c] = g;
        }
      }
    } else if (f === 12) {
      var ng = dv.getUint32(best + 12);
      for (var k = 0; k < ng; k++) { var o = best + 16 + k * 12, sc2 = dv.getUint32(o), ec = dv.getUint32(o + 4), sg = dv.getUint32(o + 8); for (var cc = sc2; cc <= ec && cc - sc2 < 0x20000; cc++) map[cc] = sg + (cc - sc2); }
    } else if (f === 6) {
      var first = dv.getUint16(best + 6), cnt = dv.getUint16(best + 8);
      for (var q = 0; q < cnt; q++) { var gg = dv.getUint16(best + 10 + q * 2); if (gg) map[first + q] = gg; }
    } else if (f === 0) {
      for (var z = 0; z < 256; z++) { var g0 = t[best + 6 + z]; if (g0) map[z] = g0; }
    }
    return map;
  }
  function buildCmap(map) {
    var codes = Object.keys(map).map(Number).sort(function (a, b) { return a - b; });
    var bmp = codes.filter(function (c) { return c < 0xFFFF; }), hasAstral = codes.some(function (c) { return c > 0xFFFF; });
    var segs = [];
    bmp.forEach(function (c) { var g = map[c], l = segs[segs.length - 1]; if (l && c === l.end + 1 && g === l.g0 + (c - l.start)) l.end = c; else segs.push({ start: c, end: c, g0: g }); });
    segs.push({ start: 0xFFFF, end: 0xFFFF, g0: 0, last: true });
    var sc = segs.length, len4 = 16 + sc * 8, f4 = new Uint8Array(len4), d4 = new DataView(f4.buffer);
    var sr = 1, es = 0; while (sr * 2 <= sc) { sr *= 2; es++; }
    d4.setUint16(0, 4); d4.setUint16(2, len4); d4.setUint16(6, sc * 2); d4.setUint16(8, sr * 2); d4.setUint16(10, es); d4.setUint16(12, sc * 2 - sr * 2);
    segs.forEach(function (s, i) {
      d4.setUint16(14 + i * 2, s.end); d4.setUint16(16 + sc * 2 + i * 2, s.start);
      d4.setInt16(16 + sc * 4 + i * 2, s.last ? 1 : ((s.g0 - s.start) << 16 >> 16));
    });
    var sub = [{ pid: 0, eid: 3, data: f4 }, { pid: 3, eid: 1, data: f4 }];
    if (hasAstral) {
      var gr = [];
      codes.forEach(function (c) { var g = map[c], l = gr[gr.length - 1]; if (l && c === l.e + 1 && g === l.g + (c - l.s)) l.e = c; else gr.push({ s: c, e: c, g: g }); });
      var f12 = new Uint8Array(16 + gr.length * 12), d12 = new DataView(f12.buffer);
      d12.setUint16(0, 12); d12.setUint32(4, f12.length); d12.setUint32(12, gr.length);
      gr.forEach(function (r, i) { d12.setUint32(16 + i * 12, r.s); d12.setUint32(20 + i * 12, r.e); d12.setUint32(24 + i * 12, r.g); });
      sub.push({ pid: 0, eid: 4, data: f12 }, { pid: 3, eid: 10, data: f12 });
    }
    var hdr = 4 + sub.length * 8, uniq = [], offs = {};
    var total = hdr; sub.forEach(function (s) { if (uniq.indexOf(s.data) < 0) { uniq.push(s.data); offs[uniq.length - 1] = total; total += s.data.length; } });
    var out = new Uint8Array(total), dv = new DataView(out.buffer);
    dv.setUint16(2, sub.length);
    sub.forEach(function (s, i) { var ui = uniq.indexOf(s.data); dv.setUint16(4 + i * 8, s.pid); dv.setUint16(6 + i * 8, s.eid); dv.setUint32(8 + i * 8, offs[ui]); });
    uniq.forEach(function (d, i) { out.set(d, offs[i]); });
    return out;
  }

  /* ---------- glyf ---------- */
  function parseGlyf(glyf, loca, locFmt, numGlyphs) {
    var ldv = new DataView(loca.buffer, loca.byteOffset, loca.byteLength), gdv = new DataView(glyf.buffer, glyf.byteOffset, glyf.byteLength);
    function off(i) { return locFmt ? ldv.getUint32(i * 4) : ldv.getUint16(i * 2) * 2; }
    var cache = {};
    function one(gid, depth) {
      if (cache[gid]) return cache[gid];
      var s = off(gid), e = off(gid + 1), res = [];
      if (e <= s || s + 10 > glyf.length) return (cache[gid] = res);
      var nc = gdv.getInt16(s), p = s + 10;
      if (nc >= 0) {
        var ends = []; for (var i = 0; i < nc; i++) { ends.push(gdv.getUint16(p)); p += 2; }
        var np = nc ? ends[nc - 1] + 1 : 0, il = gdv.getUint16(p); p += 2 + il;
        var flags = []; while (flags.length < np) { var f = glyf[p++]; flags.push(f); if (f & 8) { var r = glyf[p++]; while (r-- > 0 && flags.length < np) flags.push(f); } }
        var xs = [], ys = [], v = 0;
        for (i = 0; i < np; i++) { f = flags[i]; if (f & 2) { var d = glyf[p++]; v += (f & 16) ? d : -d; } else if (!(f & 16)) { v += gdv.getInt16(p); p += 2; } xs.push(v); }
        v = 0;
        for (i = 0; i < np; i++) { f = flags[i]; if (f & 4) { var d2 = glyf[p++]; v += (f & 32) ? d2 : -d2; } else if (!(f & 32)) { v += gdv.getInt16(p); p += 2; } ys.push(v); }
        var st = 0;
        for (var c = 0; c < nc; c++) { var ct = []; for (i = st; i <= ends[c]; i++) ct.push({ x: xs[i], y: ys[i], on: !!(flags[i] & 1) }); res.push(ct); st = ends[c] + 1; }
      } else if (depth < 8) {
        var more = true;
        while (more) {
          var fl = gdv.getUint16(p), gi = gdv.getUint16(p + 2); p += 4;
          var a1, a2;
          if (fl & 1) { a1 = (fl & 2) ? gdv.getInt16(p) : gdv.getUint16(p); a2 = (fl & 2) ? gdv.getInt16(p + 2) : gdv.getUint16(p + 2); p += 4; }
          else { a1 = (fl & 2) ? gdv.getInt8(p) : glyf[p]; a2 = (fl & 2) ? gdv.getInt8(p + 1) : glyf[p + 1]; p += 2; }
          var a = 1, b = 0, c2 = 0, d3 = 1;
          if (fl & 8) { a = d3 = gdv.getInt16(p) / 16384; p += 2; }
          else if (fl & 0x40) { a = gdv.getInt16(p) / 16384; d3 = gdv.getInt16(p + 2) / 16384; p += 4; }
          else if (fl & 0x80) { a = gdv.getInt16(p) / 16384; b = gdv.getInt16(p + 2) / 16384; c2 = gdv.getInt16(p + 4) / 16384; d3 = gdv.getInt16(p + 6) / 16384; p += 8; }
          var dx = (fl & 2) ? a1 : 0, dy = (fl & 2) ? a2 : 0;
          one(gi, depth + 1).forEach(function (ct) { res.push(ct.map(function (pt) { return { x: Math.round(a * pt.x + c2 * pt.y + dx), y: Math.round(b * pt.x + d3 * pt.y + dy), on: pt.on }; })); });
          more = !!(fl & 0x20);
        }
      }
      return (cache[gid] = res);
    }
    var out = []; for (var g = 0; g < numGlyphs; g++) { try { out.push(one(g, 0).map(function (c) { return c.map(function (p) { return { x: p.x, y: p.y, on: p.on }; }); })); } catch (e) { out.push([]); } }
    return out;
  }
  function bboxOf(contours) {
    var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9, any = false;
    contours.forEach(function (c) { c.forEach(function (p) { any = true; if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x; if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y; }); });
    return any ? { x0: x0, y0: y0, x1: x1, y1: y1 } : null;
  }
  /* نقطهٔ on-curve که دقیقاً وسط دو نقطهٔ off است را حذف می‌کند (کم‌حجم‌تر؛ ظاهر یکی است). */
  function compactContour(c) {
    var n = c.length; if (n < 3) return c;
    var keep = c.map(function () { return true; });
    for (var i = 0; i < n; i++) {
      var p = c[i], a = c[(i + n - 1) % n], b = c[(i + 1) % n];
      if (p.on && !a.on && !b.on && Math.abs(p.x * 2 - a.x - b.x) <= 0 && Math.abs(p.y * 2 - a.y - b.y) <= 0) keep[i] = false;
    }
    var r = c.filter(function (_, i) { return keep[i]; });
    return r.length >= 2 ? r : c;
  }
  function buildGlyf(glyphs) {
    var parts = [], offsets = [0], total = 0, maxPts = 0, maxCont = 0, bb = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 };
    glyphs.forEach(function (g) {
      var cs = g.contours.map(compactContour).filter(function (c) { return c.length >= 2; });
      var b = bboxOf(cs);
      g._bbox = b;
      if (!cs.length || !b) { offsets.push(total); return; }
      var np = 0; cs.forEach(function (c) { np += c.length; });
      maxPts = Math.max(maxPts, np); maxCont = Math.max(maxCont, cs.length);
      bb.x0 = Math.min(bb.x0, b.x0); bb.y0 = Math.min(bb.y0, b.y0); bb.x1 = Math.max(bb.x1, b.x1); bb.y1 = Math.max(bb.y1, b.y1);
      var flags = [], xb = [], yb = [], px = 0, py = 0, ends = [], idx = -1;
      cs.forEach(function (c) { c.forEach(function (p) {
        var f = p.on ? 1 : 0, dx = Math.round(p.x) - px, dy = Math.round(p.y) - py; px = Math.round(p.x); py = Math.round(p.y);
        if (dx === 0) f |= 16; else if (Math.abs(dx) < 256) { f |= 2 | (dx > 0 ? 16 : 0); xb.push(Math.abs(dx)); } else { xb.push((dx >> 8) & 255, dx & 255); }
        if (dy === 0) f |= 32; else if (Math.abs(dy) < 256) { f |= 4 | (dy > 0 ? 32 : 0); yb.push(Math.abs(dy)); } else { yb.push((dy >> 8) & 255, dy & 255); }
        flags.push(f); idx++; }); ends.push(idx); });
      var fl = []; for (var i = 0; i < flags.length;) { var j = i; while (j + 1 < flags.length && flags[j + 1] === flags[i] && j - i < 255) j++; if (j > i) { fl.push(flags[i] | 8, j - i); } else fl.push(flags[i]); i = j + 1; }
      var size = 10 + cs.length * 2 + 2 + fl.length + xb.length + yb.length, buf = new Uint8Array(size), dv = new DataView(buf.buffer);
      dv.setInt16(0, cs.length); dv.setInt16(2, b.x0); dv.setInt16(4, b.y0); dv.setInt16(6, b.x1); dv.setInt16(8, b.y1);
      var p0 = 10; ends.forEach(function (e) { dv.setUint16(p0, e); p0 += 2; }); dv.setUint16(p0, 0); p0 += 2;
      buf.set(fl, p0); p0 += fl.length; buf.set(xb, p0); p0 += xb.length; buf.set(yb, p0);
      var pad = (4 - size % 4) % 4; parts.push(buf); if (pad) parts.push(new Uint8Array(pad));
      total += size + pad; offsets.push(total);
    });
    var glyf = new Uint8Array(total), o = 0; parts.forEach(function (p) { glyf.set(p, o); o += p.length; });
    var long = total > 0x1FFFE, loca = new Uint8Array((glyphs.length + 1) * (long ? 4 : 2)), ld = new DataView(loca.buffer);
    offsets.forEach(function (v, i) { if (long) ld.setUint32(i * 4, v); else ld.setUint16(i * 2, v / 2); });
    if (bb.x0 > bb.x1) bb = { x0: 0, y0: 0, x1: 0, y1: 0 };
    return { glyf: glyf, loca: loca, long: long, maxPts: maxPts, maxCont: maxCont, bbox: bb };
  }

  /* ---------- post ---------- */
  function parsePost(t, numGlyphs) {
    var info = { italicAngle: 0, underlinePosition: -100, underlineThickness: 50, isFixedPitch: 0 }, names = null;
    if (!t || t.length < 32) return { info: info, names: names };
    var dv = new DataView(t.buffer, t.byteOffset, t.byteLength), fmt = dv.getUint32(0);
    info.italicAngle = dv.getInt32(4) / 65536; info.underlinePosition = dv.getInt16(8); info.underlineThickness = dv.getInt16(10); info.isFixedPitch = dv.getUint32(12);
    if (fmt === 0x00020000 && t.length > 34) {
      var n = dv.getUint16(32), idx = [], p = 34; for (var i = 0; i < n; i++) { idx.push(dv.getUint16(p)); p += 2; }
      var strs = []; while (p < t.length) { var l = t[p++]; var s = ''; for (var k = 0; k < l && p < t.length; k++) s += String.fromCharCode(t[p++]); strs.push(s); }
      names = idx.map(function (ix) { return ix >= 258 ? (strs[ix - 258] || null) : ((FS.MAC_NAMES && FS.MAC_NAMES[ix]) || null); });
    }
    return { info: info, names: names };
  }
  function buildPost(font) {
    var names = font.glyphs.map(function (g) { return g.name; }), strs = [], idx = [];
    var mac = {}; (FS.MAC_NAMES || []).forEach(function (n, i) { mac[n] = i; });
    names.forEach(function (n, i) { if (mac[n] !== undefined && (i > 0 || n === '.notdef')) { idx.push(mac[n]); } else { idx.push(258 + strs.length); strs.push(n); } });
    var sl = 0; strs.forEach(function (s) { sl += 1 + s.length; });
    var out = new Uint8Array(34 + idx.length * 2 + sl), dv = new DataView(out.buffer), p = font.post;
    dv.setUint32(0, 0x00020000); dv.setInt32(4, Math.round(p.italicAngle * 65536)); dv.setInt16(8, p.underlinePosition); dv.setInt16(10, p.underlineThickness); dv.setUint32(12, p.isFixedPitch ? 1 : 0);
    dv.setUint16(32, idx.length); idx.forEach(function (v, i) { dv.setUint16(34 + i * 2, v); });
    var o = 34 + idx.length * 2; strs.forEach(function (s) { out[o++] = s.length; for (var i = 0; i < s.length; i++) out[o++] = s.charCodeAt(i) & 127; });
    return out;
  }

  /* ---------- OS/2 ---------- */
  var UNI_RANGES = [[0,0x20,0x7E],[1,0xA0,0xFF],[2,0x100,0x17F],[3,0x180,0x24F],[4,0x250,0x2AF],[5,0x2B0,0x2FF],[6,0x300,0x36F],[7,0x370,0x3FF],[9,0x400,0x52F],[10,0x530,0x58F],[11,0x590,0x5FF],[12,0xA500,0xA63F],[13,0x600,0x6FF],[14,0x700,0x74F],[15,0x780,0x7BF],[16,0x900,0x97F],[17,0x980,0x9FF],[21,0xE00,0xE7F],[27,0x10A0,0x10FF],[29,0x1E00,0x1EFF],[31,0x2000,0x206F],[32,0x2070,0x209F],[33,0x20A0,0x20CF],[35,0x2100,0x214F],[36,0x2190,0x21FF],[37,0x2200,0x22FF],[43,0x2500,0x257F],[45,0x25A0,0x25FF],[46,0x2600,0x26FF],[48,0x3000,0x303F],[56,0xAC00,0xD7AF],[60,0xE000,0xF8FF],[62,0xFB50,0xFDFF],[63,0xFE20,0xFE2F],[64,0xFE30,0xFE4F],[67,0xFE70,0xFEFF],[69,0x0750,0x077F],[58,0x10000,0x1007F]];
  function buildOS2(font, cmap, keepLayout) {
    var o = font.os2, out = new Uint8Array(96), dv = new DataView(out.buffer), upm = font.upm;
    var codes = Object.keys(cmap).map(Number), first = 0xFFFF, last = 0, ur = [0, 0, 0, 0], sum = 0, cnt = 0;
    codes.forEach(function (c) { var cc = Math.min(c, 0xFFFF); if (cc < first) first = cc; if (cc > last) last = cc; UNI_RANGES.forEach(function (r) { if (c >= r[1] && c <= r[2]) ur[r[0] >> 5] = (ur[r[0] >> 5] | (1 << (r[0] & 31))) >>> 0; }); });
    font.glyphs.forEach(function (g) { if (g.adv > 0) { sum += g.adv; cnt++; } });
    if (codes.some(function (c) { return c > 0xFFFF; })) ur[1] = (ur[1] | (1 << (57 - 32))) >>> 0;
    var fsel = 0; if (font.head.macStyle & 2) fsel |= 1; if (font.head.macStyle & 1) fsel |= 32; if (!(fsel & 33)) fsel |= 64; if (o.useTypo) fsel |= 128; if (o.wws) fsel |= 256;
    dv.setUint16(0, 4); dv.setInt16(2, cnt ? Math.round(sum / cnt) : 0); dv.setUint16(4, o.weight); dv.setUint16(6, o.width); dv.setUint16(8, o.fsType);
    dv.setInt16(10, Math.round(upm * .65)); dv.setInt16(12, Math.round(upm * .6)); dv.setInt16(14, 0); dv.setInt16(16, Math.round(upm * .14));
    dv.setInt16(18, Math.round(upm * .65)); dv.setInt16(20, Math.round(upm * .6)); dv.setInt16(22, 0); dv.setInt16(24, Math.round(upm * .48));
    dv.setInt16(26, Math.round(upm * .05)); dv.setInt16(28, Math.round(upm * .26)); dv.setInt16(30, o.familyClass || 0);
    for (var i = 0; i < 10; i++) out[32 + i] = (o.panose && o.panose[i]) || 0;
    for (var u = 0; u < 4; u++) dv.setUint32(42 + u * 4, (ur[u] | ((o.unicodeRange && o.unicodeRange[u]) || 0)) >>> 0);
    var v = (o.vendor || 'NONE'); for (var k = 0; k < 4; k++) out[58 + k] = v.charCodeAt(k) || 32;
    dv.setUint16(62, fsel); dv.setUint16(64, first); dv.setUint16(66, last);
    dv.setInt16(68, o.typoAsc); dv.setInt16(70, o.typoDesc); dv.setInt16(72, o.typoGap); dv.setUint16(74, o.winAsc); dv.setUint16(76, o.winDesc);
    dv.setUint32(78, (o.codePage && o.codePage[0]) || 1); dv.setUint32(82, (o.codePage && o.codePage[1]) || 0);
    dv.setInt16(86, o.xHeight); dv.setInt16(88, o.capHeight); dv.setUint16(90, 0); dv.setUint16(92, 32); dv.setUint16(94, keepLayout ? 16 : 1);
    return out;
  }
  function parseOS2(t, upm) {
    var o = { weight: 400, width: 5, fsType: 0, typoAsc: 0, typoDesc: 0, typoGap: 0, winAsc: 0, winDesc: 0, xHeight: 0, capHeight: 0, useTypo: false, wws: false, vendor: 'NONE', panose: [], unicodeRange: [0, 0, 0, 0], codePage: [1, 0], familyClass: 0 };
    if (!t || t.length < 78) return o;
    var dv = new DataView(t.buffer, t.byteOffset, t.byteLength), ver = dv.getUint16(0);
    o.weight = dv.getUint16(4); o.width = dv.getUint16(6); o.fsType = dv.getUint16(8); o.familyClass = dv.getInt16(30);
    for (var i = 0; i < 10; i++) o.panose.push(t[32 + i]);
    for (var u = 0; u < 4; u++) o.unicodeRange.push(0); o.unicodeRange = [0, 0, 0, 0].map(function (_, k) { return dv.getUint32(42 + k * 4); });
    o.vendor = String.fromCharCode(t[58], t[59], t[60], t[61]); var fs = dv.getUint16(62); o.useTypo = !!(fs & 128); o.wws = !!(fs & 256);
    o.typoAsc = dv.getInt16(68); o.typoDesc = dv.getInt16(70); o.typoGap = dv.getInt16(72); o.winAsc = dv.getUint16(74); o.winDesc = dv.getUint16(76);
    if (t.length >= 86) o.codePage = [dv.getUint32(78), dv.getUint32(82)];
    if (ver >= 2 && t.length >= 90) { o.xHeight = dv.getInt16(86); o.capHeight = dv.getInt16(88); }
    return o;
  }

  /* ---------- بارگذاری کامل ---------- */
  var DROP_ON_ANY = ['glyf', 'loca', 'head', 'hhea', 'hmtx', 'maxp', 'cmap', 'name', 'post', 'OS/2', 'fpgm', 'prep', 'cvt ', 'hdmx', 'VDMX', 'LTSH', 'DSIG', 'CFF ', 'CFF2', 'VORG', 'kern_', 'fvar', 'gvar', 'avar', 'HVAR', 'MVAR', 'STAT', 'cvar', 'vhea', 'vmtx', 'EBDT', 'EBLC', 'EBSC', 'CBDT', 'CBLC', 'sbix', 'COLR', 'CPAL', 'SVG ', 'PCLT'];
  function loadFont(buf) {
    var rt = readTables(buf), T = rt.tables;
    if (!T.head || !T.maxp || !T.hhea || !T.hmtx) throw new Error('جدول‌های اصلی فونت ناقص است');
    var hd = new DataView(T.head.buffer, T.head.byteOffset, T.head.byteLength);
    var upm = hd.getUint16(18), locFmt = hd.getInt16(50), numGlyphs = new DataView(T.maxp.buffer, T.maxp.byteOffset, T.maxp.byteLength).getUint16(4);
    var hh = new DataView(T.hhea.buffer, T.hhea.byteOffset, T.hhea.byteLength), nh = hh.getUint16(34);
    var hm = new DataView(T.hmtx.buffer, T.hmtx.byteOffset, T.hmtx.byteLength);
    var contours, warnings = [];
    if (rt.kind === 'ttf') {
      if (!T.glyf || !T.loca) throw new Error('جدول glyf/loca در فونت نیست (فونت بیت‌مپی/رنگی پشتیبانی نمی‌شود)');
      contours = parseGlyf(T.glyf, T.loca, locFmt, numGlyphs);
    } else {
      if (!FS.cff) throw new Error('پشتیبانی CFF بارگذاری نشده');
      var c = FS.cff.parse(T['CFF ']); contours = c.glyphs.map(function (g) { return FS.cff.toQuadratic(g.contours); });
      warnings.push('فونت OTF/CFF بود: ترسیم‌ها به منحنی درجه‌دو (TrueType) تبدیل شد؛ خروجی TTF خواهد بود.');
    }
    var cmap = parseCmap(T.cmap), uni = {};
    Object.keys(cmap).forEach(function (cp) { var g = cmap[cp]; (uni[g] = uni[g] || []).push(+cp); });
    var post = parsePost(T.post, numGlyphs);
    var glyphs = [];
    for (var g = 0; g < numGlyphs; g++) {
      var adv = g < nh ? hm.getUint16(g * 4) : hm.getUint16((nh - 1) * 4);
      var nm = post.names && post.names[g] ? post.names[g] : null;
      if (!nm) nm = g === 0 ? '.notdef' : (uni[g] ? 'uni' + uni[g][0].toString(16).toUpperCase().padStart(4, '0') : 'glyph' + g);
      glyphs.push({ name: nm, adv: adv, contours: contours[g] || [], unicodes: (uni[g] || []).sort(function (a, b) { return a - b; }) });
    }
    uniqueNames(glyphs);
    var hdr = { macStyle: hd.getUint16(44), flags: hd.getUint16(16), revision: hd.getInt32(4) / 65536, created: [hd.getUint32(20), hd.getUint32(24)], lowestRecPPEM: hd.getUint16(46) };
    var os2 = parseOS2(T['OS/2'], upm);
    var font = {
      upm: upm, glyphs: glyphs, names: parseName(T.name), head: hdr, os2: os2, post: post.info,
      hhea: { asc: hh.getInt16(4), desc: hh.getInt16(6), gap: hh.getInt16(8) },
      extra: {}, flavor: rt.kind, origGlyphCount: numGlyphs, origNames: glyphs.map(function (g) { return g.name; }), warnings: warnings
    };
    if (!os2.typoAsc && !os2.winAsc) { os2.typoAsc = font.hhea.asc; os2.typoDesc = font.hhea.desc; os2.winAsc = Math.max(0, font.hhea.asc); os2.winDesc = Math.abs(font.hhea.desc); }
    if (T.fvar) font.warnings.push('فونت متغیر (variable) بود: نمونهٔ پیش‌فرض آن ویرایش و به فونت ثابت تبدیل می‌شود.');
    if (T.fpgm || T.prep || T.cvt) font.warnings.push('دستورهای هینتینگ TrueType حذف می‌شود (روی اندروید و وب لازم نیست).');
    Object.keys(T).forEach(function (t) { if (DROP_ON_ANY.indexOf(t) < 0) font.extra[t] = new Uint8Array(T[t]); });
    if (T.kern && !font.extra.kern) font.extra.kern = new Uint8Array(T.kern);
    font.snapshot = glyphs.map(function (g) { return JSON.parse(JSON.stringify(g.contours)); });
    return font;
  }
  function uniqueNames(glyphs) {
    var seen = {};
    glyphs.forEach(function (g, i) {
      var n = (g.name || 'glyph' + i).replace(/[^A-Za-z0-9._]/g, '_').slice(0, 63) || 'glyph' + i;
      if (/^[0-9]/.test(n) && i > 0) n = 'g' + n;
      if (i === 0) n = '.notdef';
      var base = n, k = 1; while (seen[n]) n = base + '.' + (k++);
      seen[n] = 1; g.name = n;
    });
  }

  /* ---------- ذخیره ---------- */
  function layoutStable(font) {
    /* گلیف‌های تازه فقط به انتها اضافه شده باشند (شمارهٔ گلیف‌های قبلی تغییر نکند) */
    if (font.glyphs.length < font.origGlyphCount || font.reordered) return false;
    for (var i = 0; i < font.origGlyphCount; i++) if (font.origIds && font.origIds[i] !== i) return false;
    return true;
  }
  function buildFont(font) {
    var T = {}, cmap = {}, upm = font.upm;
    uniqueNames(font.glyphs);
    font.glyphs.forEach(function (g, i) { (g.unicodes || []).forEach(function (u) { cmap[u] = i; }); });
    var gl = buildGlyf(font.glyphs);
    T.glyf = gl.glyf; T.loca = gl.loca;
    var n = font.glyphs.length, hmtx = new Uint8Array(n * 4), hv = new DataView(hmtx.buffer), minL = 1e9, minR = 1e9, maxAdv = 0, maxExt = 0;
    font.glyphs.forEach(function (g, i) {
      var b = g._bbox, adv = Math.max(0, Math.round(g.adv)), lsb = b ? b.x0 : 0;
      hv.setUint16(i * 4, Math.min(adv, 65535)); hv.setInt16(i * 4 + 2, lsb);
      if (b) { minL = Math.min(minL, lsb); minR = Math.min(minR, adv - b.x1); maxExt = Math.max(maxExt, b.x1); }
      maxAdv = Math.max(maxAdv, adv);
    });
    T.hmtx = hmtx;
    var head = new Uint8Array(54), hd = new DataView(head.buffer), now = Math.floor(Date.now() / 1000) + 2082844800;
    hd.setUint32(0, 0x00010000); hd.setInt32(4, Math.round((font.head.revision || 1) * 65536)); hd.setUint32(12, 0x5F0F3CF5);
    hd.setUint16(16, (font.head.flags | 1 | 2) & 0xFFFF); hd.setUint16(18, upm);
    hd.setUint32(20, font.head.created[0] || 0); hd.setUint32(24, font.head.created[1] || now); hd.setUint32(28, 0); hd.setUint32(32, now);
    hd.setInt16(36, gl.bbox.x0); hd.setInt16(38, gl.bbox.y0); hd.setInt16(40, gl.bbox.x1); hd.setInt16(42, gl.bbox.y1);
    hd.setUint16(44, font.head.macStyle || 0); hd.setUint16(46, font.head.lowestRecPPEM || 8); hd.setInt16(48, 2); hd.setInt16(50, gl.long ? 1 : 0); hd.setInt16(52, 0);
    T.head = head;
    var hhea = new Uint8Array(36), hh = new DataView(hhea.buffer);
    hh.setUint32(0, 0x00010000); hh.setInt16(4, font.hhea.asc); hh.setInt16(6, font.hhea.desc); hh.setInt16(8, font.hhea.gap);
    hh.setUint16(10, maxAdv); hh.setInt16(12, minL > 1e8 ? 0 : minL); hh.setInt16(14, minR > 1e8 ? 0 : minR); hh.setInt16(16, maxExt);
    var ia = font.post.italicAngle || 0; hh.setInt16(18, ia ? 1000 : 1); hh.setInt16(20, ia ? Math.round(Math.tan(-ia * Math.PI / 180) * 1000) : 0);
    hh.setUint16(34, n);
    T.hhea = hhea;
    var maxp = new Uint8Array(32), mp = new DataView(maxp.buffer);
    mp.setUint32(0, 0x00010000); mp.setUint16(4, n); mp.setUint16(6, gl.maxPts); mp.setUint16(8, gl.maxCont); mp.setUint16(14, 2);
    T.maxp = maxp;
    T.cmap = buildCmap(cmap);
    T.name = buildName(font.names);
    T.post = buildPost(font);
    var keep = layoutStable(font);
    T['OS/2'] = buildOS2(font, cmap, keep && (font.extra.GSUB || font.extra.GPOS));
    var dropped = [];
    Object.keys(font.extra).forEach(function (t) {
      if (keep) T[t] = font.extra[t];
      else if (['GSUB', 'GPOS', 'GDEF', 'kern', 'BASE', 'JSTF', 'MATH', 'morx', 'mort', 'feat', 'ankr', 'kerx', 'lcar', 'prop', 'opbd', 'trak', 'Zapf', 'bsln', 'just', 'fmtx'].indexOf(t) >= 0) dropped.push(t);
      else T[t] = font.extra[t];
    });
    font.lastDropped = dropped;
    return buildSfnt(T, 'ttf');
  }

  FS.sfnt = { readTables: readTables, buildSfnt: buildSfnt, loadFont: loadFont, buildFont: buildFont, checksum: checksum, bboxOf: bboxOf, uniqueNames: uniqueNames, parseName: parseName, tagStr: tagStr, layoutStable: layoutStable };
  if (typeof module !== 'undefined') module.exports = FS;
})(typeof window !== 'undefined' ? window : globalThis);
