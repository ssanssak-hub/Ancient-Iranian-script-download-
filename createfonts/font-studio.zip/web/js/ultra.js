/* Font Studio Ultra (1.6.0) — ابزارهای پیشرفتهٔ تازه؛ همه JS خالص و بدون نیاز به آپدیت اپ
   ۱) وزن/Offset  ۲) پاک‌سازی نقاط  ۳) فاصله‌گذاری خودکار  ۴) متریک‌های عمودی
   ۵) اصلاح نگاشت فارسی/عربی و نویسه‌های نامرئی  ۶) Mark-to-Base خودکار + Mark-to-Mark  ۷) نام‌های استاندارد گلیف */
(function (root) {
'use strict';
var A = root.StudioApp, FS = root.FS; if (!A || !FS) return;
var T = A.T, S = A.S, $ = A.$;
function esc(s) { return A.esc(String(s == null ? '' : s)); }
function hex4(n) { var h = Number(n).toString(16).toUpperCase(); while (h.length < 4) h = '0' + h; return h; }
function stdName(cp) { return cp <= 0xFFFF ? 'uni' + hex4(cp) : 'u' + cp.toString(16).toUpperCase(); }
function num(v, d) { v = +v; return Number.isFinite(v) ? v : d; }

/* ---------- هندسه ---------- */
function polys(g) {
  var res = [];
  (g.contours || []).forEach(function (c) {
    var e = FS.geom.normalized(c); if (!e || e.length < 2) return;
    var n = e.length, pl = [{ x: e[0].x, y: e[0].y }], i = 1;
    while (i <= n) {
      var p = e[i % n];
      if (p.on) { pl.push({ x: p.x, y: p.y }); i++; }
      else { var q = e[(i + 1) % n], a = pl[pl.length - 1]; for (var s = 1; s <= 6; s++) { var t = s / 6, u = 1 - t; pl.push({ x: u * u * a.x + 2 * u * t * p.x + t * t * q.x, y: u * u * a.y + 2 * u * t * p.y + t * t * q.y }); } i += 2; }
    }
    res.push(pl);
  });
  return res;
}
function tightBox(g) {
  var pl = polys(g), b = null;
  pl.forEach(function (c) { c.forEach(function (p) { if (!b) b = { x0: p.x, y0: p.y, x1: p.x, y1: p.y }; else { if (p.x < b.x0) b.x0 = p.x; if (p.x > b.x1) b.x1 = p.x; if (p.y < b.y0) b.y0 = p.y; if (p.y > b.y1) b.y1 = p.y; } }); });
  return b;
}
function rootCp(g) {
  var us = g.unicodes || []; if (us.length) return us[0];
  var m = /^uni([0-9A-Fa-f]{4,6})(?:\.|$)/.exec(g.name || ''); return m ? parseInt(m[1], 16) : -1;
}
function isMarkCp(u) { return (u >= 0x300 && u <= 0x36F) || (u >= 0x64B && u <= 0x65F) || u === 0x670 || (u >= 0x6D6 && u <= 0x6ED); }
function parseRanges(str) {
  var out = []; String(str || '').split(/[,\s]+/).forEach(function (t) { if (!t) return; var m = /^(?:U\+)?([0-9a-f]+)(?:-(?:U\+)?([0-9a-f]+))?$/i.exec(t); if (m) { var a = parseInt(m[1], 16), b = m[2] ? parseInt(m[2], 16) : a; out.push([a, Math.max(a, b)]); } });
  return out;
}
function scopeIdx(f, mode, rangeStr, cur) {
  if (mode === 'cur') return f.glyphs[cur] ? [cur] : [];
  var rs = mode === 'range' ? parseRanges(rangeStr) : null, res = [];
  f.glyphs.forEach(function (g, i) {
    if (i === 0 || !g.contours || !g.contours.length) return;
    if (rs) { var u = rootCp(g); if (!rs.some(function (r) { return u >= r[0] && u <= r[1]; })) return; }
    res.push(i);
  });
  return res;
}

/* ---------- ۱) وزن / Offset ---------- */
function offsetGlyph(g, dx, dy, keepSpacing) {
  var out = [];
  (g.contours || []).forEach(function (c) {
    var e = FS.geom.normalized(c); if (!e || e.length < 3) { out.push(c); return; }
    var pts = []; e.forEach(function (p) { var l = pts[pts.length - 1]; if (!l || l.x !== p.x || l.y !== p.y || l.on !== p.on) pts.push(p); });
    if (pts.length > 1 && pts[0].x === pts[pts.length - 1].x && pts[0].y === pts[pts.length - 1].y) pts.pop();
    var n = pts.length; if (n < 3) { out.push(c); return; }
    var np = [];
    for (var i = 0; i < n; i++) {
      var p = pts[i], a = pts[(i - 1 + n) % n], b = pts[(i + 1) % n];
      var d1x = p.x - a.x, d1y = p.y - a.y, d2x = b.x - p.x, d2y = b.y - p.y, l1 = Math.hypot(d1x, d1y), l2 = Math.hypot(d2x, d2y);
      if (!l1 && !l2) { np.push({ x: p.x, y: p.y, on: p.on }); continue; }
      if (!l1) { d1x = d2x; d1y = d2y; l1 = l2; } if (!l2) { d2x = d1x; d2y = d1y; l2 = l1; }
      var n1x = -d1y / l1, n1y = d1x / l1, n2x = -d2y / l2, n2y = d2x / l2, sx = n1x + n2x, sy = n1y + n2y, sl = Math.hypot(sx, sy), mx, my, k;
      if (sl < 1e-6) { mx = n1x; my = n1y; k = 1; } else { mx = sx / sl; my = sy / sl; k = 1 / Math.max(mx * n1x + my * n1y, 0.4); }
      np.push({ x: Math.round(p.x + mx * k * dx), y: Math.round(p.y + my * k * dy), on: p.on });
    }
    out.push(np);
  });
  g.contours = out;
  if (keepSpacing) { var s = Math.round(dx); g.contours.forEach(function (c) { c.forEach(function (p) { p.x += s; }); }); if (g.contours.length) g.adv = Math.max(0, Math.round((g.adv || 0) + 2 * s)); }
}

/* ---------- ۲) پاک‌سازی نقاط ---------- */
function dist2line(p, a, b) { var dx = b.x - a.x, dy = b.y - a.y, l = Math.hypot(dx, dy); if (!l) return Math.hypot(p.x - a.x, p.y - a.y); return Math.abs((p.x - a.x) * dy - (p.y - a.y) * dx) / l; }
function cleanContour(c, o, st) {
  var e = FS.geom.normalized(c); if (!e) return null;
  var pts = e.map(function (p) { return { x: p.x, y: p.y, on: p.on }; }), out = [];
  pts.forEach(function (p) { var l = out[out.length - 1]; if (l && Math.hypot(l.x - p.x, l.y - p.y) <= o.dup) { if (!l.on && p.on) out[out.length - 1] = p; st.dup++; return; } out.push(p); });
  while (out.length > 2 && Math.hypot(out[0].x - out[out.length - 1].x, out[0].y - out[out.length - 1].y) <= o.dup) { out.pop(); st.dup++; }
  var changed = true, guard = 0;
  while (changed && guard++ < 50 && out.length > 3) {
    changed = false;
    for (var i = 0; i < out.length && out.length > 3; i++) {
      var n = out.length, a = out[(i - 1 + n) % n], p = out[i], b = out[(i + 1) % n];
      if (o.flat && !p.on && a.on && b.on && dist2line(p, a, b) <= o.flat) { out.splice(i, 1); st.flat++; changed = true; i--; continue; }
      if (o.col && p.on && a.on && b.on) {
        var dot = (p.x - a.x) * (b.x - p.x) + (p.y - a.y) * (b.y - p.y);
        if (dot > 0 && dist2line(p, a, b) <= o.col) { out.splice(i, 1); st.col++; changed = true; i--; }
      }
    }
  }
  if (out.length < 3) { st.speck++; return null; }
  var r = FS.geom.normalized(out); if (!r || r.length < 3) { st.speck++; return null; }
  if (Math.abs(FS.editor.signedArea(r)) < o.speck) { st.speck++; return null; }
  return r;
}
function cleanGlyph(g, o) {
  var st = { dup: 0, flat: 0, col: 0, speck: 0 }, out = [];
  (g.contours || []).forEach(function (c) { var r = cleanContour(c, o, st); if (r) out.push(r); });
  g.contours = out; return st;
}

/* ---------- ۳) فاصله‌گذاری خودکار ---------- */
function extents(pl, y0, y1, N) {
  var L = [], R = [];
  for (var k = 0; k < N; k++) {
    var y = y0 + (y1 - y0) * (k + 0.5) / N, mn = Infinity, mx = -Infinity;
    for (var c = 0; c < pl.length; c++) { var P = pl[c], m = P.length; for (var j = 0; j < m; j++) { var a = P[j], b = P[(j + 1) % m]; if ((a.y <= y && b.y > y) || (b.y <= y && a.y > y)) { var x = a.x + (y - a.y) * (b.x - a.x) / (b.y - a.y); if (x < mn) mn = x; if (x > mx) mx = x; } } }
    L.push(mn); R.push(mx);
  }
  return { L: L, R: R };
}
function spaceGlyph(g, o, f) {
  var pl = polys(g), b = tightBox(g); if (!b) return false;
  var u = rootCp(g); if (isMarkCp(u) || !(g.adv > 0)) return false;
  var depth = o.depth, N = 24, y0 = o.lo, y1 = o.hi, ex = extents(pl, y0, y1, N), seen = 0, i;
  for (i = 0; i < N; i++) if (ex.L[i] !== Infinity) seen++;
  if (!seen) { ex = extents(pl, b.y0, b.y1, N); y0 = b.y0; y1 = b.y1; }
  var sl = 0, sr = 0;
  for (i = 0; i < N; i++) { sl += ex.L[i] === Infinity ? depth : Math.min(depth, ex.L[i] - b.x0); sr += ex.R[i] === -Infinity ? depth : Math.min(depth, b.x1 - ex.R[i]); }
  sl /= N; sr /= N;
  var minB = -Math.round(f.upm * 0.1), nl = Math.max(minB, Math.round(o.target - sl)), nr = Math.max(minB, Math.round(o.target - sr));
  var nm = g.name || '', form = (/\.(init|medi|fina|isol)$/.exec(nm) || [])[1];
  if (o.keepJoin && form) { if (form === 'init' || form === 'medi') nl = Math.round(b.x0); if (form === 'fina' || form === 'medi') nr = Math.round(g.adv - b.x1); }
  var dx = nl - Math.round(b.x0);
  g.contours.forEach(function (c) { c.forEach(function (p) { p.x = Math.round(p.x + dx); }); });
  g.adv = Math.max(0, Math.round(nl + (b.x1 - b.x0) + nr)); return true;
}

/* ---------- ۴) متریک‌های عمودی ---------- */
function inkStats(f) {
  var tops = [], bots = [], y1 = -Infinity, y0 = Infinity;
  f.glyphs.forEach(function (g) { var b = tightBox(g); if (!b) return; tops.push(b.y1); bots.push(b.y0); if (b.y1 > y1) y1 = b.y1; if (b.y0 < y0) y0 = b.y0; });
  if (!tops.length) { y1 = Math.round(f.upm * .8); y0 = -Math.round(f.upm * .2); tops = [y1]; bots = [y0]; }
  tops.sort(function (a, b) { return a - b; }); bots.sort(function (a, b) { return b - a; });
  var k = Math.max(0, Math.floor(tops.length * 0.99) - 1);
  return { y1: Math.ceil(y1), y0: Math.floor(y0), typ1: Math.ceil(tops[k]), typ0: Math.floor(bots[k]) };
}
function glyphTop(f, cp) { for (var i = 0; i < f.glyphs.length; i++) if ((f.glyphs[i].unicodes || []).indexOf(cp) >= 0) { var b = tightBox(f.glyphs[i]); return b ? Math.round(b.y1) : 0; } return 0; }
function applyMetrics(f, o) {
  var asc = Math.round(o.asc), desc = -Math.abs(Math.round(o.desc)), gap = Math.round(o.gap), ink = inkStats(f), os2 = f.os2 || (f.os2 = {});
  os2.typoAsc = asc; os2.typoDesc = desc; os2.typoGap = gap;
  if (o.hhea) { f.hhea.asc = asc; f.hhea.desc = desc; f.hhea.gap = gap; }
  if (o.win) { os2.winAsc = Math.max(ink.y1, asc, 0); os2.winDesc = Math.max(-ink.y0, -desc, 0); }
  os2.useTypo = !!o.useTypo;
  if (o.xh) { var xh = glyphTop(f, 0x78), ch = glyphTop(f, 0x48); if (xh > 0) os2.xHeight = xh; if (ch > 0) os2.capHeight = ch; }
}

/* ---------- ۵) نگاشت فارسی/عربی + نویسه‌های نامرئی ---------- */
var ALIASES = [
  { id: 'kaf', from: [0x643], to: 0x6A9, fa: 'ك عربی (U+0643) ← شکل «ک» فارسی (U+06A9)', en: 'Arabic Kaf (U+0643) uses the Persian Keheh shape (U+06A9)', def: true },
  { id: 'yeh', from: [0x64A], to: 0x6CC, fa: 'ي عربی (U+064A) ← شکل «ی» فارسی (U+06CC)', en: 'Arabic Yeh (U+064A) uses the Persian Yeh shape (U+06CC)', def: true },
  { id: 'ymk', from: [0x649], to: 0x6CC, fa: 'ى الف مقصوره (U+0649) ← شکل «ی» فارسی', en: 'Alef Maksura (U+0649) uses the Persian Yeh shape', def: false }
];
var INVIS = [[0x200B, 'ZWSP'], [0x200C, 'ZWNJ'], [0x200D, 'ZWJ'], [0x200E, 'LRM'], [0x200F, 'RLM'], [0x2060, 'WJ'], [0xFEFF, 'ZWNBSP'], [0x61C, 'ALM'], [0x202A, 'LRE'], [0x202B, 'RLE'], [0x202C, 'PDF'], [0x202D, 'LRO'], [0x202E, 'RLO'], [0x2066, 'LRI'], [0x2067, 'RLI'], [0x2068, 'FSI'], [0x2069, 'PDI']];
function applyUnicode(f, o, track) {
  var own = {}, rep = { aliased: 0, created: 0, skipped: 0, lines: [] };
  function reown() { own = {}; f.glyphs.forEach(function (g, i) { (g.unicodes || []).forEach(function (u) { own[u] = i; }); }); }
  reown();
  function put(cp, gi) {
    var cur = own[cp]; if (cur === gi) return; if (cur !== undefined && !o.overwrite) { rep.skipped++; return; }
    if (cur !== undefined) { track(cur); var a = f.glyphs[cur].unicodes, k = a.indexOf(cp); if (k >= 0) a.splice(k, 1); }
    track(gi); f.glyphs[gi].unicodes = (f.glyphs[gi].unicodes || []).concat([cp]); own[cp] = gi; rep.aliased++;
  }
  ALIASES.forEach(function (al) { if (!o['al_' + al.id]) return; var gi = own[al.to]; if (gi === undefined) { rep.lines.push('U+' + hex4(al.to) + ' ✗'); return; } al.from.forEach(function (cp) { put(cp, gi); }); });
  function digits(fromBase, toBase) { for (var i = 0; i < 10; i++) { var gi = own[fromBase + i]; if (gi !== undefined && own[toBase + i] === undefined) put(toBase + i, gi); } }
  if (o.dA) digits(0x6F0, 0x660); if (o.dP) digits(0x660, 0x6F0); if (o.dL) { for (var i = 0; i < 10; i++) { var gi = own[0x6F0 + i]; if (gi !== undefined && own[0x30 + i] === undefined) put(0x30 + i, gi); } }
  if (o.nbsp && own[0xA0] === undefined && own[0x20] !== undefined) put(0xA0, own[0x20]);
  if (o.invis) INVIS.forEach(function (x) { if (own[x[0]] !== undefined) return; f.glyphs.push({ name: stdName(x[0]), adv: 0, unicodes: [x[0]], contours: [] }); if (f.snapshot) f.snapshot.push([]); own[x[0]] = f.glyphs.length - 1; rep.created++; });
  return rep;
}

/* ---------- ۶) Mark-to-Base خودکار + Mark-to-Mark ---------- */
var MARKS = {
  above: [0x64B, 0x64C, 0x64E, 0x64F, 0x651, 0x652, 0x653, 0x654, 0x657, 0x658, 0x670, 0x300, 0x301, 0x302, 0x303, 0x304, 0x306, 0x307, 0x308, 0x30A, 0x30B, 0x30C],
  below: [0x64D, 0x650, 0x655, 0x656, 0x316, 0x317, 0x323, 0x324, 0x325, 0x326, 0x327, 0x328, 0x329, 0x32D, 0x32E, 0x331]
};
function isArabicBase(u) { return (u >= 0x621 && u <= 0x64A) || (u >= 0x66E && u <= 0x66F) || (u >= 0x671 && u <= 0x6D5) || (u >= 0x6EE && u <= 0x6EF) || (u >= 0x6FA && u <= 0x6FF) || (u >= 0x750 && u <= 0x77F); }
function isLatinBase(u) { return (u >= 0x41 && u <= 0x5A) || (u >= 0x61 && u <= 0x7A); }
function buildMarks(f, o) {
  var rep = { marks: 0, bases: 0, mtb: false, mkmk: false }, own = {}, mk = [], bases = [];
  f.glyphs.forEach(function (g, i) { (g.unicodes || []).forEach(function (u) { own[u] = i; }); });
  ['above', 'below'].forEach(function (dir) {
    MARKS[dir].forEach(function (cp) {
      var gi = own[cp]; if (gi === undefined) return; var g = f.glyphs[gi], b = tightBox(g); if (!b) return;
      mk.push({ gi: gi, dir: dir, cls: dir === 'above' ? 0 : 1, cx: Math.round((b.x0 + b.x1) / 2), y0: Math.round(b.y0), y1: Math.round(b.y1) });
    });
  });
  var markSet = {}; mk.forEach(function (m) { markSet[m.gi] = 1; });
  f.glyphs.forEach(function (g, i) {
    if (markSet[i] || !g.contours || !g.contours.length) return; var u = rootCp(g); if (isMarkCp(u)) return;
    if (!(isArabicBase(u) || (o.latin && isLatinBase(u)))) return;
    var b = tightBox(g); if (!b) return; bases.push({ gi: i, cx: Math.round((b.x0 + b.x1) / 2), y0: Math.round(b.y0), y1: Math.round(b.y1) });
  });
  rep.marks = mk.length; rep.bases = bases.length; if (!mk.length || !bases.length) return rep;
  var L = FS.layout.open(f), scripts = ['arab', 'DFLT']; if (o.latin) scripts.push('latn');
  var r1 = { marks: {}, bases: {}, classCount: 2 };
  mk.forEach(function (m) { r1.marks[m.gi] = { cls: m.cls, x: m.cx, y: m.dir === 'above' ? m.y0 : m.y1 }; });
  bases.forEach(function (b) { r1.bases[b.gi] = { 0: { x: b.cx, y: b.y1 + o.gap }, 1: { x: b.cx, y: b.y0 - o.gap } }; });
  FS.layout.addFeature(L.GPOS, 'mark', [FS.layout.addLookup(L.GPOS, 4, r1)], scripts); rep.mtb = true;
  if (o.mkmk) {
    var r2 = { marks: {}, bases: {}, classCount: 2 };
    mk.forEach(function (m) { r2.marks[m.gi] = { cls: m.cls, x: m.cx, y: m.dir === 'above' ? m.y0 : m.y1 }; var a = {}; a[m.cls] = { x: m.cx, y: m.dir === 'above' ? m.y1 + o.gap2 : m.y0 - o.gap2 }; r2.bases[m.gi] = a; });
    FS.layout.addFeature(L.GPOS, 'mkmk', [FS.layout.addLookup(L.GPOS, 6, r2)], scripts); rep.mkmk = true;
  }
  FS.layout.commit(f); return rep;
}

/* ---------- ۷) نام‌گذاری استاندارد ---------- */
function applyNames(f, o) {
  var used = {}, std = {}; (FS.MAC_NAMES || []).forEach(function (n) { std[n] = 1; });
  f.glyphs.forEach(function (g) { if (g.name) used[g.name] = (used[g.name] || 0) + 1; });
  var count = 0;
  f.glyphs.forEach(function (g, i) {
    if (i === 0) return; var n = g.name || '', sm = /(\.[A-Za-z0-9._]+)$/.exec(n), suffix = sm ? sm[1].replace(/[^A-Za-z0-9._]/g, '') : '', base = sm ? n.slice(0, n.length - sm[1].length) : n;
    var valid = /^[A-Za-z_][A-Za-z0-9._]{0,62}$/.test(n), dupe = used[n] > 1, us = g.unicodes || [], want = !valid || dupe;
    if (!want && o.mode === 'all' && us.length && !std[base] && base !== stdName(us[0])) want = true;
    if (!want) return;
    var nn = (us.length ? stdName(us[0]) : (base.replace(/[^A-Za-z0-9_]/g, '') || 'glyph' + i)) + suffix; if (/^[0-9]/.test(nn)) nn = 'g' + nn; nn = nn.slice(0, 63);
    if (used[nn] && nn !== n) nn = nn.slice(0, 56) + '_' + i;
    if (nn === n) return;
    if (used[n]) used[n]--; used[nn] = (used[nn] || 0) + 1; g.name = nn; count++;
  });
  return count;
}

/* ---------- ابزارهای رابط ---------- */
function touch(gi) {
  S.ttf = null; S.dirty = true; try { A.Host && A.Host.setUnsaved && A.Host.setUnsaved(true); } catch (e) { }
  try { if (S.ed) { S.ed.sel = {}; S.ed.draw(); } } catch (e) { }
  if (A.changed && S.font && S.font.glyphs.length) A.changed(Math.max(0, Math.min(gi | 0, S.font.glyphs.length - 1)), true);
}
function runOn(idx, fn) {
  var items = [], f = S.font;
  idx.forEach(function (i) { var g = f.glyphs[i], before = FS.editor.snap(g); if (fn(g, i) === false) return; var after = FS.editor.snap(g); if (before.c !== after.c || before.a !== after.a || before.n !== after.n || before.u.join() !== after.u.join()) items.push({ gi: i, before: before, after: after }); });
  if (items.length) { A.pushHistory(items); touch(items[0].gi); }
  return items.length;
}
function scopeHTML(p, def) {
  return '<div class="row"><label class="f">' + T('محدوده', 'Scope') + '<select id="' + p + 'Sc"><option value="cur"' + (def === 'cur' ? ' selected' : '') + '>' + T('گلیف فعلی', 'Current glyph') + '</option><option value="all"' + (def === 'all' ? ' selected' : '') + '>' + T('همهٔ گلیف‌های دارای طرح', 'All glyphs with outlines') + '</option><option value="range">' + T('بازه‌های Unicode', 'Unicode ranges') + '</option></select></label><label class="f grow">' + T('بازه (hex)', 'Ranges (hex)') + '<input id="' + p + 'Rg" dir="ltr" placeholder="0600-06FF, 0041-005A"></label></div>';
}
function scopeGet(b, p) { return scopeIdx(S.font, b.querySelector('#' + p + 'Sc').value, b.querySelector('#' + p + 'Rg').value, S.gi); }
function field(id, label, val, extra) { return '<label class="f">' + label + '<input id="' + id + '" type="number" value="' + val + '"' + (extra || '') + '></label>'; }
function chk(id, label, on) { return '<label class="chk"><input id="' + id + '" type="checkbox"' + (on ? ' checked' : '') + '> ' + label + '</label>'; }
function card(title, desc, body, out) { return '<div class="card ul-card"><h3>' + title + '</h3><div class="muted">' + desc + '</div>' + body + '<div class="muted ul-out" id="' + out + '"></div></div>'; }
function guard(fn) { return function () { try { fn.apply(this, arguments); } catch (e) { A.fail(e); } }; }

function openUltra() {
  var f = S.font, upm = f.upm, xh = (f.os2 && f.os2.xHeight) || Math.round(upm * .5), ink = inkStats(f), os2 = f.os2 || {};
  var m = document.createElement('div'); m.className = 'fs-lab ul-lab';
  var html = '<div class="fs-lab-head"><div><h2>💎 ' + T('Font Studio Ultra', 'Font Studio Ultra') + '</h2><div class="muted">' + esc(A.fam()) + ' · UPM ' + upm + '</div></div><button class="b" id="ulClose">✕</button></div><div id="ulBody">';
  html += card('⚖️ ' + T('وزن / Offset طرح', 'Weight / Outline offset'), T('طرح را ضخیم‌تر (+) یا نازک‌تر (−) می‌کند، بدون اینکه شکل ازهم بپاشد. می‌شود افقی و عمودی را جدا تنظیم کرد.', 'Embolden (+) or lighten (−) outlines; horizontal and vertical amounts can differ.'),
    scopeHTML('w', 'cur') + '<div class="row">' + field('wX', T('افقی (واحد)', 'Horizontal'), 12, ' step="1"') + field('wY', T('عمودی (واحد)', 'Vertical'), 12, ' step="1"') + '</div>' + chk('wKeep', T('فاصلهٔ کناری حفظ شود (عرض ± ۲×افقی)', 'Keep side bearings (advance ± 2×horizontal)'), true) + '<button class="b p" id="wGo">' + T('اعمال وزن', 'Apply weight') + '</button>', 'wOut');
  html += card('🧹 ' + T('پاک‌سازی و ساده‌سازی نقاط', 'Cleanup & simplify points'), T('نقطه‌های تکراری، نقطه‌های هم‌خط، منحنی‌های تقریباً صاف و لکه‌های ریز را حذف می‌کند.', 'Removes duplicate/collinear points, near-flat curves and tiny specks.'),
    scopeHTML('c', 'all') + '<div class="row">' + field('cDup', T('تلورانس تکراری', 'Duplicate tol'), 1, ' min="0" step="1"') + field('cCol', T('تلورانس هم‌خط', 'Collinear tol'), 1, ' min="0" step="1"') + field('cFlat', T('تلورانس منحنیِ صاف', 'Flat-curve tol'), 1, ' min="0" step="1"') + field('cSpeck', T('حداقل مساحت لکه', 'Min speck area'), Math.round(Math.pow(upm / 100, 2)), ' min="0"') + '</div><button class="b p" id="cGo">' + T('پاک‌سازی', 'Clean up') + '</button>', 'cOut');
  html += card('↔️ ' + T('فاصله‌گذاری خودکار', 'Auto spacing'), T('فضای سفید دو طرف هر گلیف را بر اساس شکل واقعی (نه فقط کادر) یکنواخت می‌کند. حروف نشانه (اعراب) را دست نمی‌زند و می‌تواند سمت اتصال init/medi/fina را حفظ کند.', 'Equalises optical white space on both sides from the real outline. Skips marks; can keep the connecting side of init/medi/fina forms.'),
    scopeHTML('s', 'cur') + '<div class="row">' + field('sT', T('فضای هدف', 'Target space'), Math.round(upm * .05)) + field('sD', T('عمق بررسی', 'Depth limit'), Math.round(xh * .3)) + field('sLo', T('از ارتفاع', 'Band from y'), 0) + field('sHi', T('تا ارتفاع', 'Band to y'), xh) + '</div>' + chk('sJoin', T('سمت اتصال فرم‌های init/medi/fina را دست نزن', 'Keep connecting side of joining forms'), true) + '<button class="b p" id="sGo">' + T('فاصله‌گذاری', 'Space glyphs') + '</button>', 'sOut');
  html += card('📏 ' + T('متریک‌های عمودی خط', 'Vertical metrics'), T('ascent/descent/lineGap را برای hhea و OS/2 هماهنگ می‌کند تا حروف با نشانه‌ها بریده نشوند. بیشینهٔ جوهر: ', 'Sync ascent/descent/lineGap in hhea and OS/2 so marks are not clipped. Ink extent: ') + ink.y0 + ' … ' + ink.y1 + ' (' + T('بدون ۱٪ پرت: ', 'without top 1%: ') + ink.typ0 + ' … ' + ink.typ1 + ')',
    '<div class="row">' + field('mA', 'Ascent', Math.max(ink.typ1, Math.round(upm * .8))) + field('mD', 'Descent', Math.abs(Math.min(ink.typ0, -Math.round(upm * .2)))) + field('mG', 'Line gap', (f.hhea && f.hhea.gap) || 0) + '</div><div class="muted" dir="ltr">hhea ' + (f.hhea ? f.hhea.asc + '/' + f.hhea.desc + '/' + f.hhea.gap : '-') + ' · typo ' + os2.typoAsc + '/' + os2.typoDesc + '/' + os2.typoGap + ' · win ' + os2.winAsc + '/' + os2.winDesc + '</div>' + chk('mH', T('hhea همان مقدار شود', 'hhea = typo'), true) + chk('mW', T('winAscent/winDescent برابر کل جوهر', 'win metrics = full ink extent'), true) + chk('mU', T('USE_TYPO_METRICS روشن شود', 'Set USE_TYPO_METRICS'), true) + chk('mX', T('xHeight/capHeight از گلیف‌های x و H', 'xHeight/capHeight from x and H'), true) + '<button class="b p" id="mGo">' + T('اعمال متریک‌ها', 'Apply metrics') + '</button>', 'mOut');
  html += card('🔤 ' + T('اصلاح نگاشت فارسی/عربی و نویسه‌های نامرئی', 'Persian/Arabic mappings & invisible characters'), T('فقط به cmap کد اضافه می‌کند (طرح تازه نمی‌سازد)؛ مگر نویسه‌های نامرئی مثل نیم‌فاصله که گلیف خالی لازم دارند.', 'Adds cmap entries only (no new outlines), except invisible characters such as ZWNJ which need an empty glyph.'),
    ALIASES.map(function (al) { return chk('u_' + al.id, T(al.fa, al.en), al.def); }).join('') + chk('uDA', T('ارقام عربی-هندی ٠–٩ از ارقام فارسی (اگر ندارد)', 'Fill Arabic-Indic digits from Persian digits'), true) + chk('uDP', T('ارقام فارسی ۰–۹ از ارقام عربی-هندی (اگر ندارد)', 'Fill Persian digits from Arabic-Indic digits'), true) + chk('uDL', T('ارقام لاتین 0–9 از ارقام فارسی (اگر ندارد)', 'Fill Latin digits from Persian digits'), false) + chk('uNb', T('فاصلهٔ ثابت U+00A0 هم‌شکل فاصله', 'NBSP (U+00A0) like space'), true) + chk('uIv', T('ساخت گلیف نیم‌فاصله، ZWJ، LRM، RLM و سایر نویسه‌های کنترلی', 'Create ZWNJ, ZWJ, LRM, RLM and other control glyphs'), true) + chk('uOv', T('کدهای موجود جابه‌جا شوند (پیش‌فرض: دست‌نخورده)', 'Overwrite existing mappings'), false) + '<button class="b p" id="uGo">' + T('اعمال', 'Apply') + '</button>', 'uOut');
  html += card('◌ ' + T('اعراب‌گذاری خودکار (Mark-to-Base + Mark-to-Mark)', 'Auto mark positioning (Mark-to-Base + Mark-to-Mark)'), T('اعرابِ بالا و پایین (فتحه، کسره، شدّه، سکون، خنجری …) را روی همهٔ حروف عربی/فارسی (و اختیاری لاتین) لنگر می‌کند. Mark-to-Mark برای روی‌هم‌قرارگرفتن اعراب (مثل شدّه + فتحه).', 'Anchors upper/lower marks on all Arabic/Persian (optionally Latin) bases. Mark-to-Mark stacks marks (shadda + fatha).'),
    '<div class="row">' + field('kG', T('فاصلهٔ اعراب از حرف', 'Gap above/below base'), Math.round(upm * .03)) + field('kG2', T('فاصلهٔ اعراب از اعراب', 'Gap between marks'), Math.round(upm * .02)) + '</div>' + chk('kMM', T('Mark-to-Mark هم ساخته شود', 'Also build Mark-to-Mark'), true) + chk('kLat', T('حروف لاتین (accent) هم باشد', 'Include Latin accents'), false) + '<button class="b p" id="kGo">' + T('ساخت GPOS', 'Build GPOS') + '</button>', 'kOut');
  html += card('🏷️ ' + T('نام‌های استاندارد گلیف', 'Production glyph names'), T('نام‌های نامعتبر یا تکراری را درست می‌کند؛ در حالت دوم همهٔ گلیف‌های دارای Unicode به شکل uniXXXX درمی‌آیند. جدول‌های GSUB/GPOS با اندیس کار می‌کنند و خراب نمی‌شوند.', 'Fixes invalid/duplicate names; the second mode renames every mapped glyph to uniXXXX. GSUB/GPOS use indices so they stay valid.'),
    '<label class="f">' + T('حالت', 'Mode') + '<select id="nMode"><option value="fix">' + T('فقط نام‌های نامعتبر/تکراری', 'Only invalid/duplicate') + '</option><option value="all">' + T('همه به uniXXXX', 'All to uniXXXX') + '</option></select></label><button class="b p" id="nGo">' + T('اصلاح نام‌ها', 'Fix names') + '</button>', 'nOut');
  html += '</div>';
  m.innerHTML = html; document.body.appendChild(m);
  var q = function (id) { return m.querySelector('#' + id); }, say = function (id, txt) { q(id).textContent = txt; A.toast(txt); };
  q('ulClose').onclick = function () { m.remove(); };

  q('wGo').onclick = guard(function () {
    var dx = num(q('wX').value, 0), dy = num(q('wY').value, 0), lim = Math.round(upm * .15), idx = scopeGet(m, 'w');
    if (Math.abs(dx) > lim || Math.abs(dy) > lim) { say('wOut', T('مقدار زیاد است؛ حداکثر ±' + lim, 'Value too large; max ±' + lim)); return; }
    var n = runOn(idx, function (g) { if (!g.contours.length) return false; A.fixDirections(g); offsetGlyph(g, dx, dy, q('wKeep').checked); FS.editor.normalizeGlyph(g); A.fixDirections(g); });
    say('wOut', n + ' ' + T('گلیف تغییر کرد ✔', 'glyphs changed ✔'));
  });
  q('cGo').onclick = guard(function () {
    var o = { dup: num(q('cDup').value, 1), col: num(q('cCol').value, 1), flat: num(q('cFlat').value, 1), speck: num(q('cSpeck').value, 0) }, tot = { dup: 0, flat: 0, col: 0, speck: 0 };
    var n = runOn(scopeGet(m, 'c'), function (g) { var st = cleanGlyph(g, o); for (var k in st) tot[k] += st[k]; FS.editor.normalizeGlyph(g); });
    say('cOut', n + ' ' + T('گلیف · حذف‌شده: تکراری ', 'glyphs · removed: duplicate ') + tot.dup + T('، هم‌خط ', ', collinear ') + tot.col + T('، منحنی صاف ', ', flat ') + tot.flat + T('، لکه ', ', specks ') + tot.speck);
  });
  q('sGo').onclick = guard(function () {
    var o = { target: num(q('sT').value, 50), depth: Math.max(1, num(q('sD').value, 100)), lo: num(q('sLo').value, 0), hi: num(q('sHi').value, xh), keepJoin: q('sJoin').checked };
    if (o.hi <= o.lo) { say('sOut', T('بازهٔ ارتفاع نامعتبر است', 'Invalid height band')); return; }
    var n = runOn(scopeGet(m, 's'), function (g) { return spaceGlyph(g, o, S.font) ? undefined : false; });
    say('sOut', n + ' ' + T('گلیف فاصله‌گذاری شد ✔', 'glyphs spaced ✔'));
  });
  q('mGo').onclick = guard(function () {
    applyMetrics(S.font, { asc: num(q('mA').value, 800), desc: num(q('mD').value, 200), gap: num(q('mG').value, 0), hhea: q('mH').checked, win: q('mW').checked, useTypo: q('mU').checked, xh: q('mX').checked });
    touch(S.gi); say('mOut', T('متریک‌ها اعمال شد ✔', 'Metrics applied ✔'));
  });
  q('uGo').onclick = guard(function () {
    var o = { overwrite: q('uOv').checked, dA: q('uDA').checked, dP: q('uDP').checked, dL: q('uDL').checked, nbsp: q('uNb').checked, invis: q('uIv').checked }, before = {}, touched = [];
    ALIASES.forEach(function (al) { o['al_' + al.id] = q('u_' + al.id).checked; });
    var rep = applyUnicode(S.font, o, function (gi) { if (!before[gi]) { before[gi] = FS.editor.snap(S.font.glyphs[gi]); touched.push(gi); } });
    var items = touched.map(function (gi) { return { gi: gi, before: before[gi], after: FS.editor.snap(S.font.glyphs[gi]) }; });
    if (items.length) A.pushHistory(items); if (items.length || rep.created) touch(touched[0] || S.gi);
    say('uOut', rep.aliased + ' ' + T('نگاشت اضافه شد', 'mappings added') + ' · ' + rep.created + ' ' + T('گلیف نامرئی ساخته شد', 'invisible glyphs created') + (rep.skipped ? ' · ' + rep.skipped + ' ' + T('کد از قبل بود', 'already mapped') : '') + (rep.lines.length ? ' · ' + rep.lines.join(' ') : ''));
  });
  q('kGo').onclick = guard(function () {
    var rep = buildMarks(S.font, { gap: num(q('kG').value, 30), gap2: num(q('kG2').value, 20), mkmk: q('kMM').checked, latin: q('kLat').checked });
    if (!rep.mtb) { say('kOut', T('اعراب یا حرف پایه پیدا نشد (' + rep.marks + ' اعراب، ' + rep.bases + ' پایه). گلیف‌های اعراب باید Unicode 064B–0652 و … داشته باشند.', 'No marks/bases found (' + rep.marks + ' marks, ' + rep.bases + ' bases).')); return; }
    touch(S.gi); say('kOut', rep.marks + ' ' + T('اعراب روی', 'marks over') + ' ' + rep.bases + ' ' + T('حرف ✔', 'bases ✔') + (rep.mkmk ? ' · Mark-to-Mark ✔' : ''));
  });
  q('nGo').onclick = guard(function () {
    var items = [], before = S.font.glyphs.map(function (g) { return FS.editor.snap(g); });
    var cnt = applyNames(S.font, { mode: q('nMode').value });
    S.font.glyphs.forEach(function (g, i) { if (g.name !== before[i].n) items.push({ gi: i, before: before[i], after: FS.editor.snap(g) }); });
    if (items.length) { A.pushHistory(items); touch(items[0].gi); }
    say('nOut', cnt + ' ' + T('نام اصلاح شد ✔', 'names fixed ✔'));
  });
}

function panel(mm) {
  var d = document.createElement('details');
  d.innerHTML = '<summary>💎 ' + T('Font Studio Ultra — ابزارهای پیشرفتهٔ تازه', 'Font Studio Ultra — new advanced tools') + '</summary><div class="muted">' + T('وزن، پاک‌سازی، فاصله‌گذاری خودکار، متریک‌ها، نگاشت فارسی/عربی، اعراب‌گذاری خودکار و نام‌گذاری.', 'Weight, cleanup, auto spacing, metrics, Persian/Arabic mappings, auto marks and naming.') + '</div><button class="b p" id="ulOpen">💎 ' + T('باز کردن Ultra', 'Open Ultra') + '</button>';
  mm.appendChild(d); d.querySelector('#ulOpen').onclick = openUltra;
}
var old = A.afterTools; A.afterTools = function (mm) { if (old) old(mm); panel(mm); };
root.StudioUltra = { offsetGlyph: offsetGlyph, cleanGlyph: cleanGlyph, spaceGlyph: spaceGlyph, applyMetrics: applyMetrics, applyUnicode: applyUnicode, buildMarks: buildMarks, applyNames: applyNames, inkStats: inkStats, scopeIdx: scopeIdx, open: openUltra };
})(window);
