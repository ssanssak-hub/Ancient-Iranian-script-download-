/* قالب‌های خروجی/ورودی: WOFF، WOFF2، EOT، SVG، زیپ، بستهٔ وب‌فونت، بستهٔ اندروید، پروژه (.dfproj)، جستجوی فونت داخل فایل ناشناس (مثلاً .fcp) */
(function (root) {
  'use strict';
  var FS = root.FS = root.FS || {};
  var enc = new TextEncoder(), dec = new TextDecoder('utf-8');

  function pad4(n) { return (n + 3) & ~3; }
  function concat(arrs) { var n = 0; arrs.forEach(function (a) { n += a.length; }); var o = new Uint8Array(n), p = 0; arrs.forEach(function (a) { o.set(a, p); p += a.length; }); return o; }
  async function stream(fmt, mode, data) {
    var cs = mode === 'c' ? new CompressionStream(fmt) : new DecompressionStream(fmt);
    var w = cs.writable.getWriter(); w.write(data); w.close();
    var chunks = [], r = cs.readable.getReader();
    for (;;) { var x = await r.read(); if (x.done) break; chunks.push(x.value); }
    return concat(chunks);
  }

  /* ---------- WOFF 1 ---------- */
  async function toWoff(ttf) {
    var T = FS.sfnt.readTables(ttf).tables, tags = Object.keys(T).sort(), n = tags.length, parts = [], sfntSize = 12 + 16 * n;
    var dirLen = 44 + 20 * n, off = dirLen, dir = [];
    for (var i = 0; i < n; i++) {
      var raw = T[tags[i]], comp = raw.length > 64 ? await stream('deflate', 'c', raw) : raw;
      var use = comp.length < raw.length ? comp : raw;
      dir.push({ tag: tags[i], off: off, comp: use.length, orig: raw.length, sum: FS.sfnt.checksum(raw) });
      parts.push(use); off += pad4(use.length); sfntSize += pad4(raw.length);
    }
    var out = new Uint8Array(off), dv = new DataView(out.buffer);
    dv.setUint32(0, 0x774F4646); dv.setUint32(4, 0x00010000); dv.setUint32(8, off); dv.setUint16(12, n); dv.setUint32(16, sfntSize);
    dir.forEach(function (d, i) { var o = 44 + i * 20; for (var k = 0; k < 4; k++) out[o + k] = d.tag.charCodeAt(k); dv.setUint32(o + 4, d.off); dv.setUint32(o + 8, d.comp); dv.setUint32(o + 12, d.orig); dv.setUint32(o + 16, d.sum); out.set(parts[i], d.off); });
    return out;
  }
  async function fromWoff(u8) {
    var dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength), n = dv.getUint16(12), T = {};
    for (var i = 0; i < n; i++) {
      var o = 44 + i * 20, tag = String.fromCharCode(u8[o], u8[o + 1], u8[o + 2], u8[o + 3]), off = dv.getUint32(o + 4), cl = dv.getUint32(o + 8), ol = dv.getUint32(o + 12);
      var d = u8.subarray(off, off + cl); T[tag] = cl < ol ? await stream('deflate', 'd', d) : d;
    }
    return FS.sfnt.buildSfnt(T, dv.getUint32(4) === 0x4F54544F ? 'cff' : 'ttf');
  }

  /* ---------- WOFF 2 (جریان Brotli بدون فشرده‌سازی؛ برای مرورگرها و اندروید معتبر است) ---------- */
  var W2_TAGS = ['cmap','head','hhea','hmtx','maxp','name','OS/2','post','cvt ','fpgm','glyf','loca','prep','CFF ','VORG','EBDT','EBLC','gasp','hdmx','kern','LTSH','PCLT','VDMX','vhea','vmtx','BASE','GDEF','GPOS','GSUB','EBSC','JSTF','MATH','CBDT','CBLC','COLR','CPAL','SVG ','sbix','acnt','avar','bdat','bloc','bsln','cvar','fdsc','feat','fmtx','fvar','gvar','hsty','just','lcar','mort','morx','opbd','prop','trak','Zapf','Silf','Glat','Gloc','Feat','Sill'];
  function b128(n) { var b = []; do { b.unshift(n & 127); n = Math.floor(n / 128); } while (n > 0); for (var i = 0; i < b.length - 1; i++) b[i] |= 128; return b; }
  function brotliStored(data) {
    var out = [], first = true, pos = 0;
    while (pos < data.length) {
      var len = Math.min(65536, data.length - pos), bits = [];
      if (first) bits.push(0);          // WBITS=16
      bits.push(0, 0, 0);               // ISLAST=0, MNIBBLES=0 (۴ نیبل)
      for (var i = 0; i < 16; i++) bits.push(((len - 1) >> i) & 1);
      bits.push(1);                     // ISUNCOMPRESSED
      while (bits.length % 8) bits.push(0);
      for (var k = 0; k < bits.length; k += 8) { var v = 0; for (var j = 0; j < 8; j++) v |= bits[k + j] << j; out.push(v); }
      for (var q = 0; q < len; q++) out.push(data[pos + q]);
      pos += len; first = false;
    }
    out.push(first ? 0x06 : 0x03);       // بلوک آخر خالی (اگر داده‌ای نبود: WBITS + ISLAST + ISLASTEMPTY)
    return Uint8Array.from(out);
  }
  function toWoff2(ttf) {
    var T = FS.sfnt.readTables(ttf).tables, tags = Object.keys(T).sort();
    var gi = tags.indexOf('glyf'), li = tags.indexOf('loca'); if (gi >= 0 && li >= 0) { tags.splice(li, 1); tags.splice(tags.indexOf('glyf') + 1, 0, 'loca'); }
    var dir = [], sfntSize = 12 + 16 * tags.length, blob = [];
    tags.forEach(function (t) {
      var idx = W2_TAGS.indexOf(t), flags = idx >= 0 ? idx : 63;
      if (t === 'glyf' || t === 'loca') flags |= 0xC0;
      var d = [flags]; if (idx < 0) d.push(t.charCodeAt(0), t.charCodeAt(1), t.charCodeAt(2), t.charCodeAt(3));
      b128(T[t].length).forEach(function (b) { d.push(b); });
      dir.push(Uint8Array.from(d)); blob.push(T[t]); sfntSize += pad4(T[t].length);
    });
    var dirBytes = concat(dir), comp = brotliStored(concat(blob)), hdr = 48, total = pad4(hdr + dirBytes.length + comp.length);
    var out = new Uint8Array(total), dv = new DataView(out.buffer);
    dv.setUint32(0, 0x774F4632); dv.setUint32(4, 0x00010000); dv.setUint32(8, total); dv.setUint16(12, tags.length); dv.setUint32(16 - 0 + 4 - 4 + 4, 0);
    dv.setUint32(16, 0); dv.setUint32(20, 0);
    out.fill(0, 12, 48); dv.setUint16(12, tags.length); dv.setUint32(16, sfntSize); dv.setUint32(20, comp.length); dv.setUint16(24, 1); dv.setUint16(26, 0);
    out.set(dirBytes, hdr); out.set(comp, hdr + dirBytes.length);
    dv.setUint32(8, total);
    return out;
  }

  /* ---------- EOT (مرورگرهای قدیمی) ---------- */
  function toEot(ttf, font) {
    function nm(id) { var r = font.names.filter(function (x) { return x.nid === id && x.pid === 3; }); return (r[0] && r[0].str) || ''; }
    function u16(s) { var b = new Uint8Array(s.length * 2); for (var i = 0; i < s.length; i++) { b[i * 2] = s.charCodeAt(i) & 255; b[i * 2 + 1] = s.charCodeAt(i) >> 8; } return b; }
    var fam = u16(nm(1)), sty = u16(nm(2)), ver = u16(nm(5)), full = u16(nm(4)), o = font.os2;
    var hdrLen = 82 + 2 + fam.length + 2 + 2 + sty.length + 2 + 2 + ver.length + 2 + 2 + full.length + 2 + 2, out = new Uint8Array(hdrLen + ttf.length), dv = new DataView(out.buffer, 0, hdrLen);
    dv.setUint32(0, out.length, true); dv.setUint32(4, ttf.length, true); dv.setUint32(8, 0x00020001, true); dv.setUint32(12, 0, true);
    for (var i = 0; i < 10; i++) out[16 + i] = o.panose[i] || 0;
    out[26] = 1; out[27] = (font.head.macStyle & 2) ? 1 : 0; dv.setUint32(28, o.weight, true); dv.setUint16(32, o.fsType, true); dv.setUint16(34, 0x504C, true);
    for (var u = 0; u < 4; u++) dv.setUint32(36 + u * 4, o.unicodeRange[u] || 0, true);
    dv.setUint32(52, o.codePage[0], true); dv.setUint32(56, o.codePage[1], true);
    var T = FS.sfnt.readTables(ttf).tables; dv.setUint32(60, new DataView(T.head.buffer, T.head.byteOffset).getUint32(8), true);
    var p = 80; dv.setUint16(p, 0, true); p += 2;
    [fam, sty, ver, full].forEach(function (b) { dv.setUint16(p, b.length, true); p += 2; out.set(b, p); p += b.length; dv.setUint16(p, 0, true); p += 2; });
    dv.setUint16(p, 0, true); p += 2;
    out.set(ttf, hdrLen);
    return out;
  }

  /* ---------- هندسه ---------- */
  function explicit(c) {
    var n = c.length, res = [];
    for (var i = 0; i < n; i++) { var a = c[i], b = c[(i + 1) % n]; res.push(a); if (!a.on && !b.on) res.push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, on: true }); }
    return res;
  }
  function rotateToOn(c) { var k = -1; for (var i = 0; i < c.length; i++) if (c[i].on) { k = i; break; } if (k < 0) return null; return c.slice(k).concat(c.slice(0, k)); }
  function normalized(c) { return rotateToOn(explicit(c)); }
  function pathD(contours, flipY, ox, oy, sc) {
    var d = '', s = sc || 1; ox = ox || 0; oy = oy || 0;
    function X(v) { return +(ox + v * s).toFixed(2); } function Y(v) { return +(oy + (flipY ? -v : v) * s).toFixed(2); }
    contours.forEach(function (c0) {
      var c = normalized(c0); if (!c || c.length < 2) return;
      d += 'M' + X(c[0].x) + ' ' + Y(c[0].y); var n = c.length, i = 1;
      while (i <= n) { var p = c[i % n]; if (p.on) { d += 'L' + X(p.x) + ' ' + Y(p.y); i++; } else { var q = c[(i + 1) % n]; d += 'Q' + X(p.x) + ' ' + Y(p.y) + ' ' + X(q.x) + ' ' + Y(q.y); i += 2; } }
      d += 'Z';
    });
    return d;
  }
  function toSvgFont(font) {
    function nm(id) { var r = font.names.filter(function (x) { return x.nid === id && x.pid === 3; }); return (r[0] && r[0].str) || 'Font'; }
    var esc = function (s) { return s.replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
    var s = '<?xml version="1.0" standalone="no"?>\n<svg xmlns="http://www.w3.org/2000/svg"><defs>\n<font id="' + esc(nm(6)) + '" horiz-adv-x="' + (font.glyphs[0] ? font.glyphs[0].adv : font.upm) + '">\n<font-face font-family="' + esc(nm(1)) + '" units-per-em="' + font.upm + '" ascent="' + font.hhea.asc + '" descent="' + font.hhea.desc + '"/>\n';
    font.glyphs.forEach(function (g, i) {
      var d = pathD(g.contours, false);
      if (i === 0) { s += '<missing-glyph horiz-adv-x="' + g.adv + '" d="' + d + '"/>\n'; return; }
      (g.unicodes.length ? g.unicodes : [null]).slice(0, 1).forEach(function (u) {
        if (u === null || u < 0x20 || (u >= 0xD800 && u <= 0xDFFF) || u === 0xFFFE || u === 0xFFFF || u > 0x10FFFF) return;
        s += '<glyph glyph-name="' + esc(g.name) + '" unicode="&#x' + u.toString(16) + ';" horiz-adv-x="' + g.adv + '" d="' + d + '"/>\n';
      });
    });
    return enc.encode(s + '</font></defs></svg>\n');
  }

  /* ---------- ZIP (ذخیره‌بدون‌فشرده) ---------- */
  var crcT = null;
  function crc32(u8) { if (!crcT) { crcT = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; crcT[n] = c >>> 0; } } var c2 = 0xFFFFFFFF; for (var i = 0; i < u8.length; i++) c2 = crcT[(c2 ^ u8[i]) & 255] ^ (c2 >>> 8); return (c2 ^ 0xFFFFFFFF) >>> 0; }
  function makeZip(files) {
    var parts = [], cd = [], off = 0;
    files.forEach(function (f) {
      var nameB = enc.encode(f.name), data = typeof f.data === 'string' ? enc.encode(f.data) : f.data, crc = crc32(data);
      var h = new Uint8Array(30 + nameB.length), dv = new DataView(h.buffer);
      dv.setUint32(0, 0x04034b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 0x0800, true); dv.setUint32(14, crc, true); dv.setUint32(18, data.length, true); dv.setUint32(22, data.length, true); dv.setUint16(26, nameB.length, true); h.set(nameB, 30);
      var c = new Uint8Array(46 + nameB.length), cv = new DataView(c.buffer);
      cv.setUint32(0, 0x02014b50, true); cv.setUint16(4, 20, true); cv.setUint16(6, 20, true); cv.setUint16(8, 0x0800, true); cv.setUint32(16, crc, true); cv.setUint32(20, data.length, true); cv.setUint32(24, data.length, true); cv.setUint16(28, nameB.length, true); cv.setUint32(42, off, true); c.set(nameB, 46);
      parts.push(h, data); cd.push(c); off += h.length + data.length;
    });
    var cdBytes = concat(cd), end = new Uint8Array(22), ev = new DataView(end.buffer);
    ev.setUint32(0, 0x06054b50, true); ev.setUint16(8, files.length, true); ev.setUint16(10, files.length, true); ev.setUint32(12, cdBytes.length, true); ev.setUint32(16, off, true);
    return concat(parts.concat([cdBytes, end]));
  }

  /* ---------- بستهٔ وب‌فونت و اندروید ---------- */
  function slug(s) { return (s || 'font').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').toLowerCase() || 'font'; }
  function famName(font) { var r = font.names.filter(function (x) { return x.nid === 1 && x.pid === 3; }); return (r[0] && r[0].str) || 'MyFont'; }
  async function buildWebPackage(font, ttf, sample) {
    var base = slug(famName(font)), fam = famName(font);
    var woff = await toWoff(ttf), woff2 = toWoff2(ttf), eot = toEot(ttf, font), svg = toSvgFont(font);
    var css = '@font-face {\n  font-family: "' + fam + '";\n  src: url("' + base + '.eot");\n  src: url("' + base + '.eot?#iefix") format("embedded-opentype"),\n       url("' + base + '.woff2") format("woff2"),\n       url("' + base + '.woff") format("woff"),\n       url("' + base + '.ttf") format("truetype"),\n       url("' + base + '.svg#' + base + '") format("svg");\n  font-weight: ' + font.os2.weight + ';\n  font-style: ' + ((font.head.macStyle & 2) ? 'italic' : 'normal') + ';\n  font-display: swap;\n}\n';
    var html = '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + fam + '</title><link rel="stylesheet" href="' + base + '.css"><style>body{font-family:"' + fam + '",sans-serif;font-size:28px;padding:24px;line-height:1.8}</style></head><body><p contenteditable="true">' + (sample || 'نمونهٔ متن — The quick brown fox — ۰۱۲۳۴۵۶۷۸۹') + '</p></body></html>';
    return makeZip([{ name: base + '.ttf', data: ttf }, { name: base + '.woff', data: woff }, { name: base + '.woff2', data: woff2 }, { name: base + '.eot', data: eot }, { name: base + '.svg', data: svg }, { name: base + '.css', data: css }, { name: 'demo.html', data: html }]);
  }
  function buildAndroidPackage(font, ttf) {
    var base = slug(famName(font)).replace(/-/g, '_'), fam = famName(font);
    var xml = '<?xml version="1.0" encoding="utf-8"?>\n<font-family xmlns:android="http://schemas.android.com/apk/res/android">\n    <font android:font="@font/' + base + '" android:fontStyle="' + ((font.head.macStyle & 2) ? 'italic' : 'normal') + '" android:fontWeight="' + font.os2.weight + '" />\n</font-family>\n';
    var readme = 'استفادهٔ پروژهٔ اندروید\n=======================\n۱) پوشهٔ res/font را در app/src/main/res کپی کنید.\n۲) XML:   android:fontFamily="@font/' + base + '_family"\n۳) Compose: val ' + base + ' = FontFamily(Font(R.font.' + base + '))\n';
    return makeZip([{ name: 'res/font/' + base + '.ttf', data: ttf }, { name: 'res/font/' + base + '_family.xml', data: xml }, { name: 'README.txt', data: readme }]);
  }

  /* ---------- پروژه (.dfproj) ---------- */
  function b64(u8) { var s = '', st = 0x8000; for (var i = 0; i < u8.length; i += st) s += String.fromCharCode.apply(null, u8.subarray(i, i + st)); return btoa(s); }
  function unb64(s) { var b = atob(s), o = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) o[i] = b.charCodeAt(i); return o; }
  function saveProject(font, meta) {
    var o = {
      format: 'dabireh-font-project', version: 1, savedAt: new Date().toISOString(), meta: meta || {},
      upm: font.upm, head: font.head, hhea: font.hhea, os2: font.os2, post: font.post, names: font.names, flavor: font.flavor, ownKern: font.ownKern || null,
      origGlyphCount: font.origGlyphCount, origIds: font.origIds || null, reordered: !!font.reordered, origNames: font.origNames,
      glyphs: font.glyphs.map(function (g) { var f = []; g.contours.forEach(function (c) { f.push(c.map(function (p) { return [p.x, p.y, p.on ? 1 : 0]; })); }); return { n: g.name, a: g.adv, u: g.unicodes, c: f }; }),
      extra: {}
    };
    Object.keys(font.extra).forEach(function (t) { o.extra[t] = b64(font.extra[t]); });
    return enc.encode(JSON.stringify(o));
  }
  function loadProject(u8) {
    var o = JSON.parse(dec.decode(u8));
    if (o.format !== 'dabireh-font-project') throw new Error('پروژهٔ معتبر نیست');
    var font = {
      upm: o.upm, head: o.head, hhea: o.hhea, os2: o.os2, post: o.post, names: o.names, flavor: o.flavor || 'ttf', ownKern: o.ownKern || null, extra: {}, warnings: [],
      origGlyphCount: o.origGlyphCount, origIds: o.origIds, reordered: !!o.reordered, origNames: o.origNames || [],
      glyphs: o.glyphs.map(function (g) { return { name: g.n, adv: g.a, unicodes: g.u || [], contours: g.c.map(function (c) { return c.map(function (p) { return { x: p[0], y: p[1], on: !!p[2] }; }); }) }; })
    };
    Object.keys(o.extra || {}).forEach(function (t) { font.extra[t] = unb64(o.extra[t]); });
    font.snapshot = font.glyphs.map(function (g) { return JSON.parse(JSON.stringify(g.contours)); });
    return { font: font, meta: o.meta || {} };
  }

  /* ---------- ورودی هوشمند ---------- */
  function looksSfnt(u8, o) {
    if (o + 12 > u8.length) return false;
    var s = String.fromCharCode(u8[o], u8[o + 1], u8[o + 2], u8[o + 3]), nt = (u8[o + 4] << 8) | u8[o + 5];
    if (!(s === '\0\x01\0\0' || s === 'OTTO' || s === 'true' || s === 'wOFF')) return false;
    if (nt < 4 || nt > 80) return false;
    var sr = 1; while (sr * 2 <= nt) sr *= 2;
    return s === 'wOFF' ? true : (((u8[o + 6] << 8) | u8[o + 7]) === sr * 16);
  }
  async function scanEmbedded(u8) {
    for (var o = 0; o < u8.length - 12; o++) if (u8[o] <= 0x77 && (u8[o] === 0 || u8[o] === 0x4F || u8[o] === 0x74 || u8[o] === 0x77) && looksSfnt(u8, o)) return u8.subarray(o);
    var tried = 0;
    for (o = 0; o < u8.length - 6 && tried < 60; o++) {
      if (u8[o] === 0x78 && (u8[o + 1] === 0x9C || u8[o + 1] === 0xDA || u8[o + 1] === 0x01 || u8[o + 1] === 0x5E)) {
        tried++;
        try { var d = await stream('deflate', 'd', u8.subarray(o)); var r = await scanEmbeddedRaw(d); if (r) return r; } catch (e) { }
      }
    }
    return null;
  }
  function scanEmbeddedRaw(u8) { for (var o = 0; o < u8.length - 12; o++) if (looksSfnt(u8, o)) return u8.subarray(o); return null; }

  /* name: نام فایل. نتیجه: {font, meta, via} */
  async function openAny(u8, name) {
    var low = (name || '').toLowerCase();
    var head = String.fromCharCode(u8[0], u8[1], u8[2], u8[3]);
    if (low.endsWith('.dfproj') || (u8[0] === 0x7B && dec.decode(u8.subarray(0, 80)).indexOf('dabireh-font-project') > 0)) { var p = loadProject(u8); return { font: p.font, meta: p.meta, via: 'project' }; }
    if (head === 'wOF2') throw new Error('WOFF2 فشرده‌شده با Brotli را نمی‌توان باز کرد؛ فایل TTF/OTF/WOFF همان فونت را باز کنید.');
    if (head === 'wOFF') return { font: FS.sfnt.loadFont(await fromWoff(u8)), via: 'woff' };
    if (looksSfnt(u8, 0) || head === 'ttcf') return { font: FS.sfnt.loadFont(u8), via: 'sfnt' };
    var emb = await scanEmbedded(u8);
    if (emb) { var e2 = String.fromCharCode(emb[0], emb[1], emb[2], emb[3]) === 'wOFF' ? await fromWoff(emb) : emb; var f = FS.sfnt.loadFont(e2); f.warnings.push('فونت از داخل فایل ' + (name || '') + ' بیرون کشیده شد (قالب پروژهٔ اختصاصی ممکن است تنظیمات اضافه‌ای داشته باشد که منتقل نمی‌شود).'); return { font: f, via: 'embedded' }; }
    throw new Error('این قالب شناخته نشد. قالب‌های پشتیبانی‌شده: TTF، OTF، TTC، WOFF، پروژهٔ .dfproj، و فایل‌هایی که فونت داخلشان ذخیره شده (مثل برخی .fcp).');
  }

  FS.io = { toWoff: toWoff, fromWoff: fromWoff, toWoff2: toWoff2, toEot: toEot, toSvgFont: toSvgFont, makeZip: makeZip, buildWebPackage: buildWebPackage, buildAndroidPackage: buildAndroidPackage, saveProject: saveProject, loadProject: loadProject, openAny: openAny, crc32: crc32, famName: famName, slug: slug };
  FS.geom = { explicit: explicit, normalized: normalized, pathD: pathD };
  if (typeof module !== 'undefined') module.exports = FS;
})(typeof window !== 'undefined' ? window : globalThis);
