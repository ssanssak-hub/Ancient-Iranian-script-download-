/* Font Studio Ultra 4 (1.9.0) — ابزارهای پیشرفتهٔ ایمن برای هندسه و متریک
   ۱) ترمیم extrema برای منحنی‌ها
   ۲) یکسان‌سازی هوشمند sidebearing چپ/راست
   ۳) فیت عمودی کنترل‌شدهٔ جوهر نسبت به baseline و ارتفاع هدف
   ۴) اسکن کیفیت هندسه و گزارش نقاط/کانتورهای مشکوک
   بدون API جدید اپ، بدون کتابخانهٔ خارجی و با Undo برای تغییرات. */
(function(root){
'use strict';
var FS=root.FS=root.FS||{}, A=root.StudioApp;
if(!A) return;
var S=A.S;
function T(a,b){return A.T?A.T(a,b):a;}
function esc(s){return A.esc?A.esc(s):String(s).replace(/[&<>\"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c];});}
function num(v,d){var x=Number(v);return Number.isFinite(x)?x:d;}
function scopeIdx(f,mode,rg,gi){
 var out=[],n=f.glyphs.length,a,b,i;
 if(mode==='cur') return [gi];
 if(mode==='range'){
  var q=String(rg||'').split('-');
  a=Math.max(0,Math.min(n-1,Math.floor(num(q[0],0))));
  b=Math.max(a,Math.min(n-1,Math.floor(num(q[1],n-1))));
  for(i=a;i<=b;i++) out.push(i); return out;
 }
 for(i=0;i<n;i++) out.push(i); return out;
}
function bbox(g){return FS.sfnt.bboxOf(g.contours);}
function touch(gi){
 S.ttf=null;S.dirty=true;
 try{A.Host&&A.Host.setUnsaved&&A.Host.setUnsaved(true);}catch(_){ }
 try{if(S.ed){S.ed.sel={};S.ed.draw();}}catch(_){ }
 if(A.changed&&S.font&&S.font.glyphs.length) A.changed(Math.max(0,Math.min(gi|0,S.font.glyphs.length-1)),true);
}
function runBatch(idx,fn,msg){
 return (async function(){
  var items=[],errors=[],info=[],t0=Date.now();
  for(var k=0;k<idx.length;k++){
   var gi=idx[k],g=S.font.glyphs[gi],before=FS.editor.snap(g),r=null;
   try{
    r=fn(g,gi); if(r) info.push({gi:gi,r:r});
    var after=FS.editor.snap(g);
    if(JSON.stringify(before)!==JSON.stringify(after)) items.push({gi:gi,before:before,after:after});
   }catch(e){
    try{FS.editor.restore(g,before);}catch(_){throw e;}
    errors.push({gi:gi,error:e&&e.message?e.message:String(e)});
   }
   if(Date.now()-t0>400&&k%8===7){await A.busy(msg+' '+(k+1)+'/'+idx.length);t0=Date.now();}
  }
  await A.busy('');
  if(items.length){A.pushHistory(items);touch(items[0].gi);}
  return {changed:items.length,errors:errors,info:info};
 })();
}
function guard(fn){return function(){var self=this,args=arguments;Promise.resolve().then(function(){return fn.apply(self,args);}).catch(function(e){try{A.busy('');}catch(_){}A.fail(e);});};}
function card(title,desc,body,out){return '<section class="card ul-card"><h3>'+title+'</h3><div class="muted">'+desc+'</div>'+body+(out?'<div class="ul-out" id="'+out+'"></div>':'')+'</section>';}
function field(id,label,value,attrs){return '<label class="f">'+esc(label)+'<input id="'+id+'" type="number" dir="ltr" value="'+esc(value)+'" '+(attrs||'')+'></label>';}
function chk(id,label,on){return '<label class="chk"><input id="'+id+'" type="checkbox" '+(on?'checked':'')+'>'+esc(label)+'</label>';}
function scopeHTML(p,def){return '<div class="row"><label class="f">'+T('محدوده','Scope')+'<select id="'+p+'Sc"><option value="all"'+(def==='all'?' selected':'')+'>'+T('همهٔ گلیف‌ها','All glyphs')+'</option><option value="cur"'+(def==='cur'?' selected':'')+'>'+T('گلیف فعلی','Current glyph')+'</option><option value="range">'+T('بازه','Range')+'</option></select></label><label class="f">'+T('بازه','Range')+'<input id="'+p+'Rg" dir="ltr" placeholder="0-100" style="width:110px"></label></div>';}
function quality(g){
 var dup=0,short=0,tiny=0,zero=0,off=0,points=0;
 (g.contours||[]).forEach(function(c){
  if(c.length<2) short++;
  points+=c.length;
  for(var i=0;i<c.length;i++){
   var p=c[i],q=c[(i+1)%c.length];
   if(p.x===q.x&&p.y===q.y) dup++;
   if(!p.on) off++;
  }
  if(Math.abs(FS.editor.signedArea(c))<1) tiny++;
 });
 if(!g.contours||!g.contours.length) zero=1;
 return {contours:(g.contours||[]).length,points:points,dup:dup,short:short,tiny:tiny,off:off,empty:zero};
}
function openLab(){
 var f=S.font;if(!f){A.toast(T('ابتدا یک فونت باز کنید','Open a font first'));return;}
 var m=document.createElement('div');m.className='fs-lab ul-lab';
 m.innerHTML='<div class="fs-lab-head"><div><h2>🧠 Font Studio Ultra 4</h2><div class="muted">'+esc(A.fam())+' · UPM '+f.upm+' · '+f.glyphs.length+' glyphs</div></div><button class="b" id="u4Close">✕</button></div><div id="u4Body"></div>';
 document.body.appendChild(m);var body=m.querySelector('#u4Body');
 body.innerHTML=
 card('📐 '+T('ترمیم extrema','Extrema Repair'),T('نقاط extrema را برای منحنی‌های درجه‌دو اضافه می‌کند تا خروجی هندسی پایدارتر و مناسب‌تر برای رندر و export شود.','Adds curve extrema points to make quadratic outlines more stable for rendering and export.'),scopeHTML('e','all')+'<div class="row">'+chk('eNorm',T('پس از ترمیم، مختصات نرمال شود','Normalize coordinates after repair'),true)+'</div><div class="row"><button class="b p" id="eGo">'+T('ترمیم extrema','Repair extrema')+'</button></div>','eOut')+
 card('↔️ '+T('یکسان‌سازی هوشمند sidebearing','Smart Sidebearing Equalizer'),T('فاصلهٔ چپ و راست جوهر را تا حد ممکن برابر می‌کند؛ advance ثابت می‌ماند و فقط طرح جابه‌جا می‌شود. گلیف‌های بدون طرح و advance صفر رد می‌شوند.','Balances left and right ink sidebearings while keeping advance unchanged. Empty and zero-advance glyphs are skipped.'),scopeHTML('s','all')+'<div class="row">'+field('sTol',T('حداقل اختلاف برای اصلاح','Minimum difference to correct'),1,'min="0" step="0.5"')+'</div><div class="row"><button class="b p" id="sGo">'+T('یکسان‌سازی','Equalize')+'</button></div>','sOut')+
 card('↕️ '+T('فیت عمودی کنترل‌شده','Controlled Vertical Fit'),T('جوهر را با حفظ نسبت افقی، بین baseline و سقف هدف قرار می‌دهد. برای حروف با ارتفاع‌های مختلف مفید است و از تقسیم بر صفر و گلیف‌های خالی جلوگیری می‌کند.','Fits ink between a target baseline and top while preserving horizontal scale. Empty glyphs and degenerate bounds are safely skipped.'),scopeHTML('v','all')+'<div class="row">'+field('vBase',T('baseline هدف','Target baseline'),0,'step="1"')+field('vTop',T('سقف هدف','Target top'),700,'step="1" min="1"')+'</div><div class="row">'+chk('vScale',T('مقیاس عمودی اعمال شود','Scale vertically'),true)+chk('vKeepAdv',T('advance ثابت بماند','Keep advance unchanged'),true)+'</div><div class="row"><button class="b p" id="vGo">'+T('فیت عمودی','Fit vertically')+'</button></div>','vOut')+
 card('🔎 '+T('اسکن کیفیت هندسه','Geometry Quality Scan'),T('بدون تغییر فونت، موارد مشکوک مثل نقاط تکراری، کانتور کوتاه، کانتور بسیار کوچک و نقاط off-curve را گزارش می‌کند.','Non-destructive scan for duplicate points, short contours, tiny contours, and off-curve points.'),scopeHTML('q','all')+'<div class="row"><button class="b p" id="qGo">'+T('اسکن فونت','Scan font')+'</button></div>','qOut');
 function say(id,txt){var q=m.querySelector('#'+id);if(q)q.textContent=txt;if(txt)A.toast(String(txt).split('\n')[0]);}
 m.querySelector('#u4Close').onclick=function(){m.remove();};
 m.querySelector('#eGo').onclick=guard(async function(){
  var idx=scopeIdx(f,m.querySelector('#eSc').value,m.querySelector('#eRg').value,S.gi),res=await runBatch(idx,function(g){if(!g.contours||!g.contours.length)return null;FS.editor.addExtrema(g);if(m.querySelector('#eNorm').checked)FS.editor.normalizeGlyph(g);return {ok:true};},T('ترمیم extrema…','Repairing extrema…'));
  say('eOut',res.changed+' '+T('گلیف ترمیم شد ✔','glyphs repaired ✔')+(res.errors.length?' · '+res.errors.length+' '+T('خطا','errors'):''));
 });
 m.querySelector('#sGo').onclick=guard(async function(){
  var idx=scopeIdx(f,m.querySelector('#sSc').value,m.querySelector('#sRg').value,S.gi),tol=Math.max(0,num(m.querySelector('#sTol').value,1)),res=await runBatch(idx,function(g){if(!g.contours||!g.contours.length||g.adv<=0)return null;var b=bbox(g);if(!b)return null;var l=b.x0,r=g.adv-b.x1,d=(r-l)/2;if(Math.abs(d)<tol)return null;var dx=Math.round(d);if(!dx)return null;g.contours.forEach(function(c){c.forEach(function(p){p.x+=dx;});});FS.editor.normalizeGlyph(g);return {dx:dx};},T('یکسان‌سازی sidebearing…','Equalizing sidebearings…'));
  say('sOut',res.changed+' '+T('گلیف اصلاح شد ✔','glyphs adjusted ✔')+(res.errors.length?' · '+res.errors.length+' '+T('خطا','errors'):''));
 });
 m.querySelector('#vGo').onclick=guard(async function(){
  var idx=scopeIdx(f,m.querySelector('#vSc').value,m.querySelector('#vRg').value,S.gi),base=num(m.querySelector('#vBase').value,0),top=num(m.querySelector('#vTop').value,700),scale=m.querySelector('#vScale').checked,keep=m.querySelector('#vKeepAdv').checked;
  if(top<=base){say('vOut',T('سقف باید بالاتر از baseline باشد','Top must be above baseline'));return;}
  var res=await runBatch(idx,function(g){if(!g.contours||!g.contours.length)return null;var b=bbox(g);if(!b||b.y1<=b.y0)return null;var k=(top-base)/(b.y1-b.y0),dy=base-b.y0;if(!scale)k=1;g.contours.forEach(function(c){c.forEach(function(p){p.y=Math.round(base+(p.y-b.y0)*k);});});if(!keep&&scale)g.adv=Math.max(0,Math.round(g.adv));FS.editor.normalizeGlyph(g);return {scale:k};},T('فیت عمودی…','Fitting vertically…'));
  say('vOut',res.changed+' '+T('گلیف فیت شد ✔','glyphs fitted ✔')+(res.errors.length?' · '+res.errors.length+' '+T('خطا','errors'):''));
 });
 m.querySelector('#qGo').onclick=guard(async function(){
  var idx=scopeIdx(f,m.querySelector('#qSc').value,m.querySelector('#qRg').value,S.gi),tot={glyphs:idx.length,dup:0,short:0,tiny:0,empty:0,points:0,off:0};
  idx.forEach(function(gi){var r=quality(f.glyphs[gi]);tot.dup+=r.dup;tot.short+=r.short;tot.tiny+=r.tiny;tot.empty+=r.empty;tot.points+=r.points;tot.off+=r.off;});
  say('qOut',T('گلیف‌ها: ','Glyphs: ')+tot.glyphs+' · '+T('نقاط: ','Points: ')+tot.points+' · '+T('تکراری: ','Duplicates: ')+tot.dup+' · '+T('کانتور کوتاه: ','Short contours: ')+tot.short+' · '+T('کانتور کوچک: ','Tiny contours: ')+tot.tiny+' · '+T('off-curve: ','Off-curve: ')+tot.off+' · '+T('خالی: ','Empty: ')+tot.empty);
 });
}
function panel(mm){var d=document.createElement('details');d.innerHTML='<summary>🧠 '+T('Font Studio Ultra 4 — هندسه و متریک پیشرفته','Font Studio Ultra 4 — Advanced Geometry & Metrics')+'</summary><div class="muted">'+T('چهار ابزار جدید؛ بدون نیاز به تغییر اپ.','Four new tools; no app update required.')+'</div><button class="b p" id="u4Open">🧠 '+T('باز کردن Ultra 4','Open Ultra 4')+'</button>';mm.appendChild(d);d.querySelector('#u4Open').onclick=openLab;}
var old=A.afterTools;A.afterTools=function(mm){if(old)old(mm);panel(mm);};
root.StudioUltra4={quality:quality,open:openLab};
})(window);
