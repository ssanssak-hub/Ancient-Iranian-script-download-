/* Font Studio Ultra Plus (1.7.0) — دو ابزار پیشرفتهٔ تازه؛ JS خالص، بدون نیاز به آپدیت اپ
   ۱) حذف همپوشانی (Remove Overlap): اجتماع واقعی کانتورها با حفظ منحنی‌های درجه‌دو (بدون تبدیل به چندضلعی)
   ۲) ناحیه‌های هم‌ترازی و اُورشوت (Alignment Zones): تشخیص خودکار خط پایه/ارتفاع‌ها و چسباندن نقاط حدیِ نزدیک به آن‌ها */
(function (root) {
'use strict';
var FS = root.FS = root.FS || {};

/* =====================================================================
   بخش ۱ — حذف همپوشانی
   مدل: هر کانتور = دنباله‌ای از پاره‌خط/منحنی درجه‌دو. قاعدهٔ پر شدن = nonzero (مثل TrueType/OTF).
   روش: ۱) یافتن همهٔ تقاطع‌ها و شکستن پاره‌ها  ۲) نگه‌داشتن پاره‌هایی که یک سمتشان داخل و سمت دیگر بیرون است
        ۳) جهت‌دهی (پرشده سمت راست) و زنجیره‌کردن به کانتور  ۴) راستی‌آزمایی نمونه‌برداری؛ اگر نخواند، گلیف دست‌نخورده می‌ماند.
   ===================================================================== */
var VTOL = 0.3, ETOL = 0.3, DELTA = 0.03;

function mkSeg(id, cid, q, a, c, b) {
  var s = { id: id, cid: cid, q: q, x0: a.x, y0: a.y, x1: b.x, y1: b.y, cx: q ? c.x : (a.x + b.x) / 2, cy: q ? c.y : (a.y + b.y) / 2, v0: -1, v1: -1 };
  s.bx0 = Math.min(s.x0, s.cx, s.x1); s.bx1 = Math.max(s.x0, s.cx, s.x1); s.by0 = Math.min(s.y0, s.cy, s.y1); s.by1 = Math.max(s.y0, s.cy, s.y1);
  return s;
}
function buildSegs(contours) {
  var segs = [];
  (contours || []).forEach(function (c, cid) {
    var e = FS.geom.normalized(c); if (!e || e.length < 2) return;
    var n = e.length, cur = e[0], i = 1;
    while (i <= n) {
      var p = e[i % n];
      if (p.on) { if (p.x !== cur.x || p.y !== cur.y) segs.push(mkSeg(segs.length, cid, false, cur, null, p)); cur = p; i++; }
      else { var q = e[(i + 1) % n]; segs.push(mkSeg(segs.length, cid, true, cur, p, q)); cur = q; i += 2; }
    }
  });
  return segs;
}
function ptAt(s, t) { var u = 1 - t; return s.q ? { x: u * u * s.x0 + 2 * u * t * s.cx + t * t * s.x1, y: u * u * s.y0 + 2 * u * t * s.cy + t * t * s.y1 } : { x: s.x0 + (s.x1 - s.x0) * t, y: s.y0 + (s.y1 - s.y0) * t }; }
function dAt(s, t) { return s.q ? { x: 2 * ((1 - t) * (s.cx - s.x0) + t * (s.x1 - s.cx)), y: 2 * ((1 - t) * (s.cy - s.y0) + t * (s.y1 - s.cy)) } : { x: s.x1 - s.x0, y: s.y1 - s.y0 }; }
function subCurve(s, t0, t1) {
  var a = ptAt(s, t0), b = ptAt(s, t1);
  if (!s.q) return { q: false, x0: a.x, y0: a.y, cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2, x1: b.x, y1: b.y };
  var u = 1 - t0, k = t1 - t0;
  return { q: true, x0: a.x, y0: a.y, cx: a.x + k * (u * (s.cx - s.x0) + t0 * (s.x1 - s.cx)), cy: a.y + k * (u * (s.cy - s.y0) + t0 * (s.y1 - s.cy)), x1: b.x, y1: b.y };
}
function bb(s) { return { x0: Math.min(s.x0, s.cx, s.x1), x1: Math.max(s.x0, s.cx, s.x1), y0: Math.min(s.y0, s.cy, s.y1), y1: Math.max(s.y0, s.cy, s.y1) }; }
function overlap(a, b, e) { return a.x0 <= b.x1 + e && b.x0 <= a.x1 + e && a.y0 <= b.y1 + e && b.y0 <= a.y1 + e; }
function flat(s) {
  if (!s.q) return true;
  var dx = s.x1 - s.x0, dy = s.y1 - s.y0, l = Math.hypot(dx, dy);
  if (l < 1e-9) return Math.hypot(s.cx - s.x0, s.cy - s.y0) < 0.02;
  return Math.abs((s.cx - s.x0) * dy - (s.cy - s.y0) * dx) / l <= 0.02;
}
function chordHit(S, T) {
  var d1x = S.x1 - S.x0, d1y = S.y1 - S.y0, d2x = T.x1 - T.x0, d2y = T.y1 - T.y0, den = d1x * d2y - d1y * d2x;
  if (Math.abs(den) < 1e-12 * (Math.hypot(d1x, d1y) * Math.hypot(d2x, d2y) + 1e-30)) return null;
  var sx = T.x0 - S.x0, sy = T.y0 - S.y0, u = (sx * d2y - sy * d2x) / den, v = (sx * d1y - sy * d1x) / den, e = 1e-6;
  if (u < -e || u > 1 + e || v < -e || v > 1 + e) return null;
  return [Math.max(0, Math.min(1, u)), Math.max(0, Math.min(1, v))];
}
function recInter(A, a0, a1, B, b0, b1, depth, res) {
  if (res.length > 64) return;
  var SA = subCurve(A, a0, a1), SB = subCurve(B, b0, b1);
  if (!overlap(bb(SA), bb(SB), 1e-7)) return;
  var fa = flat(SA), fb = flat(SB);
  if ((fa && fb) || depth >= 26) { var h = chordHit(SA, SB); if (h) res.push([a0 + h[0] * (a1 - a0), b0 + h[1] * (b1 - b0)]); return; }
  var am = (a0 + a1) / 2, bm = (b0 + b1) / 2;
  if (!fa && !fb) { recInter(A, a0, am, B, b0, bm, depth + 1, res); recInter(A, a0, am, B, bm, b1, depth + 1, res); recInter(A, am, a1, B, b0, bm, depth + 1, res); recInter(A, am, a1, B, bm, b1, depth + 1, res); }
  else if (!fa) { recInter(A, a0, am, B, b0, b1, depth + 1, res); recInter(A, am, a1, B, b0, b1, depth + 1, res); }
  else { recInter(A, a0, a1, B, b0, bm, depth + 1, res); recInter(A, a0, a1, B, bm, b1, depth + 1, res); }
}
function refine(A, B, ta, tb) {
  for (var it = 0; it < 4; it++) {
    var pa = ptAt(A, ta), pb = ptAt(B, tb), da = dAt(A, ta), db = dAt(B, tb), rx = pb.x - pa.x, ry = pb.y - pa.y, det = -da.x * db.y + db.x * da.y;
    if (Math.abs(det) < 1e-12) break;
    var na = ta + (-rx * db.y + db.x * ry) / det, nb = tb + (da.x * ry - da.y * rx) / det;
    ta = Math.max(0, Math.min(1, na)); tb = Math.max(0, Math.min(1, nb));
  }
  return [ta, tb];
}
function intersectPair(A, B) {
  var out = [];
  if (!overlap(bb(A), bb(B), 1e-7)) return out;
  if (!A.q && !B.q) { var h = chordHit(A, B); if (h) out.push(h); return out; }
  var raw = []; recInter(A, 0, 1, B, 0, 1, 0, raw);
  raw.forEach(function (r) {
    var f = refine(A, B, r[0], r[1]);
    for (var i = 0; i < out.length; i++) if (Math.abs(out[i][0] - f[0]) < 1e-4 && Math.abs(out[i][1] - f[1]) < 1e-4) return;
    out.push(f);
  });
  return out;
}
function closestT(s, x, y) {
  if (!s.q) { var dx = s.x1 - s.x0, dy = s.y1 - s.y0, l2 = dx * dx + dy * dy; if (!l2) return { t: 0, d: Math.hypot(x - s.x0, y - s.y0) }; var t = Math.max(0, Math.min(1, ((x - s.x0) * dx + (y - s.y0) * dy) / l2)); return { t: t, d: Math.hypot(x - (s.x0 + dx * t), y - (s.y0 + dy * t)) }; }
  var best = 0, bd = Infinity, k;
  for (k = 0; k <= 16; k++) { var p = ptAt(s, k / 16), d = (p.x - x) * (p.x - x) + (p.y - y) * (p.y - y); if (d < bd) { bd = d; best = k / 16; } }
  var t2 = best;
  for (k = 0; k < 6; k++) {
    var pp = ptAt(s, t2), dd = dAt(s, t2), ex = pp.x - x, ey = pp.y - y, sec = { x: 2 * (s.x1 - 2 * s.cx + s.x0), y: 2 * (s.y1 - 2 * s.cy + s.y0) };
    var num = ex * dd.x + ey * dd.y, den = dd.x * dd.x + dd.y * dd.y + ex * sec.x + ey * sec.y;
    if (Math.abs(den) < 1e-12) break; t2 = Math.max(0, Math.min(1, t2 - num / den));
  }
  var q = ptAt(s, t2); return { t: t2, d: Math.hypot(q.x - x, q.y - y) };
}

/* ---- نقطه‌های مشترک (خوشه‌بندی با تلورانس) ---- */
function VertexSet() { this.v = []; this.g = {}; }
VertexSet.prototype.get = function (x, y) {
  var gx = Math.floor(x / 0.5), gy = Math.floor(y / 0.5), i, j, k, a;
  for (i = -1; i <= 1; i++) for (j = -1; j <= 1; j++) { a = this.g[(gx + i) + ',' + (gy + j)]; if (a) for (k = 0; k < a.length; k++) { var p = this.v[a[k]]; if (Math.abs(p.x - x) <= VTOL && Math.abs(p.y - y) <= VTOL) return a[k]; } }
  this.v.push({ x: x, y: y }); var key = gx + ',' + gy; (this.g[key] = this.g[key] || []).push(this.v.length - 1); return this.v.length - 1;
};

/* ---- عدد پیچش (winding) دقیق روی منحنی‌های درجه‌دو ---- */
function buildPieces(segs) {
  var P = [];
  segs.forEach(function (s) {
    if (!s.q) { if (s.y0 !== s.y1) P.push({ q: false, x0: s.x0, y0: s.y0, x1: s.x1, y1: s.y1 }); return; }
    var den = s.y0 - 2 * s.cy + s.y1, te = den ? (s.y0 - s.cy) / den : -1, parts = [];
    if (te > 1e-9 && te < 1 - 1e-9) { parts.push(subCurve(s, 0, te)); parts.push(subCurve(s, te, 1)); } else parts.push(s);
    parts.forEach(function (p) { if (p.y0 !== p.y1) P.push({ q: true, x0: p.x0, y0: p.y0, cx: p.cx, cy: p.cy, x1: p.x1, y1: p.y1 }); });
  });
  return P;
}
function windingAt(P, px, py) {
  var w = 0;
  for (var i = 0; i < P.length; i++) {
    var s = P[i], ya = s.y0, yb = s.y1; if ((ya <= py) === (yb <= py)) continue;
    var x;
    if (!s.q) x = s.x0 + (py - ya) * (s.x1 - s.x0) / (yb - ya);
    else {
      var a = ya - 2 * s.cy + yb, b = 2 * (s.cy - ya), c = ya - py, t;
      if (Math.abs(a) < 1e-12) t = -c / b;
      else {
        var disc = b * b - 4 * a * c; if (disc < 0) disc = 0; var sq = Math.sqrt(disc), t1 = (-b + sq) / (2 * a), t2 = (-b - sq) / (2 * a);
        var in1 = t1 >= -1e-9 && t1 <= 1 + 1e-9, in2 = t2 >= -1e-9 && t2 <= 1 + 1e-9;
        t = in1 && !in2 ? t1 : (in2 && !in1 ? t2 : (Math.abs(t1 - 0.5) < Math.abs(t2 - 0.5) ? t1 : t2));
      }
      t = Math.max(0, Math.min(1, t)); var u = 1 - t; x = u * u * s.x0 + 2 * u * t * s.cx + t * t * s.x1;
    }
    if (x > px) w += yb > ya ? 1 : -1;
  }
  return w;
}

/* ---- هستهٔ الگوریتم؛ خروجی: { contours } یا { same:true } یا { fail:'دلیل' } ---- */
function unionContours(contours) {
  var segs = buildSegs(contours), n = segs.length, i, j, VS = new VertexSet();
  if (n < 2) return { same: true };
  segs.forEach(function (s) { s.v0 = VS.get(s.x0, s.y0); s.v1 = VS.get(s.x1, s.y1); s.sp = []; });
  var hadSplit = false;
  function addSplit(s, t, vid) { if (vid === s.v0 || vid === s.v1) return; if (t <= 1e-7 || t >= 1 - 1e-7) return; s.sp.push({ t: t, v: vid }); hadSplit = true; }
  /* ۱) تقاطع‌ها */
  for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) {
    var A = segs[i], B = segs[j]; if (A.bx0 > B.bx1 + 1e-7 || B.bx0 > A.bx1 + 1e-7 || A.by0 > B.by1 + 1e-7 || B.by0 > A.by1 + 1e-7) continue;
    var hits = intersectPair(A, B);
    for (var h = 0; h < hits.length; h++) {
      var ta = hits[h][0], tb = hits[h][1], pa = ptAt(A, ta), pb = ptAt(B, tb);
      var ea = Math.hypot(pa.x - A.x0, pa.y - A.y0) < ETOL ? 0 : (Math.hypot(pa.x - A.x1, pa.y - A.y1) < ETOL ? 1 : -1);
      var eb = Math.hypot(pb.x - B.x0, pb.y - B.y0) < ETOL ? 0 : (Math.hypot(pb.x - B.x1, pb.y - B.y1) < ETOL ? 1 : -1);
      if (ea >= 0 && eb >= 0) continue;
      if (ea >= 0) addSplit(B, tb, ea === 0 ? A.v0 : A.v1);
      else if (eb >= 0) addSplit(A, ta, eb === 0 ? B.v0 : B.v1);
      else { var vid = VS.get((pa.x + pb.x) / 2, (pa.y + pb.y) / 2); addSplit(A, ta, vid); addSplit(B, tb, vid); }
    }
  }
  /* ۲) نقطهٔ انتهایی که روی بدنهٔ پارهٔ دیگر می‌افتد (T-junction و هم‌خطی) */
  for (i = 0; i < n; i++) {
    var S = segs[i];
    for (j = 0; j < n; j++) {
      if (i === j) continue; var Q = segs[j];
      [S.v0, S.v1].forEach(function (vid) {
        if (vid === Q.v0 || vid === Q.v1) return; var p = VS.v[vid];
        if (p.x < Q.bx0 - ETOL || p.x > Q.bx1 + ETOL || p.y < Q.by0 - ETOL || p.y > Q.by1 + ETOL) return;
        var c = closestT(Q, p.x, p.y); if (c.d < ETOL && c.t > 1e-4 && c.t < 1 - 1e-4) addSplit(Q, c.t, vid);
      });
    }
  }
  /* ۳) شکستن پاره‌ها */
  var subs = [];
  segs.forEach(function (s) {
    var sp = s.sp.sort(function (a, b) { return a.t - b.t; }), ts = [0], vs = [s.v0], k;
    for (k = 0; k < sp.length; k++) { if (sp[k].v === vs[vs.length - 1] || sp[k].t - ts[ts.length - 1] < 1e-7) continue; ts.push(sp[k].t); vs.push(sp[k].v); }
    ts.push(1); vs.push(s.v1);
    for (k = 0; k + 1 < ts.length; k++) { if (vs[k] === vs[k + 1]) continue; subs.push({ p: s, ta: ts[k], tb: ts[k + 1], va: vs[k], vb: vs[k + 1] }); }
  });
  /* ۴) انتخاب پاره‌هایی که مرز واقعی‌اند */
  var P = buildPieces(segs), edges = [], dropped = 0;
  subs.forEach(function (sb) {
    var tm = (sb.ta + sb.tb) / 2, m = ptAt(sb.p, tm), d = dAt(sb.p, tm), l = Math.hypot(d.x, d.y);
    if (l < 1e-9) { var A0 = VS.v[sb.va], B0 = VS.v[sb.vb]; d = { x: B0.x - A0.x, y: B0.y - A0.y }; l = Math.hypot(d.x, d.y); if (l < 1e-9) { dropped++; return; } }
    var nx = -d.y / l, ny = d.x / l, wl = windingAt(P, m.x + nx * DELTA, m.y + ny * DELTA), wr = windingAt(P, m.x - nx * DELTA, m.y - ny * DELTA), inL = wl !== 0, inR = wr !== 0;
    if (inL === inR) { dropped++; return; }
    var rev = inL; /* پرشده باید سمت راست باشد */
    var sc = subCurve(sb.p, sb.ta, sb.tb);
    edges.push({ s: rev ? sb.vb : sb.va, e: rev ? sb.va : sb.vb, p: sb.p, tf: rev ? sb.tb : sb.ta, tt: rev ? sb.ta : sb.tb, q: sb.p.q, cx: sc.cx, cy: sc.cy });
  });
  if (!edges.length) return (hadSplit || dropped) ? { contours: [] } : { same: true };
  /* حذف لبه‌های کاملاً یکسان (کانتور تکراری هم همپوشانی حساب می‌شود) */
  var seen = {}, uniq = [];
  edges.forEach(function (e) { var k = e.s + '>' + e.e + (e.q ? ':' + Math.round(e.cx * 10) + ',' + Math.round(e.cy * 10) : ''); if (seen[k]) return; seen[k] = 1; uniq.push(e); });
  if (!hadSplit && !dropped && uniq.length === edges.length) return { same: true };
  edges = uniq;
  /* ۵) زنجیره‌کردن */
  function dirOut(e) { var a = VS.v[e.s], b = VS.v[e.e], x = e.q ? e.cx - a.x : b.x - a.x, y = e.q ? e.cy - a.y : b.y - a.y; if (Math.abs(x) + Math.abs(y) < 1e-9) { x = b.x - a.x; y = b.y - a.y; } return { x: x, y: y }; }
  function dirIn(e) { var a = VS.v[e.s], b = VS.v[e.e], x = e.q ? b.x - e.cx : b.x - a.x, y = e.q ? b.y - e.cy : b.y - a.y; if (Math.abs(x) + Math.abs(y) < 1e-9) { x = b.x - a.x; y = b.y - a.y; } return { x: x, y: y }; }
  var outs = {}; edges.forEach(function (e) { (outs[e.s] = outs[e.s] || []).push(e); });
  var loops = [], bridges = 0, GAP = 4;
  (function () { var x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity; segs.forEach(function (s) { x0 = Math.min(x0, s.bx0); x1 = Math.max(x1, s.bx1); y0 = Math.min(y0, s.by0); y1 = Math.max(y1, s.by1); }); GAP = Math.max(4, Math.min(24, Math.max(x1 - x0, y1 - y0) * 0.012)); })();
  for (i = 0; i < edges.length; i++) {
    var first = edges[i]; if (first.used) continue;
    var loop = [first], cur = first; first.used = true; var guard = 0;
    while (cur.e !== first.s) {
      if (++guard > edges.length + 2) return { fail: 'زنجیره بسته نشد' };
      var cand = (outs[cur.e] || []).filter(function (x) { return !x.used; });
      if (!cand.length) {
        /* لبهٔ بسیار کوچکِ حذف‌شده در برخوردهای تقریباً مماس: شکاف کوچک با یک خط بسته می‌شود (راستی‌آزمایی بعداً بررسی می‌کند) */
        var fr = VS.v[cur.e], bd2 = GAP * GAP, tgt = -1, fs0 = VS.v[first.s], dd0 = (fs0.x - fr.x) * (fs0.x - fr.x) + (fs0.y - fr.y) * (fs0.y - fr.y);
        if (dd0 < bd2) { bd2 = dd0; tgt = first.s; }
        edges.forEach(function (x) { if (x.used) return; var a = VS.v[x.s], d2 = (a.x - fr.x) * (a.x - fr.x) + (a.y - fr.y) * (a.y - fr.y); if (d2 < bd2) { bd2 = d2; tgt = x.s; } });
        if (tgt < 0 || tgt === cur.e) return { fail: 'کانتور باز ماند' };
        var br = { s: cur.e, e: tgt, p: null, q: false, cx: 0, cy: 0, tf: 0, tt: 0, used: true }; loop.push(br); cur = br; bridges++; continue;
      }
      var nx2 = cand[0];
      if (cand.length > 1) {
        var din = dirIn(cur), bestA = Infinity;
        cand.forEach(function (c2) { var dout = dirOut(c2), ang = Math.atan2(din.x * dout.y - din.y * dout.x, din.x * dout.x + din.y * dout.y); if (ang > Math.PI - 1e-9) ang -= 2 * Math.PI; if (ang < bestA) { bestA = ang; nx2 = c2; } });
      }
      nx2.used = true; loop.push(nx2); cur = nx2;
    }
    loops.push(loop);
  }
  /* ۶) ادغام تکه‌های پشت‌سرهم از یک پارهٔ اصلی و ساخت نقطه‌ها */
  var out = [];
  loops.forEach(function (loop) {
    var L = loop.map(function (e) { return { s: e.s, e: e.e, p: e.p, tf: e.tf, tt: e.tt, q: e.q, cx: e.cx, cy: e.cy }; }), k = 0;
    function mergeable(a, b) { return a.p && a.p === b.p && a.tt === b.tf && ((a.tf < a.tt) === (b.tf < b.tt)); }
    function fuse(a, b) { a.e = b.e; a.tt = b.tt; var lo = Math.min(a.tf, a.tt), hi = Math.max(a.tf, a.tt), sc = subCurve(a.p, lo, hi); a.cx = sc.cx; a.cy = sc.cy; }
    while (k + 1 < L.length) { if (mergeable(L[k], L[k + 1])) { fuse(L[k], L[k + 1]); L.splice(k + 1, 1); } else k++; }
    if (L.length > 1 && mergeable(L[L.length - 1], L[0])) { fuse(L[L.length - 1], L[0]); L.shift(); }
    var pts = [];
    L.forEach(function (e) { var a = VS.v[e.s]; pts.push({ x: a.x, y: a.y, on: true }); if (e.q) pts.push({ x: e.cx, y: e.cy, on: false }); });
    out.push(pts);
  });
  return { contours: out };
}

function roundContours(cs) {
  var res = [];
  cs.forEach(function (c) {
    var r = c.map(function (p) { return { x: Math.round(p.x), y: Math.round(p.y), on: p.on }; }), o = [];
    r.forEach(function (p) { var l = o[o.length - 1]; if (l && l.on && p.on && l.x === p.x && l.y === p.y) return; o.push(p); });
    while (o.length > 1 && o[0].on && o[o.length - 1].on && o[0].x === o[o.length - 1].x && o[0].y === o[o.length - 1].y) o.pop();
    /* نقطهٔ on هم‌خطِ میان دو خط حذف شود */
    var ch = true, guard = 0;
    while (ch && guard++ < 20 && o.length > 3) {
      ch = false;
      for (var i = 0; i < o.length && o.length > 3; i++) {
        var n = o.length, a = o[(i - 1 + n) % n], p = o[i], b = o[(i + 1) % n];
        if (a.on && p.on && b.on && (p.x - a.x) * (b.y - p.y) - (p.y - a.y) * (b.x - p.x) === 0 && (p.x - a.x) * (b.x - p.x) + (p.y - a.y) * (b.y - p.y) > 0) { o.splice(i, 1); ch = true; i--; }
      }
    }
    if (o.length >= 3 && Math.abs(FS.editor.signedArea(o)) >= 1) res.push(o);
  });
  return res;
}

/* راستی‌آزمایی: مقایسهٔ پر/خالی بودن نقاط نمونه در طرح اصلی و نتیجه */
function verifySame(origC, newC) {
  var sa = buildSegs(origC), A = buildPieces(sa), B = buildPieces(buildSegs(newC)), x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  sa.forEach(function (s) { var b = bb(s); if (b.x0 < x0) x0 = b.x0; if (b.y0 < y0) y0 = b.y0; if (b.x1 > x1) x1 = b.x1; if (b.y1 > y1) y1 = b.y1; });
  if (!(x1 > x0 && y1 > y0)) return true;
  var N = 56, bad = 0, used = 0, M = 1.5;
  function inn(P, x, y) { return windingAt(P, x, y) !== 0; }
  for (var i = 0; i < N; i++) for (var j = 0; j < N; j++) {
    var px = x0 + (x1 - x0) * (i + 0.37) / N, py = y0 + (y1 - y0) * (j + 0.61) / N, o = inn(A, px, py);
    /* نمونه‌های نزدیکِ مرز (در حد گردکردن مختصات) نادیده گرفته می‌شوند */
    if (inn(A, px + M, py) !== o || inn(A, px - M, py) !== o || inn(A, px, py + M) !== o || inn(A, px, py - M) !== o) continue;
    used++; if (inn(B, px, py) !== o) bad++;
  }
  return bad <= Math.max(1, Math.round(used * 0.002));
}

/* dry=true فقط بررسی می‌کند. خروجی: { status:'same'|'fixed'|'overlap'|'fail', before, after, reason } */
function removeOverlapGlyph(g, o) {
  o = o || {}; var cs = g.contours || [], r = { status: 'same', before: cs.length, after: cs.length };
  if (!cs.length) return r;
  var u;
  try { u = unionContours(cs); } catch (e) { return { status: 'fail', before: cs.length, after: cs.length, reason: String(e && e.message || e) }; }
  if (u.same) return r;
  if (u.fail) return { status: 'fail', before: cs.length, after: cs.length, reason: u.fail };
  var res = roundContours(u.contours);
  if (o.verify !== false && !verifySame(cs, res)) return { status: 'fail', before: cs.length, after: cs.length, reason: 'راستی‌آزمایی نخواند' };
  if (o.dry) return { status: 'overlap', before: cs.length, after: res.length };
  g.contours = res; return { status: 'fixed', before: cs.length, after: res.length };
}

/* =====================================================================
   بخش ۲ — ناحیه‌های هم‌ترازی و اُورشوت
   ===================================================================== */
function zoneCandidates(g) {
  var res = [];
  (g.contours || []).forEach(function (c, ci) {
    var n = c.length; if (n < 3) return;
    /* y مؤثرِ همسایه: اگر هم‌ارتفاع بود، به نقطهٔ بعدی نگاه می‌کنیم تا جهت منحنی/خط معلوم شود */
    function eff(i, dir, y) { var k = 0, j = i + dir, q = c[(j + n) % n]; while (q.y === y && k++ < 3) { j += dir; q = c[(j + n) % n]; } return q.y; }
    for (var i = 0; i < n; i++) {
      var p = c[i]; if (!p.on) continue;
      var a = c[(i - 1 + n) % n], b = c[(i + 1) % n];
      if (a.on && b.on && a.y === p.y && b.y === p.y) continue;
      var ea = eff(i, -1, p.y), eb = eff(i, 1, p.y), side = null;
      if (ea < p.y && eb < p.y) side = 'top'; else if (ea > p.y && eb > p.y) side = 'bottom';
      if (side) res.push({ ci: ci, i: i, y: p.y, side: side, round: (!a.on && a.y === p.y) || (!b.on && b.y === p.y) });
    }
  });
  return res;
}
function median(a) { if (!a.length) return 0; var s = a.slice().sort(function (x, y) { return x - y; }); return s[(s.length - 1) >> 1]; }
function modeOf(a) { var m = {}, best = a[0], bc = 0; a.forEach(function (v) { m[v] = (m[v] || 0) + 1; if (m[v] > bc) { bc = m[v]; best = v; } }); return best; }
function zoneTarget(z, round) { return round ? (z.side === 'top' ? z.y + z.over : z.y - z.over) : z.y; }
function zoneMatch(z, c, tol) {
  if (z.side !== c.side) return null;
  var lo = z.side === 'top' ? z.y - tol : z.y - z.over - tol, hi = z.side === 'top' ? z.y + z.over + tol : z.y + tol;
  if (c.y < lo || c.y > hi) return null;
  return zoneTarget(z, c.round);
}
function detectZones(f, idx, tol, minCount) {
  var all = { top: [], bottom: [] };
  idx.forEach(function (gi) { zoneCandidates(f.glyphs[gi]).forEach(function (c) { all[c.side].push(c); }); });
  var zones = [];
  ['top', 'bottom'].forEach(function (side) {
    var arr = all[side].slice(), guard = 0, need = Math.max(minCount, Math.round(all[side].length * 0.01));
    while (arr.length && guard++ < 8) {
      var ys = arr.map(function (c) { return c.y; }).sort(function (a, b) { return a - b; }), best = -1, bc = 0, lo = 0, hi = 0;
      for (var k = 0; k < ys.length; k++) { while (ys[k] - ys[lo] > tol) lo++; if (hi < k) hi = k; while (hi + 1 < ys.length && ys[hi + 1] - ys[k] <= tol) hi++; if (hi - lo + 1 > bc) { bc = hi - lo + 1; best = ys[k]; } }
      if (bc < need) break;
      var W = arr.filter(function (c) { return Math.abs(c.y - best) <= tol; }), flats = W.filter(function (c) { return !c.round; }).map(function (c) { return c.y; }), rounds = W.filter(function (c) { return c.round; }).map(function (c) { return c.y; });
      var zy = flats.length >= 2 ? modeOf(flats) : median(W.map(function (c) { return c.y; })), over = 0;
      if (rounds.length >= 2 && flats.length >= 2) { var d = side === 'top' ? median(rounds) - zy : zy - median(rounds); if (d > 0 && d <= tol * 1.5) over = Math.round(d); }
      var z = { y: zy, over: over, side: side, count: W.length, fix: 0 };
      W.forEach(function (c) { if (c.y !== zoneTarget(z, c.round)) z.fix++; });
      zones.push(z);
      arr = arr.filter(function (c) { return Math.abs(c.y - best) > 2 * tol; });
    }
  });
  zones.sort(function (a, b) { return a.y - b.y; });
  return zones;
}
/* اعمال روی یک گلیف؛ شمارندهٔ نقاط جابه‌جاشده را برمی‌گرداند */
function applyZonesGlyph(g, zones, tol) {
  var moved = 0, cs = zoneCandidates(g), plan = [], done = {};
  cs.forEach(function (c) {
    var bestT = null, bestD = Infinity;
    zones.forEach(function (z) { var t = zoneMatch(z, c, tol); if (t === null) return; var d = Math.abs(t - c.y); if (d < bestD) { bestD = d; bestT = t; } });
    if (bestT !== null && bestT !== c.y) plan.push({ c: c, dy: bestT - c.y });
  });
  plan.forEach(function (m) {
    var ct = g.contours[m.c.ci], n = ct.length, p = ct[m.c.i], oy = p.y, k;
    p.y = oy + m.dy; moved++;
    [(m.c.i - 1 + n) % n, (m.c.i + 1) % n].forEach(function (ni) { var q = ct[ni], key = m.c.ci + ':' + ni; if (!q.on && q.y === oy && !done[key]) { q.y += m.dy; done[key] = 1; } });
  });
  return moved;
}

root.StudioUltraPlus = { removeOverlapGlyph: removeOverlapGlyph, unionContours: unionContours, detectZones: detectZones, applyZonesGlyph: applyZonesGlyph, zoneCandidates: zoneCandidates, windingAt: windingAt, buildPieces: buildPieces, buildSegs: buildSegs };

/* =====================================================================
   رابط کاربری
   ===================================================================== */
var A = root.StudioApp; if (!A) return;
var T = A.T, S = A.S;
function esc(s) { return A.esc(String(s == null ? '' : s)); }
function num(v, d) { v = +v; return Number.isFinite(v) ? v : d; }
function rootCp(g) { var us = g.unicodes || []; if (us.length) return us[0]; var m = /^uni([0-9A-Fa-f]{4,6})(?:\.|$)/.exec(g.name || ''); return m ? parseInt(m[1], 16) : -1; }
function parseRanges(str) { var out = []; String(str || '').split(/[,\s]+/).forEach(function (t) { if (!t) return; var m = /^(?:U\+)?([0-9a-f]+)(?:-(?:U\+)?([0-9a-f]+))?$/i.exec(t); if (m) { var a = parseInt(m[1], 16), b = m[2] ? parseInt(m[2], 16) : a; out.push([a, Math.max(a, b)]); } }); return out; }
function scopeIdx(f, mode, rangeStr, cur) {
  if (mode === 'cur') return f.glyphs[cur] ? [cur] : [];
  var rs = mode === 'range' ? parseRanges(rangeStr) : null, res = [];
  f.glyphs.forEach(function (g, i) { if (!g.contours || !g.contours.length) return; if (rs) { var u = rootCp(g); if (!rs.some(function (r) { return u >= r[0] && u <= r[1]; })) return; } res.push(i); });
  return res;
}
function scopeHTML(p, def) {
  return '<div class="row"><label class="f">' + T('محدوده', 'Scope') + '<select id="' + p + 'Sc"><option value="cur"' + (def === 'cur' ? ' selected' : '') + '>' + T('گلیف فعلی', 'Current glyph') + '</option><option value="all"' + (def === 'all' ? ' selected' : '') + '>' + T('همهٔ گلیف‌های دارای طرح', 'All glyphs with outlines') + '</option><option value="range">' + T('بازه‌های Unicode', 'Unicode ranges') + '</option></select></label><label class="f grow">' + T('بازه (hex)', 'Ranges (hex)') + '<input id="' + p + 'Rg" dir="ltr" placeholder="0600-06FF, 0041-005A"></label></div>';
}
function chk(id, label, on) { return '<label class="chk"><input id="' + id + '" type="checkbox"' + (on ? ' checked' : '') + '> ' + label + '</label>'; }
function field(id, label, val, extra) { return '<label class="f">' + label + '<input id="' + id + '" type="number" value="' + val + '"' + (extra || '') + '></label>'; }
function card(title, desc, body, out) { return '<div class="card ul-card"><h3>' + title + '</h3><div class="muted">' + desc + '</div>' + body + '<div class="muted ul-out" id="' + out + '"></div></div>'; }
function touch(gi) {
  S.ttf = null; S.dirty = true; try { A.Host && A.Host.setUnsaved && A.Host.setUnsaved(true); } catch (e) { }
  try { if (S.ed) { S.ed.sel = {}; S.ed.draw(); } } catch (e) { }
  if (A.changed && S.font && S.font.glyphs.length) A.changed(Math.max(0, Math.min(gi | 0, S.font.glyphs.length - 1)), true);
}
function yieldUI() { return new Promise(function (r) { setTimeout(r, 0); }); }
async function runBatch(idx, fn, msg) {
  var f = S.font, items = [], info = [], t0 = Date.now(), shown = false;
  for (var k = 0; k < idx.length; k++) {
    var gi = idx[k], g = f.glyphs[gi], before = FS.editor.snap(g), r = fn(g, gi);
    if (r) info.push({ gi: gi, r: r });
    var after = FS.editor.snap(g); if (before.c !== after.c) items.push({ gi: gi, before: before, after: after });
    if (Date.now() - t0 > 400 && k % 8 === 7) { shown = true; await A.busy(msg + ' ' + (k + 1) + '/' + idx.length); t0 = Date.now(); }
  }
  if (shown) await A.busy('');
  if (items.length) { A.pushHistory(items); touch(items[0].gi); }
  return { changed: items.length, info: info };
}
function guard(fn) { return function () { var self = this, a = arguments; Promise.resolve().then(function () { return fn.apply(self, a); }).catch(function (e) { try { A.busy(''); } catch (_) { } A.fail(e); }); }; }
function nm(f, gi) { var g = f.glyphs[gi]; return (g && g.name) || ('#' + gi); }

function openPlus() {
  var f = S.font, upm = f.upm;
  var m = document.createElement('div'); m.className = 'fs-lab ul-lab';
  var html = '<div class="fs-lab-head"><div><h2>🚀 Font Studio Ultra Plus</h2><div class="muted">' + esc(A.fam()) + ' · UPM ' + upm + '</div></div><button class="b" id="upClose">✕</button></div><div id="upBody">';
  html += card('🧩 ' + T('حذف همپوشانی (Remove Overlap)', 'Remove Overlap'),
    T('کانتورهای روی‌هم‌افتاده را به یک طرح یکپارچه تبدیل می‌کند (اجتماع). منحنی‌ها منحنی می‌مانند و به چندضلعی تبدیل نمی‌شوند. اگر نتیجه با طرح اصلی نخواند، آن گلیف دست‌نخورده می‌ماند. با Undo برمی‌گردد.', 'Merges overlapping contours into one clean outline (union). Curves stay curves. If the result does not match the original, that glyph is left untouched. Undo restores it.'),
    scopeHTML('o', 'cur') + chk('oVer', T('راستی‌آزمایی نتیجه با نمونه‌برداری (پیشنهادی)', 'Verify result by sampling (recommended)'), true) +
    '<div class="row"><button class="b" id="oScan">' + T('فقط بررسی (کدام گلیف‌ها همپوشانی دارند)', 'Scan only (which glyphs overlap)') + '</button><button class="b p" id="oGo">' + T('حذف همپوشانی', 'Remove overlap') + '</button></div>', 'oOut');
  var xh = (f.os2 && f.os2.xHeight) || Math.round(upm * .5);
  html += card('📐 ' + T('ناحیه‌های هم‌ترازی و اُورشوت', 'Alignment zones & overshoot'),
    T('ارتفاع‌های پرتکرار (خط پایه، ارتفاع‌ها، زیرخط) را از خود فونت پیدا می‌کند و نقطه‌های حدیِ نزدیک به آن‌ها را روی همان ارتفاع می‌نشاند. نقطه‌ای که منحنیِ گرد است می‌تواند به‌اندازهٔ اُورشوت بیرون‌تر بنشیند. دستگیره‌های افقیِ هم‌ارتفاع همراه نقطه جابه‌جا می‌شوند.', 'Finds the recurring heights (baseline, x-height, ascender, descender) in your font and snaps nearby extreme points onto them. Round extremes may overshoot by a set amount. Horizontal handles move with their point.'),
    scopeHTML('z', 'all') + '<div class="row">' + field('zTol', T('تلورانس چسبیدن (واحد)', 'Snap tolerance (units)'), Math.max(2, Math.round(upm * .006)), ' min="1" step="1"') + field('zMin', T('حداقل تکرار برای تشخیص', 'Min. occurrences to detect'), 4, ' min="2" step="1"') + '</div>' +
    '<div class="row"><button class="b" id="zDet">' + T('تشخیص خودکار ناحیه‌ها', 'Auto-detect zones') + '</button><button class="b" id="zAdd">+ ' + T('ناحیهٔ دستی', 'Add zone') + '</button></div><div id="zRows"></div>' +
    '<div class="row"><button class="b p" id="zGo">' + T('اعمال هم‌ترازی', 'Apply alignment') + '</button></div>', 'zOut');
  html += '</div>'; m.innerHTML = html; document.body.appendChild(m);
  var q = function (id) { return m.querySelector('#' + id); }, say = function (id, txt) { q(id).textContent = txt; A.toast(txt.split('\n')[0]); };
  q('upClose').onclick = function () { m.remove(); };
  var sc = function (p) { return scopeIdx(S.font, q(p + 'Sc').value, q(p + 'Rg').value, S.gi); };

  q('oScan').onclick = guard(async function () {
    var idx = sc('o'), hit = [], fail = [];
    var res = await runBatch(idx, function (g) { var r = removeOverlapGlyph(g, { dry: true, verify: q('oVer').checked }); return r.status === 'same' ? null : r; }, T('بررسی…', 'Scanning…'));
    res.info.forEach(function (x) { (x.r.status === 'overlap' ? hit : fail).push(nm(S.font, x.gi)); });
    say('oOut', idx.length + ' ' + T('گلیف بررسی شد', 'glyphs scanned') + ' · ' + hit.length + ' ' + T('گلیف همپوشانی دارد', 'with overlaps') + (hit.length ? ': ' + hit.slice(0, 24).join('، ') + (hit.length > 24 ? ' …' : '') : '') + (fail.length ? '\n' + fail.length + ' ' + T('گلیف قابل پردازش نبود: ', 'not processable: ') + fail.slice(0, 10).join('، ') : ''));
  });
  q('oGo').onclick = guard(async function () {
    var idx = sc('o'); if (!idx.length) { say('oOut', T('گلیفی در محدوده نیست', 'No glyphs in scope')); return; }
    var res = await runBatch(idx, function (g) { return removeOverlapGlyph(g, { verify: q('oVer').checked }); }, T('حذف همپوشانی…', 'Removing overlap…'));
    var fixed = 0, fail = [];
    res.info.forEach(function (x) { if (x.r.status === 'fixed') fixed++; else if (x.r.status === 'fail') fail.push(nm(S.font, x.gi) + ' (' + x.r.reason + ')'); });
    say('oOut', fixed + ' ' + T('گلیف اصلاح شد ✔', 'glyphs fixed ✔') + ' · ' + (idx.length - fixed - fail.length) + ' ' + T('گلیف همپوشانی نداشت', 'had no overlap') + (fail.length ? '\n' + fail.length + ' ' + T('گلیف دست‌نخورده ماند: ', 'left untouched: ') + fail.slice(0, 8).join('، ') : ''));
  });

  /* ---- ناحیه‌ها ---- */
  function rowHTML(z) {
    return '<div class="row zr"><label class="chk"><input class="ze" type="checkbox" checked></label><select class="zs"><option value="top"' + (z.side === 'top' ? ' selected' : '') + '>' + T('بالا', 'Top') + '</option><option value="bottom"' + (z.side === 'bottom' ? ' selected' : '') + '>' + T('پایین', 'Bottom') + '</option></select>' +
      '<label class="f">y<input class="zy" type="number" dir="ltr" value="' + z.y + '" style="width:80px"></label><label class="f">' + T('اُورشوت', 'Overshoot') + '<input class="zo" type="number" dir="ltr" min="0" value="' + z.over + '" style="width:70px"></label><span class="muted zc">' + (z.count ? z.count + ' ' + T('نقطه', 'pts') + (z.fix ? ' · ' + z.fix + ' ' + T('نامرتب', 'off') : ' ✔') : '') + '</span><button class="b zx">✕</button></div>';
  }
  function bindRows() { m.querySelectorAll('.zx').forEach(function (b) { b.onclick = function () { b.closest('.zr').remove(); }; }); }
  function setRows(zs) { q('zRows').innerHTML = zs.map(rowHTML).join(''); bindRows(); }
  function readRows() {
    var zs = []; m.querySelectorAll('.zr').forEach(function (r) { if (!r.querySelector('.ze').checked) return; var y = num(r.querySelector('.zy').value, NaN); if (!Number.isFinite(y)) return; zs.push({ side: r.querySelector('.zs').value, y: Math.round(y), over: Math.max(0, Math.round(num(r.querySelector('.zo').value, 0))) }); });
    return zs;
  }
  q('zDet').onclick = guard(function () {
    var tol = Math.max(1, num(q('zTol').value, 10)), idx = sc('z'), zs = detectZones(S.font, idx, tol, Math.max(2, num(q('zMin').value, 4)));
    if (!zs.length) { setRows([]); say('zOut', T('ناحیهٔ پرتکراری پیدا نشد؛ تلورانس یا حداقل تکرار را کم کنید یا ناحیه را دستی بسازید.', 'No recurring zones found; lower tolerance/min or add zones manually.')); return; }
    setRows(zs); say('zOut', zs.length + ' ' + T('ناحیه پیدا شد؛ مقدارها را بازبینی کنید، سپس «اعمال» را بزنید.', 'zones found; review, then press Apply.'));
  });
  q('zAdd').onclick = function () { var d = document.createElement('div'); d.innerHTML = rowHTML({ side: 'top', y: Math.round(xh), over: 0, count: 0, fix: 0 }); q('zRows').appendChild(d.firstChild); bindRows(); };
  q('zGo').onclick = guard(async function () {
    var zs = readRows(), tol = Math.max(1, num(q('zTol').value, 10)), idx = sc('z');
    if (!zs.length) { say('zOut', T('ابتدا ناحیه‌ها را تشخیص بدهید یا دستی بسازید', 'Detect or add zones first')); return; }
    var pts = 0, res = await runBatch(idx, function (g) { var n = applyZonesGlyph(g, zs, tol); pts += n; if (n) { FS.editor.normalizeGlyph(g); } return n ? { n: n } : null; }, T('هم‌ترازی…', 'Aligning…'));
    say('zOut', pts + ' ' + T('نقطه در', 'points moved in') + ' ' + res.changed + ' ' + T('گلیف هم‌تراز شد ✔', 'glyphs ✔'));
  });
}

function panel(mm) {
  var d = document.createElement('details');
  d.innerHTML = '<summary>🚀 ' + T('Font Studio Ultra Plus — حذف همپوشانی و ناحیه‌های هم‌ترازی', 'Font Studio Ultra Plus — Remove Overlap & Alignment Zones') + '</summary><div class="muted">' + T('اجتماع واقعی کانتورها با حفظ منحنی، و هم‌ترازی خودکار خط پایه/ارتفاع‌ها با اُورشوت.', 'True contour union that keeps curves, and automatic baseline/height alignment with overshoot.') + '</div><button class="b p" id="upOpen">🚀 ' + T('باز کردن Ultra Plus', 'Open Ultra Plus') + '</button>';
  mm.appendChild(d); d.querySelector('#upOpen').onclick = openPlus;
}
var old = A.afterTools; A.afterTools = function (mm) { if (old) old(mm); panel(mm); };
root.StudioUltraPlus.open = openPlus;
})(window);
