package com.example.persianfontkeyboard

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.persianfontkeyboard.dictionary.KeyboardSuggest
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.FileProvider
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class MainActivity : AppCompatActivity(), com.example.persianfontkeyboard.physical.AppKeyboardHider {

    private lateinit var editText: EditText
    private lateinit var textScrollView: ScrollView
    private lateinit var customKeyboard: CustomKeyboardView
    private lateinit var scriptLabel: TextView
    private lateinit var lineNumbers: TextView
    private lateinit var fontTypeface: Typeface

    private var currentFontFile: String = ""
    /** شمارهٔ نسخهٔ فونتِ اعمال‌شده؛ با آپدیت فونت عوض می‌شود تا onResume دوباره اعمالش کند. */
    private var appliedFontStamp: Long = 0L

    private var currentTextSizeSp: Float = 24f
    /** حالت تمرکز: نوار ابزارها مخفی می‌شوند ولی حذف نمی‌گردند. */
    private var focusMode = false
    private var isDarkMode: Boolean = false
    private var lastFoundIndex: Int = -1

    /** تاریخچهٔ واگردانی/تکرار کادر متن صفحهٔ اصلی؛ برای همهٔ روش‌های ورودی و میانبرها مشترک است. */
    private lateinit var editHistory: EditHistory
    private var fontLoadGeneration = 0
    private var systemKeyboardShown = false

    /** کیبورد اپلیکیشن را خودِ «پشتیبانی از کیبورد فیزیکی» پنهان کرده است. */
    private var hiddenByPhysicalKeyboard = false

    override fun hideForPhysicalKeyboard() {
        runOnUiThread {
            val panel = findViewById<View>(R.id.keyboardPanel) ?: return@runOnUiThread
            if (panel.visibility != View.VISIBLE) return@runOnUiThread
            closeEmojiPanel()
            panel.visibility = View.GONE
            hiddenByPhysicalKeyboard = true
            findViewById<Button>(R.id.btnToggleAppKeyboard)?.text = AppLang.t("استفاده از کیبورد اپلیکیشن", "Use app keyboard")
            if (::editText.isInitialized) {
                editText.setShowSoftInputOnFocus(false)
                hideSystemKeyboard()
            }
        }
    }

    override fun restoreAfterPhysicalKeyboard() {
        runOnUiThread {
            if (!hiddenByPhysicalKeyboard) return@runOnUiThread
            hiddenByPhysicalKeyboard = false
            val panel = findViewById<View>(R.id.keyboardPanel) ?: return@runOnUiThread
            if (panel.visibility != View.VISIBLE && !systemKeyboardShown) {
                panel.visibility = View.VISIBLE
                findViewById<Button>(R.id.btnToggleAppKeyboard)?.text = AppLang.t("بستن کیبورد اپلیکیشن", "Close app keyboard")
            }
        }
    }

    // میانبرها: نوار زیر دکمه‌های بالا، نوار کنار کیبورد، و حالت آیکون/متن دکمه‌های بالا
    private lateinit var shortcutTopBar: ShortcutBar
    private lateinit var shortcutKeyboardBar: ShortcutBar
    private lateinit var topButtonsMode: TopButtonsMode

    // ورودی صوتی («بگویید تا بنویسم»)؛ باید هنگام ساخت صفحه ساخته شود تا درخواست اجازهٔ میکروفون ثبت شود
    private val speechInput = com.example.persianfontkeyboard.dictionary.SttDialog(this)

    private val appPrefs: SharedPreferences by lazy {
        getSharedPreferences("app_prefs", MODE_PRIVATE)
    }

    private val draftPrefs: SharedPreferences by lazy {
        getSharedPreferences("draft_prefs", MODE_PRIVATE)
    }

    private val draftSaveHandler = Handler(Looper.getMainLooper())

    private val draftSaveRunnable = Runnable {
        draftPrefs.edit()
            .putString("draft_text", editText.text.toString())
            .apply()
    }

    private val backgroundPickerLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri == null) return@registerForActivityResult

            if (KeyboardBackgroundManager.saveSelectedImage(this, uri)) {
                KeyboardBackgroundManager.showSettings(this) {
                    applyKeyboardBackground()
                    KeyboardBackgroundManager.applyWholeApp(this)
                    Toast.makeText(
                        this,
                        AppLang.t("تنظیمات پس‌زمینه اعمال شد؛ تصویر در خروجی‌ها استفاده نمی‌شود.", "Background settings applied; the image isn't used in exports."),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                Toast.makeText(
                    this,
                    AppLang.t("انتخاب تصویر ناموفق بود.", "Choosing the image failed."),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    private var lastImagePalette: List<Int> = emptyList()

    /** استخراج پالت از عکس — بدون ارجاع به خودش داخل initializer (رفع recursive type). */
    private val paletteFromImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri == null) return@registerForActivityResult
            val colors = ColorPaletteExtractor.extractFromUri(this, uri, 6)
            if (colors.isEmpty()) {
                Toast.makeText(this, AppLang.t("رنگی از عکس استخراج نشد", "No color could be extracted from the photo"), Toast.LENGTH_SHORT).show()
                return@registerForActivityResult
            }
            lastImagePalette = colors
            showTextColorPicker(extraColors = colors)
        }

    private fun showTextColorPicker(extraColors: List<Int> = lastImagePalette) {
        TextColorManager.showPicker(
            this,
            TextColorManager.getColor(this),
            onPickFromImage = { paletteFromImageLauncher.launch("image/*") },
            extraColors = extraColors,
            onColorSelected = { applyTextColor(it) }
        )
    }

    private val converterLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val text = result.data?.getStringExtra(ScriptConverterActivity.EXTRA_RESULT_TEXT)
                if (!text.isNullOrEmpty()) {
                    editText.requestFocus()
                    insertAtCursor(text)
                }
            }
        }

    private val qrLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val text = result.data?.getStringExtra(com.example.persianfontkeyboard.qr.QrTextActivity.EXTRA_RESULT_TEXT)
                if (!text.isNullOrEmpty()) {
                    editText.requestFocus()
                    insertAtCursor(text)
                }
            }
        }

    private val stylusLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val text = result.data?.getStringExtra(com.example.persianfontkeyboard.stylus.StylusSystemActivity.EXTRA_RESULT_TEXT)
                if (!text.isNullOrEmpty()) {
                    editText.requestFocus()
                    insertAtCursor(text)
                }
            }
        }

    /** متن انتخاب‌شده (وگرنه همهٔ متن) ویرایشگر را به «متن به QR Code و برعکس» می‌فرستد. */
    private fun openQr(text: String) {
        qrLauncher.launch(
            Intent(this, com.example.persianfontkeyboard.qr.QrTextActivity::class.java)
                .putExtra(com.example.persianfontkeyboard.qr.QrTextActivity.EXTRA_EDITOR_TEXT, text.take(3000))
                .putExtra(com.example.persianfontkeyboard.qr.QrTextActivity.EXTRA_FOR_RESULT, true)
        )
    }

    private val backupCreateLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            if (uri == null) return@registerForActivityResult
            Thread {
                try {
                    val count = contentResolver.openOutputStream(uri)?.use { out ->
                        BackupManager.writeBackup(this, out)
                    } ?: throw IllegalStateException(AppLang.t("فایل مقصد باز نشد", "The destination file couldn't be opened"))
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            AppLang.t("پشتیبان ساخته شد ($count متن + تنظیمات)", "Backup created ($count texts + settings)"),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this, AppLang.t("پشتیبان‌گیری ناموفق بود: ${e.message}", "Backup failed: ${e.message}"), Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }

    private val backupRestoreLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            Thread {
                try {
                    val result = contentResolver.openInputStream(uri)?.use { input ->
                        BackupManager.restoreBackup(this, input)
                    } ?: throw IllegalArgumentException(AppLang.t("فایل باز نشد", "The file couldn't be opened"))
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            AppLang.t("بازیابی انجام شد (${result.texts} متن، ${result.settings} تنظیم)", "Restore done (${result.texts} texts, ${result.settings} settings)"),
                            Toast.LENGTH_LONG
                        ).show()
                        recreate()
                    }
                } catch (e: IllegalArgumentException) {
                    runOnUiThread { Toast.makeText(this, e.message ?: AppLang.t("فایل پشتیبان معتبر نیست", "The backup file is not valid"), Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, AppLang.t("بازیابی ناموفق بود: ${e.message}", "Restore failed: ${e.message}"), Toast.LENGTH_LONG).show() }
                }
            }.start()
        }

    private val savedTextLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

            if (result.resultCode == RESULT_OK) {

                val path = result.data?.getStringExtra(
                    SavedFilesActivity.EXTRA_RESULT_FILE_PATH
                )

                if (path != null) {
                    try {
                        val content = File(path).readText()

                        editText.setText(content)
                        editText.setTextColor(TextColorManager.getColor(this))
                        editText.setSelection(editText.text.length)

                    } catch (e: Exception) {
                        Toast.makeText(
                            this,
                            AppLang.t("خطا در بازخوانی فایل متن", "Error reloading the text file"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {

        ThemeManager.apply(this)

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.textDisplay)
        // اگر زبان گوشی عوض شود و برنامه خودکار دوباره راه‌اندازی شود، متن کادر اصلی از دست نمی‌رود
        AppLang.beforeAutoRestart = { act -> if (act === this) saveDraftNow() }
        textScrollView = findViewById(R.id.textScrollView)
        textScrollView.viewTreeObserver.addOnScrollChangedListener {
            if (::lineNumbers.isInitialized) {
                val settings = TextSettings.load(this)
                if (settings.lineNumbering || settings.lineLettering) {
                    lineNumbers.translationY = -textScrollView.scrollY.toFloat()
                }
            }
        }
        customKeyboard = findViewById(R.id.customKeyboard)
        MainMenuApply.bindKeyboard(customKeyboard, MenuTarget.TEXT_FRAME)
        scriptLabel = findViewById(R.id.scriptLabel)
        lineNumbers = findViewById(R.id.lineNumbers)
        shortcutTopBar = findViewById(R.id.shortcutBarTop)
        shortcutKeyboardBar = findViewById(R.id.shortcutBarKeyboard)
        // با عوض شدن چیدمان (شکسته‌شدن سطرها، چرخش صفحه، اندازهٔ فونت) شماره‌ها دوباره هم‌ردیف می‌شوند
        editText.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateLineNumbers() }

        applyKeyboardBackground()
        KeyboardBackgroundManager.applyWholeApp(this)

        findViewById<TextView>(R.id.versionText).text =
            AppLang.t("نسخه: ${AppInfo.fullVersion}", "Version: ${AppInfo.fullVersion}")

        // پیش‌فرض: فقط کیبورد اپلیکیشن. کیبورد گوشی فقط با دکمهٔ «استفاده از کیبورد گوشی» باز می‌شود
        // (حتی اگر دسترسی به آن از منو فعال باشد، ورود به برنامه و لمس کادر آن را باز نمی‌کند).
        editText.setTextIsSelectable(true)
        editText.isFocusable = true
        editText.isFocusableInTouchMode = true
        editText.setShowSoftInputOnFocus(false)
        editText.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) enforceAppKeyboardOnly()
        }
        editText.setOnClickListener { enforceAppKeyboardOnly() }
        editText.requestFocus()
        enforceAppKeyboardOnly()

        val restoredText =
            savedInstanceState?.getString("editor_text")
                ?: draftPrefs.getString("draft_text", "")
                ?: ""

        editText.setText(restoredText)
        applyTextSettings(TextSettings.load(this))

        val restoredSelection =
            savedInstanceState?.getInt(
                "selection_start",
                restoredText.length
            ) ?: restoredText.length

        editText.setSelection(
            restoredSelection.coerceIn(
                0,
                editText.text.length
            )
        )

        // با چرخش صفحه، جای اسکرول متن (به‌صورت نسبت) هم‌گام می‌ماند
        savedInstanceState?.getFloat("scroll_ratio", -1f)?.takeIf { it >= 0f }?.let { ratio ->
            textScrollView.postDelayed({
                val content = textScrollView.getChildAt(0)
                if (content != null) {
                    val range = (content.height - textScrollView.height).coerceAtLeast(0)
                    textScrollView.scrollTo(0, (ratio * range).toInt())
                }
            }, 150L)
        }

        currentTextSizeSp =
            savedInstanceState
                ?.getInt("font_size_sp", 24)
                ?.coerceAtLeast(10)
                ?.toFloat()
                ?: TextSizeManager.get(this)

        editText.textSize = currentTextSizeSp

        applyTextColor(TextColorManager.getColor(this))

        // تاریخچه باید پیش از ناظر پایین ساخته شود تا هر تغییر متن به ترتیب درست ثبت شود
        editHistory = EditHistory(editText)

        editText.addTextChangedListener(
            object : TextWatcher {

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun afterTextChanged(s: Editable?) {

                    updateLineNumbers()
                    TextSettingsApplier.apply(editText, TextSettings.load(this@MainActivity))

                    draftSaveHandler.removeCallbacks(
                        draftSaveRunnable
                    )

                    draftSaveHandler.postDelayed(
                        draftSaveRunnable,
                        400
                    )
                }

                override fun onTextChanged(
                    s: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {
                }
            }
        )

        // «اعمال قوانین خط پهلوی کتابی» (تنظیم صفحهٔ تبدیل متن): هر فاصله‌ای که پس از ח ה ׳ وارد شود،
        // از هر راهی (کیبورد اپ، کیبورد گوشی یا چسباندن متن)، ה را پیش از خودش می‌گیرد.
        // فقط بخش تازه‌وارد‌شدهٔ متن بررسی می‌شود، پس خودِ ה افزوده‌شده دوباره قاعده را راه نمی‌اندازد.
        editText.addTextChangedListener(
            object : TextWatcher {
                private var pending: List<Int> = emptyList()
                private var applying = false

                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    pending = emptyList()
                    // هر ویرایش دیگری، نشانهٔ «ה افزوده‌شدهٔ خودکار» را بی‌اعتبار می‌کند
                    if (!applying) ruleMark = -1
                    // مثل «تبدیل متن»، قاعده فقط هنگام تایپ فاصله اعمال می‌شود. متنی که یکجا درج یا چسبانده می‌شود
                    // (مثلاً نتیجهٔ همان تبدیل متن) پیش‌تر قاعده را گرفته است و دوباره ה نمی‌گیرد.
                    if (applying || s == null || count != 1 || before != 0) return
                    if (!BookPahlavi.rulesEnabled(this@MainActivity)) return
                    if (start in 1 until s.length && s[start] == ' ' && BookPahlavi.needsFinalLetter(s[start - 1])) {
                        pending = listOf(start)
                    }
                }

                override fun afterTextChanged(e: Editable?) {
                    if (e == null || pending.isEmpty() || applying) return
                    val positions = pending
                    pending = emptyList()
                    applying = true
                    try {
                        // از آخر به اول، تا جای فاصله‌های پیشین با افزودن ה جابه‌جا نشود
                        for (i in positions.asReversed()) {
                            if (i in 1 until e.length && e[i] == ' ') {
                                val letter = BookPahlavi.finalLetter(this@MainActivity)
                                // افزودن خودکار با فاصله یک مرحلهٔ واگردانی حساب شود
                                editHistory.mergeNextChange()
                                e.insert(i, letter)
                                // جای ה افزوده‌شده را نگه می‌داریم تا بک‌اسپیس بلافاصله بتواند آن را برگرداند
                                ruleMark = i
                                ruleLetter = letter
                            }
                        }
                    } finally {
                        applying = false
                    }
                }
            }
        )

        isDarkMode = ThemeManager.isDark(this)

        // پیشنهاد واژه (با معنی) از فرهنگ‌ها هنگام تایپ با کیبورد اپ
        KeyboardSuggest.attach(this, customKeyboard) { editText }

        customKeyboard.listener =
            object : CustomKeyboardView.KeyboardListener {

                override fun onCharacter(text: String) {
                    insertAtCursor(text)
                }

                override fun onBackspace() {
                    deleteBeforeCursor()
                }

                override fun onEnter() {
                    insertAtCursor("\n")
                }

                override fun onScriptChanged(
                    scriptName: String,
                    scriptIndex: Int,
                    totalScripts: Int
                ) {

                    val scriptNote = customKeyboard.currentScriptNote()

                    scriptLabel.text =
                        AppLang.t("خط: $scriptName  (${scriptIndex + 1}/$totalScripts)", "Script: ${ScriptNames.block(scriptName)}  (${scriptIndex + 1}/$totalScripts)") +
                                if (scriptNote.isNotEmpty()) "\n$scriptNote" else ""

                    appPrefs.edit()
                        .putString(
                            "last_script_name",
                            scriptName
                        )
                        .apply()

                    applyEditorDirection(
                        UnicodeScripts.isRtl(
                            customKeyboard.currentScript()
                        )
                    )
                }
            }

        customKeyboard.setCharacterTextColor(TextColorManager.getColor(this))

        val selectedFont = FontManager.getSelectedFontFile(this)

        if (selectedFont != null) {
            applyFont(selectedFont)
        } else {
            Toast.makeText(
                this,
                AppLang.t("هیچ فونتی در پوشه fonts پیدا نشد", "No font was found in the fonts folder"),
                Toast.LENGTH_LONG
            ).show()
        }

        val seekBar =
            findViewById<SeekBar>(R.id.fontSizeSeekBar)

        seekBar.progress = currentTextSizeSp.toInt()

        seekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    sb: SeekBar,
                    progress: Int,
                    fromUser: Boolean
                ) {

                    val size =
                        progress.coerceAtLeast(10).toFloat()

                    currentTextSizeSp = size

                    editText.textSize = size

                    TextSizeManager.set(this@MainActivity, size)
                }

                override fun onStartTrackingTouch(
                    sb: SeekBar
                ) {
                }

                override fun onStopTrackingTouch(
                    sb: SeekBar
                ) {
                }
            }
        )

        findViewById<ImageButton>(
            R.id.btnSearch
        ).setOnClickListener {
            showSearchDialog()
        }

        findViewById<Button>(
            R.id.btnClear
        ).setOnClickListener {
            confirmClearText()
        }

        findViewById<Button>(
            R.id.btnExportPdf
        ).setOnClickListener {
            exportPdf()
        }

        findViewById<Button>(R.id.btnExportDocx).setOnClickListener {
            exportDocx()
        }

        // موتور تبدیل صدا به متن: نتیجه در محل مکان‌نما نوشته می‌شود
        findViewById<Button>(R.id.btnListen).setOnClickListener {
            SpeechQuick.listen(this, speechInput) { insertAtCursor(it) }
        }

        // نوشتن با دست‌خط: متنِ تشخیص‌داده‌شده یا واژهٔ پیشنهادی (تطبیق دست‌خط با فرهنگ‌ها) در محل مکان‌نما درج می‌شود
        findViewById<Button>(R.id.btnHandwriting).setOnClickListener {
            com.example.persianfontkeyboard.handwriting.HandwritingPad.show(
                this,
                com.example.persianfontkeyboard.handwriting.HandwritingPad.Target(
                    insert = { insertAtCursor(it) },
                    source = com.example.persianfontkeyboard.handwriting.HandwritingQuick.SRC_EDITOR,
                    currentText = {
                        val a = editText.selectionStart.coerceAtLeast(0)
                        val b = editText.selectionEnd.coerceAtLeast(0)
                        if (a != b) editText.text.substring(minOf(a, b), maxOf(a, b)) else ""
                    }
                )
            )
        }

        // موتور گفتار: متن انتخاب‌شده (وگرنه همهٔ متن) خوانده می‌شود
        findViewById<Button>(R.id.btnSpeak).setOnClickListener {
            SpeechQuick.speak(this, SpeechQuick.textOf(editText))
        }

        // خروجی QR Code از متن ویرایشگر
        findViewById<Button>(R.id.btnExportQr).setOnClickListener {
            val t = SpeechQuick.textOf(editText)
            if (t.isBlank()) {
                Toast.makeText(this, AppLang.t("ابتدا در ویرایشگر اصلی متنی بنویسید", "First write some text in the main editor"), Toast.LENGTH_SHORT).show()
            } else {
                openQr(t)
            }
        }

        findViewById<Button>(
            R.id.btnExportImage
        ).setOnClickListener {
            exportImage()
        }

        findViewById<Button>(
            R.id.btnTextColor
        ).setOnClickListener {
            showTextAndColorDialog()
        }

        // دکمهٔ بالای کیبورد: اگر کیبورد اپلیکیشن باز است می‌بندد، اگر بسته است باز می‌کند
        findViewById<Button>(R.id.btnToggleAppKeyboard).setOnClickListener {
            closeEmojiPanel()
            val panel = findViewById<View>(R.id.keyboardPanel)
            val toggleButton = findViewById<Button>(R.id.btnToggleAppKeyboard)
            if (panel.visibility == View.VISIBLE) {
                panel.visibility = View.GONE
                toggleButton.text = AppLang.t("استفاده از کیبورد اپلیکیشن", "Use app keyboard")
                // با بسته‌شدن کیبورد اپلیکیشن، کیبورد گوشی خودبه‌خود باز نمی‌شود
                editText.setShowSoftInputOnFocus(false)
                hideSystemKeyboard()
            } else {
                panel.visibility = View.VISIBLE
                toggleButton.text = AppLang.t("بستن کیبورد اپلیکیشن", "Close app keyboard")
                findViewById<Button>(R.id.btnSystemKeyboard).text = AppLang.t("استفاده از کیبورد گوشی", "Use phone keyboard")
                systemKeyboardShown = false
                editText.setShowSoftInputOnFocus(false)
                hideSystemKeyboard()
                ensureEditorFocused()
            }
        }

        // با چرخش صفحه، اگر کاربر کیبورد اپلیکیشن را بسته بود، دوباره خودبه‌خود باز نشود
        if (savedInstanceState?.getBoolean("app_keyboard_visible", true) == false) {
            findViewById<View>(R.id.keyboardPanel).visibility = View.GONE
            findViewById<Button>(R.id.btnToggleAppKeyboard).text = AppLang.t("استفاده از کیبورد اپلیکیشن", "Use app keyboard")
        }

        // ایموجی در کادر اصلی: با فونت ایموجی نمایش داده می‌شود، نه فونت دبیره
        EmojiText.attachLive(editText)
        findViewById<Button>(R.id.btnEmojiKeyboard)?.setOnClickListener { toggleEmojiPanel() }
        findViewById<Button>(R.id.btnSystemKeyboard).setOnClickListener {
            closeEmojiPanel()
            val enabled = appPrefs.getBoolean("system_keyboard_enabled", false)
            if (!enabled) {
                Toast.makeText(this, AppLang.t("دسترسی به کیبورد گوشی از منوی اصلی غیرفعال شده است", "Access to the phone keyboard is disabled in the main menu"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (systemKeyboardShown) {
                // فقط کیبورد گوشی را ببند؛ بستن آن نباید کیبورد اپلیکیشن را باز کند.
                hideSystemKeyboard()
                systemKeyboardShown = false
                findViewById<Button>(R.id.btnSystemKeyboard).text = AppLang.t("استفاده از کیبورد گوشی", "Use phone keyboard")
                editText.setShowSoftInputOnFocus(false)
                ensureEditorFocused()
                return@setOnClickListener
            }

            findViewById<View>(R.id.keyboardPanel).visibility = View.GONE
            findViewById<Button>(R.id.btnToggleAppKeyboard).text = AppLang.t("استفاده از کیبورد اپلیکیشن", "Use app keyboard")
            editText.setShowSoftInputOnFocus(true)
            editText.requestFocus()
            systemKeyboardShown = true
            findViewById<Button>(R.id.btnSystemKeyboard).text = AppLang.t("بستن کیبورد گوشی", "Close phone keyboard")
            editText.post {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
            }
        }

        setupDrawerMenu()
        // با کیبورد فیزیکی (بلوتوثی، بی‌سیم، USB OTG) کیبورد اپلیکیشن خودکار کنار می‌رود
        com.example.persianfontkeyboard.physical.PhysicalInputHook.registerHider(this)
        setupTopButtonsMode()
        refreshShortcutBars()

        val lastInstalledVersion = appPrefs.getString("last_installed_version", "") ?: ""
        val justUpdated = lastInstalledVersion.isNotEmpty() &&
                lastInstalledVersion != AppInfo.fullVersion

        if (justUpdated) {
            draftSaveHandler.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    ChangelogHelper.show(this)
                    appPrefs.edit()
                        .putString("last_seen_changelog", getCurrentChangelogTag())
                        .apply()
                    updateChangelogBadge()
                }
            }, 1500L)
        }

        appPrefs.edit()
            .putString("last_installed_version", AppInfo.fullVersion)
            .apply()

        // بازمانده‌های بروزرسانی خودکارِ نسخه‌های قبل (کار پس‌زمینه و APK) پاک شوند
        if (savedInstanceState == null) UpdateChecker.cleanupLegacy(this)

        // پیام خوش‌آمدگویی: فقط هنگام باز شدن تازهٔ برنامه (نه با چرخش صفحه)
        if (savedInstanceState == null) {
            findViewById<View>(android.R.id.content).post { WelcomeOverlay.showIfNeeded(this) }
        }
    }

    /** کادر «متن و رنگ»؛ هم از دکمهٔ «تنظیمات متن» و هم از آیتم «تنظیمات متن» منوی اصلی باز می‌شود. */
    private fun showTextAndColorDialog() {
        val items = arrayOf(AppLang.t("تنظیمات متن", "Text settings"), AppLang.t("رنگ متن", "Text color"), AppLang.t("پالت از روی عکس", "Palette from photo"), AppLang.t("تنظیمات میانبرها", "Shortcut settings"))
        AlertDialog.Builder(this)
            .setTitle(AppLang.t("متن و رنگ", "Text & color"))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> TextSettingsApplier.showDialog(this) { settings ->
                        applyTextSettings(settings)
                        applyTextColor(if (settings.textColor != 0) settings.textColor else TextColorManager.getColor(this))
                    }
                    1 -> showTextColorPicker()
                    2 -> paletteFromImageLauncher.launch("image/*")
                    3 -> ShortcutSettingsDialog.show(this) { onShortcutSettingsChanged() }
                }
            }.show()
    }

    override fun onResume() {
        super.onResume()
        // فونت ممکن است از صفحهٔ «دانلود و به‌روزرسانی فونت» (یا اعلان) عوض یا آپدیت شده باشد
        try {
            val sel = FontManager.getSelectedFontFile(this)
            if (sel != null && currentFontFile.isNotEmpty() &&
                (sel != currentFontFile || FontManager.fontStamp(this, sel) != appliedFontStamp)
            ) {
                applyFont(sel)
            }
        } catch (_: Exception) {
        }
        // اگر تنظیمات میانبرها یا آیتم‌های منو عوض شده باشد، نوارها به‌روز می‌شوند
        if (::shortcutTopBar.isInitialized) refreshShortcutBars()
        // همگام با کیبورد دیالوگ زیرنویس: اگر آنجا خط عوض شده باشد، اینجا هم همان انتخاب می‌شود
        try {
            val saved = appPrefs.getString("last_script_name", null)
            if (saved != null && customKeyboard.currentScript()?.name != saved) {
                customKeyboard.selectScriptByName(saved)
            }
            findViewById<NavigationView>(R.id.navigationView)?.menu?.findItem(R.id.nav_glide_typing)?.isChecked =
                GlideSettings.enabled(this)
        } catch (_: Exception) {
        }
    }

    /** دکمهٔ «پاک کردن» و میانبر «پاک کردن»: پیش از پاک‌شدن متن تأیید می‌گیرد. */
    private fun confirmClearText() {
        if (editText.text.isEmpty()) {
            return
        }

        AlertDialog.Builder(this)
            .setTitle(AppLang.t("پاک کردن متن", "Clear text"))
            .setMessage(AppLang.t("متن فعلی پاک شود؟", "Clear the current text?"))
            .setPositiveButton(AppLang.t("پاک کردن", "Clear")) { _, _ ->

                editText.setText("")

                draftPrefs.edit()
                    .remove("draft_text")
                    .apply()
            }
            .setNegativeButton(
                AppLang.t("انصراف", "Cancel"),
                null
            )
            .show()
    }

    /**
     * دکمه‌های بالا (پاک کردن، تنظیمات متن، PDF، عکس): سبک نمایش (آیکون / متن / هر دو) از «تنظیمات میانبرها»؛
     * با ۵ ثانیه نگه‌داشتن هر کدام، همه بین آیکون و متن عوض می‌شوند.
     */
    private fun setupTopButtonsMode() {
        topButtonsMode = TopButtonsMode(this).apply {
            register(findViewById(R.id.btnClear), R.drawable.ic_sc_clear, AppLang.t("پاک کردن", "Clear"))
            register(findViewById(R.id.btnTextColor), R.drawable.ic_btn_text_settings, AppLang.t("تنظیمات متن", "Text settings"))
            register(findViewById(R.id.btnExportPdf), R.drawable.ic_btn_pdf, AppLang.t("ذخیره PDF", "Save PDF"))
            register(findViewById(R.id.btnExportDocx), R.drawable.ic_btn_docx, AppLang.t("ذخیره DOCX (Word)", "Save DOCX (Word)"))
            register(findViewById(R.id.btnExportImage), R.drawable.ic_btn_image, AppLang.t("ذخیره عکس", "Save image"))
            register(findViewById(R.id.btnExportQr), R.drawable.ic_btn_qr, AppLang.t("خروجی QR Code", "QR code"))
            // موتور تبدیل صدا به متن و موتور گفتار (کنار چهار دکمهٔ پیش‌فرض)
            findViewById<Button>(R.id.btnListen).text = AppLang.t("بگویید", "Listen")
            findViewById<Button>(R.id.btnSpeak).text = AppLang.t("بخوان", "Speak")
            register(findViewById(R.id.btnListen), R.drawable.ic_btn_mic, AppLang.t("موتور تبدیل صدا به متن", "Speech to text"))
            findViewById<Button>(R.id.btnHandwriting).text = AppLang.t("دست‌خط", "Handwriting")
            register(findViewById(R.id.btnHandwriting), R.drawable.ic_btn_handwriting, AppLang.t("نوشتن با دست‌خط", "Write by handwriting"))
            register(findViewById(R.id.btnSpeak), R.drawable.ic_btn_speak, AppLang.t("موتور گفتار (خواندن متن)", "Speech engine (read the text)"))
            register(findViewById(R.id.btnApplyMenuLook), R.drawable.ic_btn_menu_look, AppLang.t("ظاهر منو", "Menu look"))
        }
        topButtonsMode.applyAll()

        // «اعمال ظاهر منو روی متن» (کادر اصلی): کلیک = اعمال / توقف، نگه‌داشتن = پخش دوبارهٔ افکت.
        // تعداد دفعات اعمال از «تنظیمات منو اصلی» می‌آید (پیش‌فرض ۱ بار؛ «همیشه» تا توقف).
        MainMenuApply.bindApplyView(
            findViewById<View>(R.id.btnApplyMenuLook), MenuTarget.TEXT_FRAME, hideWhenOff = false
        ) { v, forced ->
            // رنگ دکمه نشان می‌دهد اعمال روشن است یا نه
            v.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (forced) 0xFFEF6C00.toInt() else 0xFF00695C.toInt()
            )
        }

        // اگر کاربر در «تنظیمات منو اصلی» نوار میانبرها را تیک زده باشد، ظاهر منو روی متن این دکمه‌ها هم می‌آید
        // (رنگ متن دست‌نخورده می‌ماند چون روی پس‌زمینهٔ رنگی دکمه نشسته است)
        val ids = intArrayOf(
            R.id.btnClear, R.id.btnTextColor, R.id.btnExportPdf, R.id.btnExportDocx, R.id.btnExportImage, R.id.btnApplyMenuLook,
            R.id.btnListen, R.id.btnSpeak, R.id.btnExportQr, R.id.btnHandwriting
        )
        for (id in ids) findViewById<View>(id).tag = MainMenuApply.KEEP_COLOR
        (findViewById<View>(R.id.topBarRow) as? android.view.ViewGroup)?.let {
            MainMenuApply.attachView(it, MenuTarget.SHORTCUT_BAR)
        }
    }

    private fun onShortcutSettingsChanged() {
        refreshShortcutBars()
        topButtonsMode.applyAll()
    }

    /** نوارهای میانبر را طبق تنظیمات (فعال/غیرفعال، محل نمایش، چیدمان) و منوی فعلی دوباره می‌سازد. */
    private fun refreshShortcutBars() {
        val cfg = ShortcutsManager.load(this)
        val items = if (cfg.enabled) ShortcutsManager.resolve(this, cfg, includeMenu = true) else emptyList()
        val canShow = cfg.enabled && items.isNotEmpty() && !focusMode
        // آیکون «ظاهر منو» بین دکمه‌های بالا؛ از «تنظیمات میانبرها» قابل خاموش‌کردن است
        findViewById<View>(R.id.btnApplyMenuLook)?.visibility =
            if (cfg.showApplyLookTop && !focusMode) View.VISIBLE else View.GONE
        bindShortcutBar(shortcutTopBar, canShow && cfg.showTop, items, cfg)
        bindShortcutBar(shortcutKeyboardBar, canShow && cfg.showKeyboard, items, cfg)
    }

    private fun bindShortcutBar(
        bar: ShortcutBar,
        show: Boolean,
        items: List<ShortcutsManager.Shortcut>,
        cfg: ShortcutsManager.Config
    ) {
        if (!show) {
            bar.visibility = View.GONE
            return
        }
        bar.bind(items, cfg, 2) { runShortcut(it.key) }
        bar.visibility = View.VISIBLE
    }

    /** اجرای یک میانبر: یا عمل ویرایشی کیبورد، یا یکی از آیتم‌های منوی اصلی. */
    private fun runShortcut(key: String) {
        if (key.startsWith(ShortcutsManager.MENU_PREFIX)) {
            val navigationView = findViewById<NavigationView>(R.id.navigationView)
            val item = ShortcutsManager.findMenuItem(this, navigationView.menu, key)
            if (item == null) {
                Toast.makeText(this, AppLang.t("این گزینه دیگر در منوی اصلی نیست", "This option is no longer in the main menu"), Toast.LENGTH_SHORT).show()
                refreshShortcutBars()
            } else {
                handleNavItem(item)
            }
            return
        }

        if (key.startsWith(ShortcutsManager.VIEW_PREFIX)) {
            val id = resources.getIdentifier(key.removePrefix(ShortcutsManager.VIEW_PREFIX), "id", packageName)
            val v = if (id != 0) findViewById<View>(id) else null
            if (v == null) {
                Toast.makeText(this, AppLang.t("این دکمه دیگر در صفحهٔ اصلی نیست", "This button is no longer on the main screen"), Toast.LENGTH_SHORT).show()
                refreshShortcutBars()
            } else {
                v.performClick()
            }
            return
        }

        when (key.removePrefix(ShortcutsManager.ACT_PREFIX)) {
            "backspace" -> deleteBeforeCursor()
            "enter" -> insertAtCursor("\n")
            "space" -> insertAtCursor(" ")
            "script_next" -> customKeyboard.nextScript()
            "script_prev" -> customKeyboard.prevScript()
            "undo" -> undoEdit()
            "redo" -> redoEdit()
            "copy" -> {
                ensureEditorFocused()
                EditActions.copy(this, editText)
            }
            "cut" -> {
                ensureEditorFocused()
                EditActions.cut(this, editText)
            }
            "paste" -> {
                val text = EditActions.clipboardText(this)
                if (text == null) {
                    Toast.makeText(this, AppLang.t("چیزی برای چسباندن در کلیپ‌بورد نیست", "There is nothing to paste on the clipboard"), Toast.LENGTH_SHORT).show()
                } else {
                    ClipboardHistory.record(this, text)
                    insertAtCursor(text)
                }
            }
            "clipboard" -> {
                ensureEditorFocused()
                ClipboardHistory.showDialog(this) { insertAtCursor(it) }
            }
            "clear" -> confirmClearText()
            "apply_menu_look" -> MainMenuApply.pressApply(this, MenuTarget.TEXT_FRAME)
            "export_pdf" -> exportPdf()
            "export_docx" -> exportDocx()
            "export_image" -> exportImage()
            "toggle_app_keyboard" -> findViewById<View>(R.id.btnToggleAppKeyboard).performClick()
            "toggle_system_keyboard" -> findViewById<View>(R.id.btnSystemKeyboard).performClick()
            "toggle_book_rules" -> {
                val on = !BookPahlavi.rulesEnabled(this)
                BookPahlavi.setRulesEnabled(this, on)
                Toast.makeText(this, AppLang.t("اعمال قوانین خط پهلوی کتابی: ", "Apply Book Pahlavi rules: ") + if (on) AppLang.t("روشن", "On") else AppLang.t("خاموش", "Off"), Toast.LENGTH_SHORT).show()
            }
            "toggle_book_alt" -> {
                val on = !BookPahlavi.alternatesEnabled(this)
                BookPahlavi.setAlternatesEnabled(this, on)
                Toast.makeText(this, AppLang.t("استفاده از حروف جایگزین: ", "Use alternative letters: ") + if (on) AppLang.t("روشن", "On") else AppLang.t("خاموش", "Off"), Toast.LENGTH_SHORT).show()
            }
            "select_all" -> {
                ensureEditorFocused()
                editText.setSelection(0, editText.length())
            }
            "cursor_start" -> {
                ensureEditorFocused()
                editText.setSelection(0)
            }
            "cursor_end" -> {
                ensureEditorFocused()
                editText.setSelection(editText.length())
            }
            "text_align" -> TextAlignChooser.show(this, TextSettings.load(this).alignment) { i ->
                // همان تنظیمِ «تراز» در تنظیمات متن؛ ذخیره می‌شود و بلافاصله روی متن اعمال می‌شود
                TextSettings.saveAlignment(this, i)
                applyTextSettings(TextSettings.load(this))
            }
            else -> {
                // میانبرهای درج نویسه: . , ' / () : {} [] | - +
                val id = key.removePrefix(ShortcutsManager.ACT_PREFIX)
                ShortcutsManager.insertTextFor(this, id)?.let { text ->
                    ensureEditorFocused()
                    EditActions.insertShortcutText(editText, text)
                }
            }
        }
    }

    private fun toggleFocusMode() {
        focusMode = !focusMode
        val visibility = if (focusMode) View.GONE else View.VISIBLE
        // ابزارها فقط مخفی می‌شوند؛ از layout حذف نمی‌گردند
        listOf(
            R.id.fontSizeSeekBar,
            R.id.btnExportImage,
            R.id.btnExportPdf,
            R.id.btnExportDocx,
            R.id.btnExportQr,
            R.id.btnTextColor,
            R.id.btnListen,
            R.id.btnSpeak,
            R.id.btnClear,
            R.id.btnSearch,
            R.id.btnToggleAppKeyboard,
            R.id.btnSystemKeyboard,
            R.id.keyboardPanel,
            R.id.scriptLabel,
            R.id.lineNumbers
        ).forEach { id ->
            runCatching { findViewById<View>(id)?.visibility = visibility }
        }
        // والد اسلایدر سایز اگر LinearLayout افقی ابزار باشد
        runCatching { findViewById<View>(R.id.fontSizeSeekBar)?.parent?.let { (it as? View)?.visibility = visibility } }
        // نوارهای میانبر در حالت تمرکز مخفی می‌شوند و با خاموش‌شدنش (اگر فعال باشند) برمی‌گردند
        refreshShortcutBars()
        Toast.makeText(
            this,
            if (focusMode) AppLang.t("حالت تمرکز روشن — برای بازگشت دوباره از منوی ظاهر استفاده کنید", "Focus mode on — use the Look menu to go back")
            else AppLang.t("حالت تمرکز خاموش", "Focus mode off"),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun applyTextSettings(settings: TextSettings) {
        TextSettingsApplier.apply(editText, settings)
        // سایز فونت مشترک با تنظیمات متن و اسلایدر صفحهٔ اصلی
        val size = settings.textSizeSp.coerceAtLeast(TextSizeManager.MIN_SP)
        currentTextSizeSp = size
        editText.textSize = size
        TextSizeManager.set(this, size)
        runCatching {
            findViewById<SeekBar>(R.id.fontSizeSeekBar)?.let { sb ->
                sb.progress = size.toInt().coerceIn(0, sb.max)
            }
        }
        editText.gravity = Gravity.TOP or when (settings.alignment) { 1 -> Gravity.CENTER_HORIZONTAL; 2 -> Gravity.START; 3 -> Gravity.FILL_HORIZONTAL; else -> Gravity.END }
        updateLineNumbers()
    }

    private var lastLineNumbersText = ""

    /**
     * شماره‌ها کنار اولین سطرِ هر بند می‌آیند؛ اگر یک بند چند سطر شد، سطرهای بعدی بدون شماره می‌مانند
     * تا شماره‌ها با متن هم‌ردیف بمانند. اندازهٔ خط شماره‌ها هم با ویرایشگر یکی می‌شود.
     */
    private fun updateLineNumbers() {
        if (!::lineNumbers.isInitialized) return
        val settings = TextSettings.load(this)
        if (!settings.lineNumbering && !settings.lineLettering) {
            lineNumbers.visibility = View.GONE
            return
        }
        lineNumbers.visibility = View.VISIBLE
        lineNumbers.translationY = -textScrollView.scrollY.toFloat()
        lineNumbers.typeface = editText.typeface

        // ارتفاع هر خط برچسب را با ارتفاع خط ویرایشگر برابر می‌کنیم.
        val base = lineNumbers.paint.getFontMetricsInt(null)
        lineNumbers.setLineSpacing((editText.lineHeight - base).toFloat(), 1f)

        val content = editText.text
        val layout = editText.layout
        val labels = StringBuilder()
        var paragraphIndex = 0
        if (layout != null && content.isNotEmpty()) {
            for (i in 0 until layout.lineCount) {
                val start = layout.getLineStart(i)
                if (start == 0 || content[start - 1] == '\n') {
                    paragraphIndex++
                    val number = paragraphIndex.toString()
                    val letter = if (settings.lineLettering) {
                        if (settings.lineLetterMode == 1) {
                            settings.lineLetterCustom.ifBlank { "a" }
                        } else {
                            alphabeticLineLabel(paragraphIndex)
                        }
                    } else ""
                    val label = when {
                        settings.lineNumbering && settings.lineLettering ->
                            if (settings.lineLabelOrder == 0) number + letter else letter + number
                        settings.lineNumbering -> number
                        settings.lineLettering -> letter
                        else -> ""
                    }
                    labels.append(label)
                }
                if (i < layout.lineCount - 1) labels.append('\n')
            }
        } else {
            val count = maxOf(1, content.count { it == '\n' } + 1)
            for (i in 1..count) {
                val number = i.toString()
                val letter = if (settings.lineLettering) {
                    if (settings.lineLetterMode == 1) settings.lineLetterCustom.ifBlank { "a" }
                    else alphabeticLineLabel(i)
                } else ""
                labels.append(when {
                    settings.lineNumbering && settings.lineLettering ->
                        if (settings.lineLabelOrder == 0) number + letter else letter + number
                    settings.lineNumbering -> number
                    settings.lineLettering -> letter
                    else -> ""
                })
                if (i < count) labels.append('\n')
            }
        }

        val result = labels.toString()
        if (result != lastLineNumbersText) {
            lastLineNumbersText = result
            lineNumbers.text = result
        }
    }

    /** a, b, ... z, aa, ab, ... برای تعداد نامحدود بند. */
    private fun alphabeticLineLabel(index: Int): String {
        var n = index
        val out = StringBuilder()
        while (n > 0) {
            n--
            out.append(('a'.code + (n % 26)).toChar())
            n /= 26
        }
        return out.reverse().toString()
    }

    private fun setupDrawerMenu() {

        val drawerLayout =
            findViewById<DrawerLayout>(
                R.id.drawerLayout
            )

        val navigationView =
            findViewById<NavigationView>(
                R.id.navigationView
            )

        navigationView.menu
            .findItem(R.id.nav_about_app)
            .title =
            AppLang.t("درباره اپلیکیشن (${AppInfo.fullVersion})", "About the app (${AppInfo.fullVersion})")

        val systemKeyboardItem = navigationView.menu.findItem(R.id.nav_system_keyboard)
        systemKeyboardItem.isChecked = appPrefs.getBoolean("system_keyboard_enabled", false)

        updateRotationMenuItem(navigationView.menu.findItem(R.id.nav_rotation_sync))

        navigationView.menu.findItem(R.id.nav_glide_typing)?.isChecked = GlideSettings.enabled(this)

        updateChangelogBadge()

        // جهت منوی کناری همیشه با زبان برنامه یکی باشد (فارسی ← راست‌به‌چپ، English ← چپ‌به‌راست)
        drawerLayout.layoutDirection = AppLang.layoutDirection
        navigationView.layoutDirection = AppLang.layoutDirection

        findViewById<ImageButton>(
            R.id.btnMenu
        ).setOnClickListener {
            // عرض منو با پهن‌ترین عنوان آیتم‌ها (در همین زبان) هماهنگ می‌شود
            MainMenuStyler.fitWidth(this)
            drawerLayout.openDrawer(navigationView)
        }

        navigationView.setNavigationItemSelectedListener { item ->
            handleNavItem(item)
            drawerLayout.closeDrawer(navigationView)
            true
        }

        // ظاهر سفارشی «تنظیمات منو اصلی» (اگر کاربر فعال کرده باشد) فقط روی همین منو اعمال می‌شود.
        MainMenuStyler.refresh(this)
    }

    /** اجرای یک آیتم منوی کناری؛ هم از خود منو و هم از آیکون‌های میانبر صدا زده می‌شود. */
    private fun handleNavItem(item: android.view.MenuItem) {

        // تور آموزشی اولیه (اختیاری): اگر فعال باشد و برای این آیتم پیامی در فایل تور باشد، نشان داده می‌شود
        com.example.persianfontkeyboard.onboarding.OnboardingTour.onMenuItem(this, item.itemId)

        // سخنگو: نام آیتم انتخاب‌شده با TalkBack اعلام می‌شود (اگر کاربر روشن گذاشته باشد)
        SpeakingApp.onMenuItem(editText, item.title ?: "")

            when (item.itemId) {

                R.id.nav_language ->
                    showLanguageDialog()

                R.id.nav_text_settings ->
                    showTextAndColorDialog()

                R.id.nav_select_font ->
                    FontManager.showFontPickerDialog(
                        this,
                        forApp = true
                    ) { chosen ->
                        if (FontManager.isCustomFont(this, chosen)) {
                            Toast.makeText(this, AppLang.t("فونت سفارشی فقط در نوشتن روی عکس و ساخت فیلم/زیرنویس استفاده می‌شود.", "A custom font is only used in Write on Image and when making videos/subtitles."), Toast.LENGTH_LONG).show()
                        } else {
                            applyFont(chosen)
                        }
                    }

                R.id.nav_welcome_settings ->
                    WelcomeSettingsDialog.show(this)

                R.id.nav_main_menu_settings ->
                    MainMenuSettingsDialog.show(this)

                R.id.nav_app_icon ->
                    startActivity(Intent(this, AppIconActivity::class.java))

                R.id.nav_speaking_app ->
                    SpeakingAppDialog.show(this) { editText.text?.toString().orEmpty() }

                R.id.nav_onboarding ->
                    startActivity(
                        Intent(
                            this,
                            com.example.persianfontkeyboard.onboarding.OnboardingActivity::class.java
                        )
                    )

                R.id.nav_security ->
                    startActivity(
                        Intent(
                            this,
                            com.example.persianfontkeyboard.security.SecurityActivity::class.java
                        )
                    )

                R.id.nav_audio_studio ->
                    startActivity(Intent(this, AudioStudioActivity::class.java))

                R.id.nav_write_on_image ->
                    startActivity(
                        Intent(
                            this,
                            ImageTextEditorActivity::class.java
                        )
                    )

                R.id.nav_free_design ->
                    startActivity(
                        Intent(
                            this,
                            FreeDesignActivity::class.java
                        )
                    )

                R.id.nav_font_studio ->
                    // استودیوی فونت اختیاری است: اگر دانلود نشده باشد، صفحهٔ مدیریت پیام «بارگیری کنید» را نشان می‌دهد
                    startActivity(
                        Intent(
                            this,
                            com.example.persianfontkeyboard.fontstudio.FontStudioHubActivity::class.java
                        )
                    )

                R.id.nav_emoji_system ->
                    startActivity(Intent(this, EmojiSystemActivity::class.java))

                R.id.nav_sticker_system ->
                    startActivity(Intent(this, StickerSystemActivity::class.java))

                R.id.nav_print_system ->
                    startActivity(
                        Intent(
                            this,
                            com.example.persianfontkeyboard.print.PrintSystemActivity::class.java
                        ).apply {
                            // متن فعلی کادر اصلی برای چاپ آماده می‌شود
                            val t = editText.text?.toString().orEmpty()
                            if (t.isNotBlank()) putExtra(com.example.persianfontkeyboard.print.PrintHelper.EXTRA_TEXT, t)
                        }
                    )

                R.id.nav_stylus_system ->
                    stylusLauncher.launch(
                        Intent(
                            this,
                            com.example.persianfontkeyboard.stylus.StylusSystemActivity::class.java
                        ).putExtra(com.example.persianfontkeyboard.stylus.StylusSystemActivity.EXTRA_FOR_RESULT, true)
                    )

                R.id.nav_physical_input ->
                    startActivity(
                        Intent(
                            this,
                            com.example.persianfontkeyboard.physical.PhysicalInputActivity::class.java
                        )
                    )

                R.id.nav_subtitle_burn ->
                    startActivity(
                        Intent(
                            this,
                            SubtitleBurnActivity::class.java
                        )
                    )

                R.id.nav_toggle_dark -> {
                    val items = arrayOf(AppLang.t("تم و پس‌زمینه", "Theme & background"), AppLang.t("پروفایل ظاهر", "Appearance profile"), AppLang.t("حالت تمرکز (مخفی‌کردن ابزارها)", "Focus mode (hide tools)"))
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle(AppLang.t("ظاهر و تمرکز", "Look & focus"))
                        .setItems(items) { _, which ->
                            when (which) {
                                0 -> ThemeManager.showPicker(
                                    this,
                                    onPickBackground = {
                                        KeyboardBackgroundManager.showBackgroundChooser(
                                            this,
                                            onPickImage = { backgroundPickerLauncher.launch("image/*") },
                                            onApplied = {
                                                applyKeyboardBackground()
                                                KeyboardBackgroundManager.applyWholeApp(this)
                                            }
                                        )
                                    }
                                )
                                1 -> AppearanceProfile.showManager(
                                    this,
                                    onApplied = { applyTextSettings(it) },
                                    onNeedRecreate = { recreate() }
                                )
                                2 -> toggleFocusMode()
                            }
                        }.show()
                }

                R.id.nav_handwriting_word ->
                    startActivity(
                        Intent(
                            this,
                            com.example.persianfontkeyboard.handwriting.HandwritingHubActivity::class.java
                        )
                    )

                R.id.nav_glide_typing -> {
                    // پنجرهٔ تنظیمات: روشن/خاموش، منبع تایپ کشیدنی و ذخیره‌سازی سریع
                    item.isChecked = GlideSettings.enabled(this)
                    GlideSettingsDialog.show(this) { item.isChecked = GlideSettings.enabled(this) }
                }

                R.id.nav_dictionary_hub ->
                    startActivity(
                        Intent(
                            this,
                            com.example.persianfontkeyboard.dictionary.DictionaryHubActivity::class.java
                        )
                    )

                R.id.nav_dictionary_lookup -> {
                    val full = editText.text.toString()
                    val s = editText.selectionStart
                    val e = editText.selectionEnd
                    val picked = (if (s >= 0 && e > s) full.substring(s, e) else full).trim().take(80)
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle(AppLang.t("فرهنگ واژگان", "Dictionary"))
                        .setMessage(if (picked.isEmpty()) AppLang.t("متنی در ویرایشگر نیست؛ می‌توانید خالی ادامه دهید.", "There is no text in the editor; you can continue empty.") else picked)
                        .setItems(arrayOf(AppLang.t("جستجوی این متن", "Search this text"), AppLang.t("افزودن به فرهنگ واژگان", "Add to dictionary"))) { _, which ->
                            if (which == 0) {
                                startActivity(
                                    Intent(this, com.example.persianfontkeyboard.dictionary.WordSearchActivity::class.java)
                                        .putExtra(com.example.persianfontkeyboard.dictionary.WordSearchActivity.EXTRA_QUERY, picked)
                                )
                            } else {
                                startActivity(
                                    Intent(this, com.example.persianfontkeyboard.dictionary.AddEditWordActivity::class.java)
                                        .putExtra(com.example.persianfontkeyboard.dictionary.AddEditWordActivity.EXTRA_TERM, picked)
                                )
                            }
                        }
                        .setNegativeButton(AppLang.t("انصراف", "Cancel"), null)
                        .show()
                }

                R.id.nav_script_converter ->
                    converterLauncher.launch(
                        Intent(this, ScriptConverterActivity::class.java)
                    )

                R.id.nav_send_to_converter -> {
                    val text = editText.text.toString()
                    if (text.isBlank()) {
                        Toast.makeText(this, AppLang.t("ابتدا در ویرایشگر اصلی متنی بنویسید", "First write some text in the main editor"), Toast.LENGTH_SHORT).show()
                    } else {
                        converterLauncher.launch(
                            Intent(this, ScriptConverterActivity::class.java)
                                .putExtra(ScriptConverterActivity.EXTRA_EDITOR_TEXT, text.take(100_000))
                                .putExtra(ScriptConverterActivity.EXTRA_AUTO_INSERT, true)
                        )
                    }
                }

                R.id.nav_send_to_free_design -> {
                    val text = editText.text.toString()
                    if (text.isBlank()) {
                        Toast.makeText(this, AppLang.t("ابتدا در ویرایشگر اصلی متنی بنویسید", "First write some text in the main editor"), Toast.LENGTH_SHORT).show()
                    } else {
                        startActivity(
                            Intent(this, FreeDesignActivity::class.java)
                                .putExtra(FreeDesignActivity.EXTRA_TEXT, text.take(2000))
                        )
                    }
                }

                R.id.nav_qr_text ->
                    openQr(SpeechQuick.textOf(editText))

                R.id.nav_alphabet_table ->
                    startActivity(
                        Intent(this, AlphabetTableActivity::class.java)
                    )

                R.id.nav_compare_scripts ->
                    startActivity(
                        Intent(this, ScriptCompareActivity::class.java)
                            .putExtra(ScriptCompareActivity.EXTRA_TEXT, editText.text.toString().trim().take(80))
                    )

                R.id.nav_daily_word ->
                    startActivity(Intent(this, DailyWordActivity::class.java))

                R.id.nav_home_widget ->
                    startActivity(Intent(this, HomeWidgetsActivity::class.java))

                R.id.nav_quiz ->
                    startActivity(Intent(this, QuizActivity::class.java))

                R.id.nav_review_cards ->
                    startActivity(Intent(this, ReviewCardsActivity::class.java))

                R.id.nav_word_game ->
                    startActivity(Intent(this, com.example.persianfontkeyboard.wordgame.ui.WordGameActivity::class.java))

                R.id.nav_search_text ->
                    showSearchDialog()

                R.id.nav_undo ->
                    undoEdit()

                R.id.nav_redo ->
                    redoEdit()

                R.id.nav_save_text ->
                    saveTextToFile()

                R.id.nav_export_transparent ->
                    exportTransparentImage()

                R.id.nav_clear_quick_chars ->
                    showCharHistoryDialog()

                R.id.nav_screenshot ->
                    takeScreenshot()

                R.id.nav_saved_texts ->
                    openSavedTexts()

                R.id.nav_saved_pdfs ->
                    openSavedFiles(
                        SavedFilesActivity.TYPE_PDF
                    )
R.id.nav_backup ->
                    backupCreateLauncher.launch(BackupManager.suggestedFileName())

                R.id.nav_backup_share ->
                    shareBackupToCloud()

                R.id.nav_restore ->
                    confirmRestore()

                R.id.nav_about_dev ->
                    MenuActionsHelper.showAboutDeveloperDialog(
                        this
                    )

                R.id.nav_web_version ->
                    MenuActionsHelper.openWebVersion(this)

                R.id.nav_website ->
                    MenuActionsHelper.showWebsiteDialog(
                        this
                    )

                R.id.nav_about_app ->
                    MenuActionsHelper.showAboutAppDialog(
                        this
                    )

                R.id.nav_feedback ->
                    MenuActionsHelper.showFeedbackDialog(
                        this
                    )

                R.id.nav_update ->
                    MenuActionsHelper.openUpdatePage(this)

                R.id.nav_changelog -> {
                    ChangelogHelper.show(this)
                    appPrefs.edit()
                        .putString("last_seen_changelog", getCurrentChangelogTag())
                        .apply()
                    item.title = AppLang.t("تغییرات نسخه", "Version changes")
                }

                R.id.nav_rotation_sync -> {
                    val newState = !RotationManager.isEnabled(this)
                    RotationManager.setEnabled(this, newState)
                    updateRotationMenuItem(item)
                    val message = when {
                        !newState ->
                            AppLang.t("همگام‌سازی چرخش خاموش شد؛ برنامه در جهت فعلی قفل شد", "Rotation sync turned off; the app is locked in the current orientation")
                        !RotationManager.isSystemAutoRotateOn(this) ->
                            AppLang.t("همگام‌سازی چرخش روشن شد؛ ولی «چرخش خودکار» خود گوشی خاموش است. برای چرخش برنامه، آن را از پنل تنظیمات سریع گوشی روشن کنید", "Rotation sync turned on; but your phone's own “Auto-rotate” is off. To rotate the app, turn it on from the phone's quick settings panel")
                        else ->
                            AppLang.t("همگام‌سازی چرخش روشن شد؛ برنامه با چرخش گوشی می‌چرخد", "Rotation sync turned on; the app rotates with the phone")
                    }
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }

                R.id.nav_system_keyboard -> {
                    val newState = !item.isChecked
                    item.isChecked = newState
                    appPrefs.edit().putBoolean("system_keyboard_enabled", newState).apply()
                    // فعال‌کردن این گزینه فقط اجازهٔ استفاده از دکمهٔ کیبورد گوشی را می‌دهد؛
                    // کیبورد گوشی خودکار باز نمی‌شود.
                    if (!systemKeyboardShown) editText.setShowSoftInputOnFocus(false)

                    if (!newState) {
                        hideSystemKeyboard()
                        systemKeyboardShown = false
                        findViewById<View>(R.id.keyboardPanel).visibility = View.VISIBLE
                        findViewById<Button>(R.id.btnToggleAppKeyboard).text = AppLang.t("بستن کیبورد اپلیکیشن", "Close app keyboard")
                        findViewById<Button>(R.id.btnSystemKeyboard).text = AppLang.t("استفاده از کیبورد گوشی", "Use phone keyboard")
                        editText.setShowSoftInputOnFocus(false)
                        Toast.makeText(this, AppLang.t("دسترسی به کیبورد گوشی غیرفعال شد", "Phone keyboard access disabled"), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, AppLang.t("دسترسی به کیبورد گوشی فعال شد", "Phone keyboard access enabled"), Toast.LENGTH_SHORT).show()
                    }
                }

                R.id.nav_share_app ->
                    MenuActionsHelper.shareApp(
                        this
                    )

                R.id.nav_telegram_channel -> {
                    val telegramUri = android.net.Uri.parse("https://t.me/dabireirani")
                    val telegramIntent = Intent(Intent.ACTION_VIEW, telegramUri).apply {
                        setPackage("org.telegram.messenger")
                    }
                    try {
                        startActivity(telegramIntent)
                    } catch (_: android.content.ActivityNotFoundException) {
                        val telegramXIntent = Intent(Intent.ACTION_VIEW, telegramUri).apply {
                            setPackage("org.thunderdog.challegram")
                        }
                        try {
                            startActivity(telegramXIntent)
                        } catch (_: android.content.ActivityNotFoundException) {
                            startActivity(Intent(Intent.ACTION_VIEW, telegramUri))
                        }
                    }
                }
            }
    }

    /** عنوان و وضعیت گزینهٔ «همگام‌سازی چرخش» را با تنظیم فعلی هماهنگ می‌کند. */
    private fun updateRotationMenuItem(item: android.view.MenuItem) {
        val on = RotationManager.isEnabled(this)
        item.isChecked = on
        item.title = if (on) AppLang.t("همگام‌سازی چرخش: روشن", "Rotation sync: on") else AppLang.t("همگام‌سازی چرخش: خاموش", "Rotation sync: off")
    }

    private fun takeScreenshot() {
        Handler(Looper.getMainLooper()).postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            var bitmap: android.graphics.Bitmap? = null
            try {
                val root = window.decorView
                if (root.width <= 0 || root.height <= 0) throw IllegalStateException(AppLang.t("صفحه آماده نیست", "The screen isn't ready"))
                bitmap = android.graphics.Bitmap.createBitmap(
                    root.width, root.height, android.graphics.Bitmap.Config.ARGB_8888
                )
                root.draw(android.graphics.Canvas(bitmap))

                val dir = getExternalFilesDir(null) ?: filesDir
                if (!dir.exists()) dir.mkdirs()
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
                val file = File(dir, "screenshot_$stamp.png")
                java.io.FileOutputStream(file).use { out ->
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
                }
                Toast.makeText(
                    this,
                    AppLang.t("اسکرین‌شات ذخیره شد و در «عکس‌های ذخیره‌شده» هست", "Screenshot saved and available in “Saved images”"),
                    Toast.LENGTH_LONG
                ).show()

                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, AppLang.t("اشتراک‌گذاری اسکرین‌شات", "Share screenshot")))
            } catch (e: Exception) {
                Toast.makeText(this, AppLang.t("گرفتن اسکرین‌شات ناموفق بود: ${e.message}", "Taking the screenshot failed: ${e.message}"), Toast.LENGTH_LONG).show()
            } finally {
                bitmap?.recycle()
            }
        }, 400L)
    }

    private fun getCurrentChangelogTag(): String = "v${AppInfo.fullVersion}"

    private fun updateChangelogBadge() {
        val navigationView = findViewById<NavigationView>(R.id.navigationView) ?: return
        val item = navigationView.menu.findItem(R.id.nav_changelog) ?: return

        val lastSeen = appPrefs.getString("last_seen_changelog", "") ?: ""
        val current = getCurrentChangelogTag()

        item.title = if (lastSeen != current) {
            AppLang.t("تغییرات نسخه 🔴", "Version changes 🔴")
        } else {
            AppLang.t("تغییرات نسخه", "Version changes")
        }
    }

    /**
     * «زبان / Language»: «زبان پیش‌فرض گوشی» (خودکار)، فارسی (راست‌به‌چپ) یا English (چپ‌به‌راست).
     * با تغییر زبان، برنامه یک بار خودکار دوباره باز می‌شود تا همهٔ بخش‌ها با زبان تازه ساخته شوند؛
     * متن نوشته‌شدهٔ کادر اصلی پیش‌از آن ذخیره می‌شود.
     * در حالت «پیش‌فرض گوشی»، با عوض شدن زبان گوشی زبان برنامه هم خودکار همگام می‌شود.
     */
    private fun showLanguageDialog() {

        val modes = arrayOf(AppLang.SYSTEM, AppLang.FA, AppLang.EN)
        val sysName = if (AppLang.systemLanguage() == AppLang.EN) "English" else "فارسی"
        val labels = arrayOf(
            "زبان پیش‌فرض گوشی / Phone default language\n(" + AppLang.t("اکنون: ", "now: ") + sysName + ")",
            "فارسی  (Persian) — راست‌به‌چپ",
            "English (انگلیسی) — Left to right"
        )
        var checked = modes.indexOf(AppLang.mode).coerceAtLeast(0)

        val dialog = AlertDialog.Builder(this)
            .setTitle("زبان / Language")
            .setSingleChoiceItems(labels, checked) { _, which -> checked = which }
            .setPositiveButton(AppLang.t("اعمال", "Apply")) { _, _ ->
                val target = modes[checked]
                if (target == AppLang.mode) return@setPositiveButton

                // متن کادر اصلی را پیش از ری‌استارت ذخیره می‌کنیم
                saveDraftNow()

                if (AppLang.set(this, target)) {
                    Toast.makeText(
                        this,
                        if (AppLang.isEnglish) "Applying English…" else "در حال اعمال زبان فارسی…",
                        Toast.LENGTH_SHORT
                    ).show()
                    AppLang.restartApp(this)
                } else {
                    // فقط شیوهٔ انتخاب عوض شده (زبان همان است) ← نیازی به راه‌اندازی مجدد نیست
                    Toast.makeText(
                        this,
                        if (target == AppLang.SYSTEM)
                            AppLang.t("زبان برنامه با زبان گوشی همگام می‌شود.", "The app language will follow the phone language.")
                        else
                            AppLang.t("زبان ذخیره شد.", "Language saved."),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton(AppLang.t("انصراف", "Cancel"), null)
            .create()

        dialog.show()
    }

    /** متن کادر اصلی را همین حالا (همگام) ذخیره می‌کند؛ پیش از راه‌اندازی مجدد برنامه. */
    private fun saveDraftNow() {
        if (!::editText.isInitialized) return
        draftSaveHandler.removeCallbacks(draftSaveRunnable)
        draftPrefs.edit()
            .putString("draft_text", editText.text.toString())
            .commit()
    }

    /**
     * «تاریخچه کاراکترها»: روشن/خاموش کردن کاراکترهای اخیر و محبوب،
     * و حذف همه یا انتخابی آن‌ها.
     */
    private fun showCharHistoryDialog() {

        fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

        val col = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(4))
            layoutDirection = AppLang.layoutDirection
        }

        val countView = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(4), 0, dp(8))
        }

        fun refreshCounts() {
            countView.text =
                AppLang.t("ذخیره‌شده: ${QuickCharsManager.recents(this@MainActivity).size} کاراکتر اخیر، ", "Saved: ${QuickCharsManager.recents(this@MainActivity).size} recent characters, ") +
                        AppLang.t("${QuickCharsManager.favorites(this@MainActivity).size} کاراکتر محبوب", "${QuickCharsManager.favorites(this@MainActivity).size} favorite characters")
        }
        refreshCounts()

        // ── کاراکترهای اخیر ──
        col.addView(androidx.appcompat.widget.SwitchCompat(this).apply {
            text = AppLang.t("تاریخچهٔ کاراکترهای اخیر", "Recent characters history")
            textSize = 14f
            isChecked = QuickCharsManager.recentEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                QuickCharsManager.setRecentEnabled(this@MainActivity, on)
                customKeyboard.refreshQuickRows()
            }
        })
        col.addView(TextView(this).apply {
            text = AppLang.t("ردیف «اخیر» پایین کیبورد، آخرین کاراکترهای تایپ‌شده را نشان می‌دهد. ", "The “Recent” row at the bottom of the keyboard shows the last characters you typed. ") +
                    AppLang.t("اگر خاموش باشد کاراکتری ثبت و نمایش داده نمی‌شود (فهرست قبلی پاک نمی‌شود).", "If off, no character is recorded or shown (the previous list isn't erased).")
            textSize = 11.5f
            setPadding(0, dp(2), 0, dp(10))
        })

        // ── کاراکترهای محبوب ──
        col.addView(androidx.appcompat.widget.SwitchCompat(this).apply {
            text = AppLang.t("کاراکترهای محبوب ★", "Favorite characters ★")
            textSize = 14f
            isChecked = QuickCharsManager.favoritesEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                QuickCharsManager.setFavoritesEnabled(this@MainActivity, on)
                customKeyboard.refreshQuickRows()
            }
        })
        col.addView(TextView(this).apply {
            text = AppLang.t("با نگه داشتن انگشت روی هر کاراکتر کیبورد، به محبوب‌ها اضافه می‌شود. ", "Long-press any keyboard character to add it to favorites. ") +
                    AppLang.t("اگر خاموش باشد ردیف ★ پنهان می‌شود و افزودن به محبوب‌ها کار نمی‌کند.", "If off, the ★ row is hidden and adding to favorites doesn't work.")
            textSize = 11.5f
            setPadding(0, dp(2), 0, dp(10))
        })

        col.addView(TextView(this).apply {
            text = AppLang.t("حذف سریع روی کیبورد: انگشت را روی کاراکتر ردیف «اخیر» ۳ ثانیه نگه دارید؛ ", "Quick delete on the keyboard: hold your finger on a character in the “Recent” row for 3 seconds; ") +
                    AppLang.t("روی کاراکتر ردیف ★ هم نگه داشتن آن را برمی‌دارد.", "holding a character in the ★ row also removes it.")
            textSize = 11.5f
            setPadding(0, 0, 0, dp(8))
        })

        col.addView(countView)

        fun confirmClear(title: String, message: String, action: () -> Unit) {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(AppLang.t("حذف", "Delete")) { _, _ ->
                    action()
                    customKeyboard.refreshQuickRows()
                    refreshCounts()
                    Toast.makeText(this, AppLang.t("حذف شد", "Deleted"), Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(AppLang.t("انصراف", "Cancel"), null)
                .show()
        }

        fun nothingToDelete(): Boolean {
            val empty = QuickCharsManager.recents(this).isEmpty() &&
                    QuickCharsManager.favorites(this).isEmpty()
            if (empty) {
                Toast.makeText(this, AppLang.t("تاریخچه‌ای برای حذف وجود ندارد", "There is no history to delete"), Toast.LENGTH_SHORT).show()
            }
            return empty
        }

        col.addView(Button(this).apply {
            text = AppLang.t("انتخاب و حذف کاراکترها…", "Choose and delete characters…")
            isAllCaps = false
            textSize = 12.5f
            setOnClickListener {
                if (!nothingToDelete()) showPickCharsToDeleteDialog { refreshCounts() }
            }
        })
        col.addView(Button(this).apply {
            text = AppLang.t("حذف همهٔ کاراکترهای اخیر", "Delete all recent characters")
            isAllCaps = false
            textSize = 12.5f
            setOnClickListener {
                if (QuickCharsManager.recents(this@MainActivity).isEmpty()) {
                    Toast.makeText(this@MainActivity, AppLang.t("کاراکتر اخیری وجود ندارد", "There are no recent characters"), Toast.LENGTH_SHORT).show()
                } else {
                    confirmClear(AppLang.t("حذف کاراکترهای اخیر", "Delete recent characters"), AppLang.t("همهٔ کاراکترهای اخیر پاک شوند؟", "Delete all recent characters?")) {
                        QuickCharsManager.clearRecents(this@MainActivity)
                    }
                }
            }
        })
        col.addView(Button(this).apply {
            text = AppLang.t("حذف همهٔ کاراکترهای محبوب", "Delete all favorite characters")
            isAllCaps = false
            textSize = 12.5f
            setOnClickListener {
                if (QuickCharsManager.favorites(this@MainActivity).isEmpty()) {
                    Toast.makeText(this@MainActivity, AppLang.t("کاراکتر محبوبی وجود ندارد", "There are no favorite characters"), Toast.LENGTH_SHORT).show()
                } else {
                    confirmClear(AppLang.t("حذف کاراکترهای محبوب", "Delete favorite characters"), AppLang.t("همهٔ کاراکترهای محبوب پاک شوند؟", "Delete all favorite characters?")) {
                        QuickCharsManager.clearFavorites(this@MainActivity)
                    }
                }
            }
        })
        col.addView(Button(this).apply {
            text = AppLang.t("حذف همه (اخیر و محبوب)", "Delete all (recent and favorite)")
            isAllCaps = false
            textSize = 12.5f
            setOnClickListener {
                if (!nothingToDelete()) {
                    confirmClear(AppLang.t("حذف همه", "Delete all"), AppLang.t("همهٔ کاراکترهای اخیر و محبوب پاک شوند؟", "Delete all recent and favorite characters?")) {
                        QuickCharsManager.clearAll(this@MainActivity)
                    }
                }
            }
        })

        AlertDialog.Builder(this)
            .setTitle(AppLang.t("تاریخچه کاراکترها", "Character history"))
            .setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton(AppLang.t("بستن", "Close"), null)
            .show()
    }

    private fun showPickCharsToDeleteDialog(onChanged: () -> Unit = {}) {

        val recents = QuickCharsManager.recents(this)
        val favorites = QuickCharsManager.favorites(this)

        if (recents.isEmpty() && favorites.isEmpty()) {
            Toast.makeText(
                this,
                AppLang.t("تاریخچه‌ای برای حذف وجود ندارد", "There is no history to delete"),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val entries =
            favorites.map { it to true } + recents.map { it to false }

        fun label(entry: Pair<String, Boolean>): String {
            val hex = "U+%04X".format(entry.first.codePointAt(0))
            val kind = if (entry.second) AppLang.t("★ محبوب", "★ Favorites") else AppLang.t("اخیر", "Recent")
            return "$kind:   ${entry.first}    ($hex)"
        }

        val checked = BooleanArray(entries.size)

        AlertDialog.Builder(this)
            .setTitle(AppLang.t("حذف کاراکترهای انتخابی", "Delete selected characters"))
            .setMultiChoiceItems(
                entries.map { label(it) }.toTypedArray(),
                checked
            ) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton(AppLang.t("حذف انتخاب‌شده‌ها", "Delete selected")) { _, _ ->

                val favRemove = mutableListOf<String>()
                val recentRemove = mutableListOf<String>()

                entries.forEachIndexed { index, entry ->
                    if (checked[index]) {
                        if (entry.second) favRemove += entry.first
                        else recentRemove += entry.first
                    }
                }

                if (favRemove.isEmpty() && recentRemove.isEmpty()) {
                    Toast.makeText(
                        this,
                        AppLang.t("موردی انتخاب نشده است", "Nothing is selected"),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    QuickCharsManager.removeFavorites(this, favRemove)
                    QuickCharsManager.removeRecents(this, recentRemove)
                    customKeyboard.refreshQuickRows()
                    onChanged()
                    Toast.makeText(
                        this,
                        AppLang.t("${favRemove.size + recentRemove.size} مورد حذف شد", "${favRemove.size + recentRemove.size} items deleted"),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNeutralButton(AppLang.t("حذف همه", "Delete all")) { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle(AppLang.t("حذف همه", "Delete all"))
                    .setMessage(AppLang.t("همه‌ی کاراکترهای اخیر و محبوب پاک شوند؟", "Delete all recent and favorite characters?"))
                    .setPositiveButton(AppLang.t("حذف", "Delete")) { _, _ ->
                        QuickCharsManager.clearAll(this)
                        customKeyboard.refreshQuickRows()
                    onChanged()
                        Toast.makeText(
                            this,
                            AppLang.t("همه حذف شد", "All deleted"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    .setNegativeButton(AppLang.t("انصراف", "Cancel"), null)
                    .show()
            }
            .setNegativeButton(AppLang.t("انصراف", "Cancel"), null)
            .show()
    }

    private fun confirmRestore() {
        AlertDialog.Builder(this)
            .setTitle(AppLang.t("بازیابی از پشتیبان", "Restore from backup"))
            .setMessage(
                AppLang.t("تنظیمات فعلی با تنظیمات فایل پشتیبان جایگزین می‌شود. ", "Your current settings will be replaced by the settings in the backup file. ") +
                        AppLang.t("متن‌های پشتیبان به متن‌های فعلی اضافه می‌شوند و هیچ متنی بازنویسی نمی‌شود.", "The backup's texts are added to your current texts, and no text is overwritten.")
            )
            .setPositiveButton(AppLang.t("انتخاب فایل", "Choose file")) { _, _ ->
                backupRestoreLauncher.launch(
                    arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
                )
            }
            .setNegativeButton(AppLang.t("انصراف", "Cancel"), null)
            .show()
    }

    private fun openSavedTexts() {

        val intent =
            Intent(
                this,
                SavedFilesActivity::class.java
            )

        intent.putExtra(
            SavedFilesActivity.EXTRA_FILE_TYPE,
            SavedFilesActivity.TYPE_TEXT
        )

        savedTextLauncher.launch(intent)
    }

    private fun openSavedFiles(type: String) {

        val intent =
            Intent(
                this,
                SavedFilesActivity::class.java
            )

        intent.putExtra(
            SavedFilesActivity.EXTRA_FILE_TYPE,
            type
        )

        startActivity(intent)
    }

    private fun saveTextToFile() {

        val text = editText.text.toString()

        if (text.isBlank()) {
            Toast.makeText(
                this,
                AppLang.t("متنی برای ذخیره وجود ندارد", "There is no text to save"),
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        try {

            val file =
                timestampedFile(
                    "text_note",
                    "txt"
                )

            file.writeText(text)

            Toast.makeText(
                this,
                AppLang.t("متن ذخیره شد", "Text saved"),
                Toast.LENGTH_SHORT
            ).show()

        } catch (e: Exception) {

            Toast.makeText(
                this,
                AppLang.t("خطا در ذخیره‌ی متن: ${e.message}", "Error saving the text: ${e.message}"),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun showSearchDialog() {

        val input =
            EditText(this).apply {
                hint = AppLang.t("متن مورد نظر برای جستجو", "Text to search for")
                gravity = Gravity.END
                textDirection =
                    AppLang.textDirection
            }

        lastFoundIndex = -1

        val dialog =
            AlertDialog.Builder(this)
                .setTitle(AppLang.t("جستجو در متن", "Search in text"))
                .setView(input)
                .setPositiveButton(
                    AppLang.t("بعدی", "Next"),
                    null
                )
                .setNegativeButton(
                    AppLang.t("بستن", "Close"),
                    null
                )
                .create()

        dialog.setOnShowListener {

            dialog.getButton(
                AlertDialog.BUTTON_POSITIVE
            ).setOnClickListener {

                val query =
                    input.text.toString()

                if (query.isEmpty()) {
                    return@setOnClickListener
                }

                val text =
                    editText.text.toString()

                val searchFrom =
                    if (lastFoundIndex >= 0) {
                        lastFoundIndex + 1
                    } else {
                        0
                    }

                var foundIndex =
                    text.indexOf(
                        query,
                        searchFrom,
                        ignoreCase = true
                    )

                if (foundIndex < 0) {
                    foundIndex =
                        text.indexOf(
                            query,
                            0,
                            ignoreCase = true
                        )
                }

                if (foundIndex >= 0) {

                    lastFoundIndex =
                        foundIndex

                    editText.requestFocus()

                    editText.setSelection(
                        foundIndex,
                        foundIndex + query.length
                    )

                } else {

                    Toast.makeText(
                        this,
                        AppLang.t("چیزی پیدا نشد", "Nothing found"),
                        Toast.LENGTH_SHORT
                    ).show()

                    lastFoundIndex = -1
                }
            }
        }

        dialog.show()
    }

    private fun applyTextColor(color: Int) {
        editText.setTextColor(color)
        customKeyboard.setCharacterTextColor(color)
    }

    private fun applyKeyboardBackground() {
        KeyboardBackgroundManager.apply(
            this,
            textScrollView,
            customKeyboard
        )
    }

    private fun applyFont(fileName: String) {

        currentFontFile = try {

            fontTypeface =
                FontManager.createTypeface(this, fileName)

            fileName

        } catch (e: Exception) {

            val fallbackFont =
                FontManager.getDefaultFontFile(this)

            if (fallbackFont == null) {

                Toast.makeText(
                    this,
                    AppLang.t("هیچ فونتی در پوشه fonts پیدا نشد", "No font was found in the fonts folder"),
                    Toast.LENGTH_LONG
                ).show()

                return
            }

            Toast.makeText(
                this,
                AppLang.t("فونت انتخاب‌شده پیدا نشد؛ اولین فونت موجود بارگذاری شد", "The selected font wasn't found; the first available font was loaded"),
                Toast.LENGTH_SHORT
            ).show()

            try {

                fontTypeface =
                    FontManager.createTypeface(this, fallbackFont)

                fallbackFont

            } catch (fallbackException: Exception) {

                Toast.makeText(
                    this,
                    AppLang.t("خطا در بارگذاری فونت", "Error loading the font"),
                    Toast.LENGTH_LONG
                ).show()

                return
            }
        }

        appliedFontStamp = FontManager.fontStamp(this, currentFontFile)

        editText.typeface = fontTypeface
        TextSettingsApplier.apply(editText, TextSettings.load(this))

        customKeyboard.setFontTypeface(
            fontTypeface
        )

        loadFontCharactersAsync(
            currentFontFile
        )
    }

    private fun loadFontCharactersAsync(
        fileName: String
    ) {

        val generation =
            ++fontLoadGeneration

        Thread(
            {

                val codePoints =
                    try {

                        val bytes =
                            FontManager.readFontBytes(
                                this,
                                fileName
                            )

                        FontUnicodeReader
                            .getSupportedCodePoints(
                                bytes
                            )

                    } catch (e: Exception) {

                        emptySet()
                    }

                val scripts =
                    UnicodeScripts.buildScripts(
                        codePoints
                    )

                val savedScriptName =
                    appPrefs.getString(
                        "last_script_name",
                        null
                    )

                Handler(
                    Looper.getMainLooper()
                ).post {

                    if (
                        generation != fontLoadGeneration ||
                        isFinishing ||
                        isDestroyed
                    ) {
                        return@post
                    }

                    if (scripts.isEmpty()) {

                        Toast.makeText(
                            this,
                            AppLang.t("هیچ کاراکتری در فونت پیدا نشد", "No character was found in the font"),
                            Toast.LENGTH_LONG
                        ).show()

                    } else {

                        customKeyboard.setScripts(
                            scripts,
                            savedScriptName
                        )
                    }
                }

            },
            "font-loader-$generation"
        ).start()
    }

    /**
     * تا وقتی کاربر کیبورد گوشی را با دکمهٔ مخصوصش باز نکرده، کیبورد گوشی نباید بالا بیاید.
     * بعضی گوشی‌ها کیبورد را کمی دیرتر از لمس/فوکوس باز می‌کنند؛ پس چند بار پشت‌سرهم بسته می‌شود.
     */
    private fun enforceAppKeyboardOnly() {
        if (!::editText.isInitialized || systemKeyboardShown) return
        editText.setShowSoftInputOnFocus(false)
        hideSystemKeyboard()
        for (delay in longArrayOf(0L, 120L, 350L)) {
            editText.postDelayed({
                if (!systemKeyboardShown) {
                    editText.setShowSoftInputOnFocus(false)
                    hideSystemKeyboard()
                }
            }, delay)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enforceAppKeyboardOnly()
    }

    private fun hideSystemKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(editText.windowToken, 0)
    }

    // ---------------------------------------------------------------- پنل ایموجی داخل کیبورد

    private var emojiEmbedded: EmojiPicker.Embedded? = null
    private var emojiHostView: View? = null
    /** فرزندهای پنل کیبورد (کیبورد، میانبر، برچسب خط) و وضعیت دیده‌شدنشان پیش از باز شدن پنل ایموجی. */
    private var emojiHiddenChildren: List<Pair<View, Int>> = emptyList()

    /**
     * دکمهٔ 😊: ایموجی، ایموجی متحرک و استیکر را درست جای کیبورد اپلیکیشن نشان می‌دهد؛ با «ABC» یا زدن دوباره برمی‌گردد.
     * (اصلاح باگ: قبلاً فقط «فرزند اول» پنل پنهان می‌شد و پنل ایموجی بدون ارتفاع مشخص اضافه می‌شد، پس در
     * بعضی چیدمان‌ها—به‌ویژه حالت افقی—اصلاً دیده نمی‌شد. حالا همهٔ فرزندان پنهان می‌شوند و پنل ایموجی
     * با وزن/ارتفاع حداقلی اضافه می‌شود.)
     */
    private fun toggleEmojiPanel() {
        val panel = findViewById<ViewGroup>(R.id.keyboardPanel) ?: return
        if (emojiEmbedded != null && panel.visibility == View.VISIBLE) {
            closeEmojiPanel()
            return
        }
        closeEmojiPanel()
        if (panel.visibility != View.VISIBLE) {
            panel.visibility = View.VISIBLE
            findViewById<Button>(R.id.btnToggleAppKeyboard)?.text = AppLang.t("بستن کیبورد اپلیکیشن", "Close app keyboard")
            findViewById<Button>(R.id.btnSystemKeyboard)?.text = AppLang.t("استفاده از کیبورد گوشی", "Use phone keyboard")
            systemKeyboardShown = false
            editText.setShowSoftInputOnFocus(false)
            hideSystemKeyboard()
        }
        val e = EmojiPicker.embed(this, { editText }) { closeEmojiPanel() }
        // همهٔ فرزندان فعلیِ پنل (کیبورد، نوار میانبر، برچسب خط…) پنهان می‌شوند تا جایی از پنل ایموجی نگیرند
        val hidden = ArrayList<Pair<View, Int>>()
        for (i in 0 until panel.childCount) {
            val child = panel.getChildAt(i)
            hidden.add(child to child.visibility)
            child.visibility = View.GONE
        }
        emojiHiddenChildren = hidden
        val lp: ViewGroup.LayoutParams =
            if (panel is LinearLayout) LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            else ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        e.view.minimumHeight = (resources.displayMetrics.density * 220).toInt()
        panel.addView(e.view, lp)
        emojiEmbedded = e
        emojiHostView = e.view
        ensureEditorFocused()
    }

    private fun closeEmojiPanel() {
        val e = emojiEmbedded ?: return
        emojiEmbedded = null
        e.stop()
        (emojiHostView?.parent as? ViewGroup)?.removeView(emojiHostView)
        emojiHostView = null
        for ((v, vis) in emojiHiddenChildren) v.visibility = vis
        emojiHiddenChildren = emptyList()
    }

    private fun ensureEditorFocused() {
        if (!editText.hasFocus()) {
            editText.requestFocus()
        }
        // ✅ فقط در صورتی که کیبورد اپلیکیشن فعال باشد، کیبورد گوشی مخفی می‌شود
        if (!systemKeyboardShown) {
            hideSystemKeyboard()
        }
    }

    private fun editorSelection(): Pair<Int, Int> {
        ensureEditorFocused()
        val len = editText.length()
        var start = editText.selectionStart
        var end = editText.selectionEnd
        if (start < 0 || end < 0) {
            start = len
            end = len
            if (len >= 0) {
                editText.setSelection(len)
            }
        }
        val left = minOf(start, end).coerceIn(0, len)
        val right = maxOf(start, end).coerceIn(0, len)
        return left to right
    }

    private fun applyEditorDirection(rtl: Boolean) {
        editText.textDirection =
            if (rtl) View.TEXT_DIRECTION_RTL
            else View.TEXT_DIRECTION_LTR
        editText.gravity =
            Gravity.TOP or if (rtl) Gravity.END else Gravity.START
        editText.textAlignment = View.TEXT_ALIGNMENT_GRAVITY
        editText.requestLayout()
    }

    /** جای ה/׳ ای که قانون پهلوی کتابی خودکار پیش از فاصله افزوده است (یا ‎-1). */
    private var ruleMark = -1
    private var ruleLetter = ""

    private fun insertAtCursor(text: String) {

        val editable: Editable =
            editText.text

        val (left, right) = editorSelection()
        val expectedLen = editable.length - (right - left) + text.length

        editable.replace(left, right, text)

        // اگر ناظر متن (مثل «قوانین خط پهلوی کتابی») نویسه‌ای پیش از مکان‌نما افزوده باشد، مکان‌نما باید
        // همچنان بعد از متن درج‌شده بماند، نه پیش از آن.
        val extra = (editText.length() - expectedLen).coerceAtLeast(0)
        val pos = (left + text.length + extra).coerceAtMost(editText.length())
        editText.setSelection(pos)
    }

    private fun deleteBeforeCursor() {

        val editable: Editable =
            editText.text

        val (left, right) = editorSelection()

        if (left != right) {

            editable.delete(left, right)
            editText.setSelection(left.coerceIn(0, editText.length()))
            return
        }

        val start = left

        if (start <= 0) {
            return
        }

        // برگرداندن قانون پهلوی کتابی: اگر درست پس از افزودن خودکار ה و فاصله بک‌اسپیس بزنیم،
        // هر دو (فاصله و ה خودکار) با هم پاک می‌شوند؛ پس زدن دوبارهٔ فاصله، ה را دوباره می‌گذارد
        // و واژه خراب (ה اضافه) نمی‌شود.
        val mark = ruleMark
        if (mark >= 0 && ruleLetter.isNotEmpty() && start == mark + ruleLetter.length + 1 &&
            start <= editable.length && editable[start - 1] == ' ' &&
            editable.subSequence(mark, mark + ruleLetter.length).toString() == ruleLetter
        ) {
            ruleMark = -1
            editable.delete(mark, start)
            editText.setSelection(mark.coerceIn(0, editText.length()))
            return
        }

        val bookStart = BookPahlavi.deleteStart(editable, start)
        if (bookStart >= 0) {
            editable.delete(bookStart, start)
            editText.setSelection(bookStart.coerceIn(0, editText.length()))
            return
        }

        // ایموجی/استیکر (حتی سفارشی و متحرک که با نویسه‌های نامرئی ذخیره می‌شود) یکجا پاک شود
        val emojiStart = EmojiText.emojiRunStartBefore(editable, start)
        if (emojiStart in 0 until start) {
            editable.delete(emojiStart, start)
            editText.setSelection(emojiStart.coerceIn(0, editText.length()))
            return
        }

        var deleteStart =
            Character.offsetByCodePoints(
                editable,
                start,
                -1
            )

        while (deleteStart > 0) {

            val cp =
                Character.codePointAt(
                    editable,
                    deleteStart
                )

            val type =
                Character.getType(cp)

            if (
                type ==
                Character.NON_SPACING_MARK.toInt() ||

                type ==
                Character.COMBINING_SPACING_MARK.toInt() ||

                cp == 0xFE0F
            ) {

                deleteStart =
                    Character.offsetByCodePoints(
                        editable,
                        deleteStart,
                        -1
                    )

            } else {

                break
            }
        }

        editable.delete(
            deleteStart,
            start
        )
        editText.setSelection(deleteStart.coerceIn(0, editText.length()))
    }

    /** واگردانی آخرین تغییر متن صفحهٔ اصلی (برای آیکون میانبر، آیتم منو و ...). */
    private fun undoEdit() {
        ensureEditorFocused()
        if (!editHistory.undo()) {
            Toast.makeText(
                this,
                AppLang.t("عملی برای بازگردانی وجود ندارد", "There is nothing to undo"),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    /** تکرار تغییری که واگردانی شده است. */
    private fun redoEdit() {
        ensureEditorFocused()
        if (!editHistory.redo()) {
            Toast.makeText(
                this,
                AppLang.t("عملی برای تکرار وجود ندارد", "There is nothing to redo"),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onSaveInstanceState(
        outState: Bundle
    ) {

        outState.putString(
            "editor_text",
            editText.text.toString()
        )

        outState.putInt(
            "selection_start",
            editText.selectionStart.coerceAtLeast(0)
        )

        outState.putInt(
            "font_size_sp",
            currentTextSizeSp.toInt()
        )

        textScrollView.getChildAt(0)?.let { content ->
            val range = (content.height - textScrollView.height).coerceAtLeast(0)
            outState.putFloat(
                "scroll_ratio",
                if (range > 0) (textScrollView.scrollY.toFloat() / range).coerceIn(0f, 1f) else 0f
            )
        }

        outState.putString(
            "font_file",
            currentFontFile
        )

        outState.putBoolean(
            "app_keyboard_visible",
            findViewById<View>(R.id.keyboardPanel).visibility == View.VISIBLE
        )

        super.onSaveInstanceState(outState)
    }

    /** پشتیبان را می‌سازد و با اشتراک‌گذاری به فضای ابری یا هر برنامهٔ دیگر می‌فرستد. */
    private fun shareBackupToCloud() {
        try {
            val (file, texts) = BackupManager.createShareFile(this)
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            Toast.makeText(this, AppLang.t("پشتیبان آماده شد ($texts متن)؛ مقصد را انتخاب کنید", "Backup ready ($texts texts); choose the destination"), Toast.LENGTH_LONG).show()
            startActivity(Intent.createChooser(send, AppLang.t("ارسال پشتیبان به فضای ابری", "Send backup to the cloud")))
        } catch (e: Exception) {
            Toast.makeText(this, AppLang.t("ساخت پشتیبان ناموفق بود: ${e.message}", "Creating the backup failed: ${e.message}"), Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        com.example.persianfontkeyboard.physical.PhysicalInputHook.unregisterHider(this)

        fontLoadGeneration++
        if (!isChangingConfigurations) AppLang.beforeAutoRestart = null

        draftSaveHandler.removeCallbacks(
            draftSaveRunnable
        )

        if (::topButtonsMode.isInitialized) topButtonsMode.release()

        super.onDestroy()
    }

    private fun timestampedFile(
        prefix: String,
        ext: String
    ): File {

        val dir =
            getExternalFilesDir(null)
                ?: filesDir

        if (!dir.exists()) {
            dir.mkdirs()
        }

        val stamp =
            SimpleDateFormat(
                "yyyyMMdd_HHmmss_SSS",
                Locale.US
            ).format(Date())

        var file =
            File(
                dir,
                "${prefix}_${stamp}.${ext}"
            )

        var counter = 1

        while (file.exists()) {

            file =
                File(
                    dir,
                    "${prefix}_${stamp}_${counter}.${ext}"
                )

            counter++
        }

        return file
    }

    private fun sharePdfOrImage(file: File, mimeType: String) {
        if (mimeType == "application/pdf" || mimeType.startsWith("image/")) {
            com.example.persianfontkeyboard.print.PrintHelper.showShareOrPrint(this, file) { doSharePdfOrImage(file, mimeType) }
        } else {
            doSharePdfOrImage(file, mimeType)
        }
    }

    private fun doSharePdfOrImage(
        file: File,
        mimeType: String
    ) {

        val uri =
            FileProvider.getUriForFile(
                this,
                "$packageName.fileprovider",
                file
            )

        val intent =
            Intent(Intent.ACTION_SEND).apply {

                type = mimeType

                putExtra(
                    Intent.EXTRA_STREAM,
                    uri
                )

                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }

        startActivity(
            Intent.createChooser(
                intent,
                AppLang.t("اشتراک‌گذاری خروجی", "Share output")
            )
        )
    }

    /** پنجرهٔ انتخاب پس‌زمینهٔ خروجی PDF / عکس (با نمایش پیش‌نمایش هر پس‌زمینه). */
    private fun chooseExportBackground(
        prefKey: String = "export_bg",
        onTransparent: (() -> Unit)? = null,
        onChosen: (ExportBg) -> Unit
    ) = TextExportDialogs.chooseBackground(this, prefKey, onTransparent, onChosen)

    private fun exportPdf() = chooseExportBackground { exportPdfWith(it) }

    private fun exportImage() = chooseExportBackground { exportImageWith(it) }

    private fun exportPdfWith(bg: ExportBg) {

        try {

            val text =
                editText.text.toString()

            val file =
                timestampedFile(
                    "text_export",
                    "pdf"
                )

            val density =
                resources.displayMetrics.density

            val sizePx =
                currentTextSizeSp * density

            ExportUtils.exportTextToPdf(
                this,
                text,
                fontTypeface,
                sizePx,
                TextColorManager.getColor(this),
                file,
                bg
            )

            Toast.makeText(
                this,
                AppLang.t("فایل PDF ذخیره شد:\n${file.absolutePath}", "PDF file saved:\n${file.absolutePath}"),
                Toast.LENGTH_LONG
            ).show()

            sharePdfOrImage(
                file,
                "application/pdf"
            )

        } catch (e: Exception) {

            Toast.makeText(
                this,
                AppLang.t("خطا در ساخت PDF: ${e.message}", "Error creating PDF: ${e.message}"),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun exportImageWith(bg: ExportBg) {

        try {

            val text =
                editText.text.toString()

            val file =
                timestampedFile(
                    "text_export",
                    "png"
                )

            val density =
                resources.displayMetrics.density

            val sizePx =
                currentTextSizeSp * density

            ExportUtils.exportTextToImage(
                text,
                fontTypeface,
                sizePx,
                TextColorManager.getColor(this),
                file,
                bg,
                this
            )

            Toast.makeText(
                this,
                AppLang.t("فایل عکس ذخیره شد:\n${file.absolutePath}", "Image file saved:\n${file.absolutePath}"),
                Toast.LENGTH_LONG
            ).show()

            sharePdfOrImage(
                file,
                "image/png"
            )

        } catch (e: Exception) {

            Toast.makeText(
                this,
                AppLang.t("خطا در ساخت عکس: ${e.message}", "Error creating image: ${e.message}"),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** DOCX: اول نوع خروجی (متن قابل ویرایش / عکس صفحه‌ها) پرسیده می‌شود. */
    private fun exportDocx() {
        if (editText.text.toString().isBlank()) {
            Toast.makeText(this, AppLang.t("ابتدا متنی بنویسید", "First write some text"), Toast.LENGTH_SHORT).show()
            return
        }
        TextExportDialogs.chooseDocxMode(
            this,
            onEditable = { exportDocxText() },
            onPicture = { chooseExportBackground(prefKey = "export_bg_docx") { exportDocxImagesWith(it) } }
        )
    }

    private fun exportDocxText() {
        try {
            val file = timestampedFile("text_export", "docx")
            ExportUtils.exportTextToDocx(
                editText.text.toString(),
                ExportUtils.fontFamilyOf(this, currentFontFile),
                currentTextSizeSp,
                TextColorManager.getColor(this),
                file
            )
            Toast.makeText(
                this,
                AppLang.t("فایل DOCX ذخیره شد:\n${file.absolutePath}", "DOCX file saved:\n${file.absolutePath}"),
                Toast.LENGTH_LONG
            ).show()
            sharePdfOrImage(file, DocxWriter.MIME)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                AppLang.t("خطا در ساخت DOCX: ${e.message}", "Error creating DOCX: ${e.message}"),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun exportDocxImagesWith(bg: ExportBg) {
        try {
            val file = timestampedFile("text_export", "docx")
            ExportUtils.exportTextToDocxImages(
                this,
                editText.text.toString(),
                fontTypeface,
                currentTextSizeSp * resources.displayMetrics.density,
                TextColorManager.getColor(this),
                file,
                bg
            )
            Toast.makeText(
                this,
                AppLang.t("فایل DOCX ذخیره شد:\n${file.absolutePath}", "DOCX file saved:\n${file.absolutePath}"),
                Toast.LENGTH_LONG
            ).show()
            sharePdfOrImage(file, DocxWriter.MIME)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                AppLang.t("خطا در ساخت DOCX: ${e.message}", "Error creating DOCX: ${e.message}"),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** «ساخت استیکر (WebP)»: اول پس‌زمینه (شفاف یا تاریخی) انتخاب می‌شود. */
    private fun exportTransparentImage() {
        if (editText.text.toString().isBlank()) {
            Toast.makeText(this, AppLang.t("ابتدا متنی بنویسید", "First write some text"), Toast.LENGTH_SHORT).show()
            return
        }
        chooseExportBackground(
            prefKey = "sticker_bg",
            onTransparent = { exportStickerWith(null) }
        ) { exportStickerWith(it) }
    }

    private fun exportStickerWith(bg: ExportBg?) {

        val text = editText.text.toString()

        if (text.isBlank()) {
            Toast.makeText(
                this,
                AppLang.t("ابتدا متنی بنویسید", "First write some text"),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        try {

            val sizePx =
                currentTextSizeSp * resources.displayMetrics.density

            val color = TextColorManager.getColor(this)

            var bitmap =
                ExportUtils.renderTransparentBitmap(
                    text,
                    fontTypeface,
                    sizePx,
                    color
                )

            if (bg != null) {
                bitmap.recycle()
                bitmap = ExportUtils.renderStickerOnBackground(this, text, fontTypeface, sizePx, color, bg)
            }

            val longest = maxOf(bitmap.width, bitmap.height)
            if (bg == null && longest < 400) {
                val k = 480f / longest
                bitmap.recycle()
                bitmap = ExportUtils.renderTransparentBitmap(
                    text,
                    fontTypeface,
                    sizePx * k,
                    color
                )
            }

            val file = StickerUtils.saveSticker(this, bitmap)
            bitmap.recycle()

            Toast.makeText(
                this,
                AppLang.t("استیکر WebP ذخیره شد:\n${file.absolutePath}", "WebP sticker saved:\n${file.absolutePath}"),
                Toast.LENGTH_LONG
            ).show()

            startActivity(StickerUtils.shareIntent(this, file))

        } catch (e: Exception) {

            Toast.makeText(
                this,
                AppLang.t("خطا در ساخت استیکر: ${e.message}", "Error creating sticker: ${e.message}"),
                Toast.LENGTH_LONG
            ).show()
        }
    }

}
