package com.example.persianfontkeyboard.fontstudio

import org.json.JSONObject

/**
 * مانیفست بستهٔ «استودیو ساخت و ویرایش فونت» (فایل `manifest.json` در ریشهٔ زیپ).
 *
 * نمونه:
 * {
 *   "id": "font-studio",
 *   "applicationId": "irani.script.keyboards",
 *   "versionCode": 1,
 *   "versionName": "1.0.0",
 *   "minAppVersionCode": 1,
 *   "hostApi": 1,
 *   "entry": "web/index.html",
 *   "files": { "web/index.html": "<sha256>", "web/app.js": "<sha256>" }
 * }
 */
class FontStudioManifest(
    val id: String,
    val applicationId: String,
    val versionCode: Int,
    val versionName: String,
    val minAppVersionCode: Int,
    val hostApi: Int,
    /** مسیر صفحهٔ ورودی نسبت به ریشهٔ بسته. */
    val entry: String,
    /** مسیر فایل ← SHA-256 (hex، حروف کوچک). فایل‌هایی که اینجا نیستند نصب نمی‌شوند. */
    val files: Map<String, String>,
    val raw: String
) {
    companion object {
        const val FILE_NAME = "manifest.json"
        const val SIG_NAME = "manifest.sig"
        const val EXPECTED_ID = "font-studio"

        class Invalid(message: String) : Exception(message)

        fun parse(text: String): FontStudioManifest {
            val o = try {
                JSONObject(text.removePrefix("\uFEFF"))
            } catch (e: Exception) {
                throw Invalid("manifest.json معتبر نیست")
            }
            val files = LinkedHashMap<String, String>()
            val fo = o.optJSONObject("files") ?: throw Invalid("فهرست فایل‌ها (files) در مانیفست نیست")
            for (k in fo.keys()) {
                val path = normalize(k) ?: throw Invalid("مسیر نامعتبر در مانیفست: $k")
                val h = fo.optString(k).trim().lowercase()
                if (!Regex("[0-9a-f]{64}").matches(h)) throw Invalid("SHA-256 نامعتبر برای $k")
                files[path] = h
            }
            val entry = normalize(o.optString("entry", "web/index.html")) ?: throw Invalid("مسیر ورودی نامعتبر است")
            if (!files.containsKey(entry)) throw Invalid("صفحهٔ ورودی ($entry) در فهرست فایل‌ها نیست")
            val m = FontStudioManifest(
                id = o.optString("id").trim(),
                applicationId = o.optString("applicationId").trim(),
                versionCode = o.optInt("versionCode", 0),
                versionName = o.optString("versionName", "").trim(),
                minAppVersionCode = o.optInt("minAppVersionCode", 0),
                hostApi = o.optInt("hostApi", 1),
                entry = entry,
                files = files,
                raw = text
            )
            if (m.id != EXPECTED_ID) throw Invalid("این بسته مربوط به استودیو فونت نیست")
            if (m.versionCode <= 0) throw Invalid("شمارهٔ نسخهٔ بسته نامعتبر است")
            return m
        }

        /** مسیر نسبی امن: بدون `..`، بدون مسیر مطلق، بدون بک‌اسلش. */
        fun normalize(p: String): String? {
            var s = p.trim().replace('\\', '/')
            while (s.startsWith("./")) s = s.substring(2)
            if (s.isEmpty() || s.startsWith("/") || s.contains(':')) return null
            val parts = s.split('/')
            if (parts.any { it.isEmpty() || it == "." || it == ".." }) return null
            return parts.joinToString("/")
        }
    }
}
