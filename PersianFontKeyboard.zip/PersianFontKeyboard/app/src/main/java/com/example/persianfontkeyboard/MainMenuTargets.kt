package com.example.persianfontkeyboard

private val GROUP_MAIN: String get() = AppLang.t("صفحهٔ اصلی", "Main page")
private val GROUP_SECTIONS: String get() = AppLang.t("بخش‌های اصلی برنامه", "Main sections of the app")
private val GROUP_TOOLS: String get() = AppLang.t("ابزارها و آموزش", "Tools and learning")
private val GROUP_MEDIA: String get() = AppLang.t("زیرنویس و عکس", "Subtitles and photos")
private val GROUP_INFO: String get() = AppLang.t("اطلاعات و بروزرسانی", "Info and updates")

/**
 * جاهایی از برنامه که کاربر می‌تواند «ظاهر منو اصلی» (فونت، رنگ، افکت، سایه، جعبه، حرکت و …) را
 * علاوه بر خود منو روی آن‌ها هم اعمال کند. پیش‌فرض: هیچ‌کدام (فقط منو اصلی).
 *
 * انتخاب هر مورد در [MainMenuConfig.targets] ذخیره می‌شود؛ یعنی برای «منو اصلی ثابت» و
 * «منو اصلی متحرک» جدا از هم نگه داشته می‌شود و فقط وقتی اثر دارد که همان نوع منو فعال باشد.
 */
enum class MenuTarget(val key: String, val title: String, val group: String) {
    // ---- صفحهٔ اصلی ----
    TEXT_FRAME("text_frame", AppLang.t("کادر متن صفحهٔ اصلی (بالای برنامه)", "Main page text box (top of the app)"), GROUP_MAIN),

    SHORTCUT_BAR("shortcut_bar", AppLang.t("نوار میانبرها و دکمه‌های بالای صفحه (در سبک متن / هر دو)", "Shortcut bar and top page buttons (in text / both style)"), GROUP_MAIN),
    SHORTCUT_SETTINGS("shortcut_settings", AppLang.t("تنظیمات میانبرها", "Shortcut settings"), GROUP_MAIN),
    WELCOME("welcome", AppLang.t("نام من و خوش‌آمدگویی (پنجرهٔ تنظیمات)", "My name and welcome (settings window)"), GROUP_MAIN),

    // ---- بخش‌های اصلی برنامه (همهٔ آیتم‌ها و پنجره‌های درون هر بخش) ----
    TEXT_SETTINGS("text_settings", AppLang.t("تنظیمات متن (همهٔ آیتم‌های درون آن)", "Text settings (all items inside it)"), GROUP_SECTIONS),
    SWIPE_TYPING("swipe_typing", AppLang.t("تایپ کشیدنی (تنظیمات و آیتم‌های درون آن)", "Swipe typing (settings and items inside it)"), GROUP_SECTIONS),
    SPEAKING_APP("speaking_app", AppLang.t("اپلیکیشن سخنگو (TalkBack)", "Talking app (TalkBack)"), GROUP_SECTIONS),
    HANDWRITING("handwriting", AppLang.t("واژه با دست‌خط (همهٔ صفحه‌ها و پنجره‌ها)", "Word in handwriting (all pages and windows)"), GROUP_SECTIONS),
    DICTIONARY("dictionary", AppLang.t("فرهنگ واژگان (همهٔ صفحه‌ها و پنجره‌ها)", "Dictionary (all pages and windows)"), GROUP_SECTIONS),
    FREE_DESIGN_UI("free_design_ui", AppLang.t("طراحی آزاد (کل صفحه، گالری و پنجره‌ها)", "Free Design (whole page, gallery and windows)"), GROUP_SECTIONS),
    SAVED_TEXTS("saved_texts", AppLang.t("متن‌های ذخیره‌شده", "Saved texts"), GROUP_SECTIONS),
    SUBTITLE_CREATE("subtitle_create", AppLang.t("ایجاد زیرنویس فیلم (همهٔ آیتم‌ها، کتابخانه و زیرنویس خودکار)", "Add subtitles to video (all items, library and auto subtitles)"), GROUP_SECTIONS),
    FONT_MANAGER("font_manager", AppLang.t("افزودن و انتخاب فونت", "Add and choose font"), GROUP_SECTIONS),
    FONT_STUDIO("font_studio", AppLang.t("استودیو ساخت و ویرایش فونت (صفحهٔ مدیریت و پنجره‌ها)", "Font Creation & Editing Studio (manager page and windows)"), GROUP_SECTIONS),
    THEME_PICKER("theme_picker", AppLang.t("انتخاب تم اپلیکیشن (پنجرهٔ تم و تنظیمات تم متحرک / چندرسانه‌ای)", "Choose app theme (theme window and animated / multimedia theme settings)"), GROUP_SECTIONS),
    MAIN_MENU_SETTINGS("main_menu_settings", AppLang.t("تنظیمات منو اصلی (همین پنجره)", "Main menu settings (this window)"), GROUP_SECTIONS),
    APP_ICON("app_icon", AppLang.t("آیکون اپلیکیشن (انتخاب آیکون)", "App icon (choose an icon)"), GROUP_SECTIONS),
    SECURITY("security", AppLang.t("سامانه امنیتی (قفل برنامه)", "Security system (app lock)"), GROUP_SECTIONS),

    // ---- ابزارها و آموزش ----
    FREE_DESIGN_TEXT("free_design_text", AppLang.t("متن مستقل در طراحی آزاد", "Standalone text in Free Design"), GROUP_TOOLS),
    SCRIPT_CONVERTER("script_converter", AppLang.t("تبدیل متن به دبیره‌های باستانی", "Convert text to ancient scripts"), GROUP_TOOLS),
    QR_CODE("qr_code", AppLang.t("متن به QR Code و برعکس", "Text ⇄ QR Code"), GROUP_TOOLS),
    ALPHABET_TABLE("alphabet_table", AppLang.t("جدول آموزشی دبیره‌ها", "Script learning table"), GROUP_TOOLS),
    COMPARE_SCRIPTS("compare_scripts", AppLang.t("مقایسهٔ دبیره‌ها", "Compare scripts"), GROUP_TOOLS),
    DAILY_WORD("daily_word", AppLang.t("واژهٔ روز", "Word of the day"), GROUP_TOOLS),
    HOME_WIDGET("home_widget", AppLang.t("ویجت صفحه اصلی", "Home screen widget"), GROUP_TOOLS),
    QUIZ("quiz", AppLang.t("کوییز و تمرین دبیره‌ها", "Quiz and script practice"), GROUP_TOOLS),
    REVIEW_CARDS("review_cards", AppLang.t("کارت‌های مرور واژگان", "Vocabulary review cards"), GROUP_TOOLS),
    WORD_GAME("word_game", AppLang.t("بازی واژگان", "Word game"), GROUP_TOOLS),
    PRINT_SYSTEM("print_system", AppLang.t("سامانه چاپگری", "Printing system"), GROUP_TOOLS),
    STYLUS_SYSTEM("stylus_system", AppLang.t("سامانه قلم نوری (Stylus / S-Pen)", "Stylus system (S-Pen)"), GROUP_TOOLS),

    // ---- زیرنویس و عکس ----
    SUBTITLE_LOOK("subtitle_look", AppLang.t("ظاهر زیرنویس (در ایجاد زیرنویس فیلم)", "Subtitle look (in Add subtitles to video)"), GROUP_MEDIA),
    WRITE_ON_IMAGE("write_on_image", AppLang.t("نوشتن روی عکس", "Write on image"), GROUP_MEDIA),

    // ---- اطلاعات و بروزرسانی ----
    WEB_VERSION("web_version", AppLang.t("نسخه وب اپلیکیشن", "Web version of the app"), GROUP_INFO),
    WEBSITE("website", AppLang.t("سازندگان و مخلفات", "Creators and credits"), GROUP_INFO),
    ABOUT_APP("about_app", AppLang.t("درباره اپلیکیشن", "About the app"), GROUP_INFO),
    UPDATE("update", AppLang.t("استعلام نسخه جدید", "Check for a new version"), GROUP_INFO),
    CHANGELOG("changelog", AppLang.t("تغییرات نسخه", "Version changes"), GROUP_INFO),
    ONBOARDING("onboarding", AppLang.t("تور آموزشی اولیه", "Intro tour"), GROUP_INFO),
    ABOUT_DEV("about_dev", AppLang.t("اطلاعات سازنده و نرم‌افزار", "Developer and software info"), GROUP_INFO),
    FEEDBACK("feedback", AppLang.t("انتقادات و پیشنهادات", "Feedback and suggestions"), GROUP_INFO);

    companion object {
        fun fromKey(key: String): MenuTarget? = values().firstOrNull { it.key == key }

        /** گروه‌ها به ترتیب نمایش. */
        fun groups(): List<String> = values().map { it.group }.distinct()

        fun inGroup(group: String): List<MenuTarget> = values().filter { it.group == group }

        /**
         * محل‌هایی که یک «صفحهٔ کامل» (Activity) هستند و با [MainMenuApply.attach] ثبت می‌شوند؛ لایهٔ تم متحرک /
         * چندرسانه‌ای فقط روی همین‌ها (نه پنجره‌ها) بر اساس «اولویت در تداخل» ([MenuLookPolicy]) خاموش می‌شود.
         */
        val SCREEN_LEVEL: Set<MenuTarget> by lazy {
            setOf(
                SCRIPT_CONVERTER, QR_CODE, ALPHABET_TABLE, COMPARE_SCRIPTS, DAILY_WORD, HOME_WIDGET, QUIZ, REVIEW_CARDS, WORD_GAME,
                PRINT_SYSTEM, STYLUS_SYSTEM, WRITE_ON_IMAGE, ONBOARDING, SECURITY, HANDWRITING, DICTIONARY, FREE_DESIGN_UI, SAVED_TEXTS,
                SUBTITLE_CREATE, FONT_MANAGER, FONT_STUDIO, APP_ICON
            )
        }

        /** فقط کلیدهای معتبر را نگه می‌دارد (برای سازگاری با نسخه‌های بعدی/قبلی). */
        fun sanitize(keys: Set<String>): Set<String> {
            val valid = values().map { it.key }.toSet()
            return keys.filterTo(HashSet()) { it in valid }
        }
    }
}
