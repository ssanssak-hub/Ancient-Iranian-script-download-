package com.example.persianfontkeyboard.fontstudio

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import com.example.persianfontkeyboard.AppLang
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/**
 * دانلود بستهٔ استودیو از مخزن عمومی (فقط خواندن):
 *   https://github.com/ssanssak-hub/Ancient-Iranian-script-download-/tree/main/createfonts
 *
 * در آن پوشه دو فایل هست:
 *  • font-studio.zip         : خود بسته (همان فایلی که کاربر دانلود می‌کند)
 *  • fontstudio.meta.json    : اطلاعات نسخه برای اپلیکیشن:
 *      { "version": 3, "versionName": "1.1.0", "sha256": "...", "size": 123456, "zip": "font-studio.zip",
 *        "minAppVersionCode": 1, "releasedAt": "2026-11-26", "notes": "…فارسی…", "notesEn": "…English…" }
 *
 * «بررسی نسخه» فقط meta را می‌خواند. دانلود با نوار پیشرفت، قابل لغو، با بررسی فضای خالی و SHA-256،
 * و اگر آدرس اصلی در دسترس نبود با آینه‌های جایگزین تلاش می‌کند.
 */
object FontStudioRemote {

    /** به ترتیب امتحان می‌شوند. آینه‌ها (کش CDN) ممکن است چند دقیقه عقب باشند؛ تطبیق SHA-256 جلوی نسخهٔ ناهماهنگ را می‌گیرد. */
    val BASES = listOf(
        "https://raw.githubusercontent.com/ssanssak-hub/Ancient-Iranian-script-download-/main/createfonts/",
        "https://github.com/ssanssak-hub/Ancient-Iranian-script-download-/raw/main/createfonts/",
        "https://cdn.jsdelivr.net/gh/ssanssak-hub/Ancient-Iranian-script-download-@main/createfonts/"
    )
    const val REPO_PAGE = "https://github.com/ssanssak-hub/Ancient-Iranian-script-download-/tree/main/createfonts"
    const val META_NAME = "fontstudio.meta.json"
    const val DEFAULT_ZIP = "font-studio.zip"

    private const val MAX_META_BYTES = 32 * 1024
    private const val MAX_ZIP_BYTES = 400L * 1024 * 1024

    @Volatile private var activeBase = 0

    class FetchException(message: String) : Exception(message)

    class Meta(
        val version: Int,
        val versionName: String,
        val sha256: String,
        val size: Long,
        val zip: String,
        val minAppVersionCode: Int,
        val releasedAt: String,
        val notesFa: String,
        val notesEn: String
    ) {
        /** یادداشت نسخه به زبان اپلیکیشن. */
        val notes: String get() = AppLang.t(notesFa.ifBlank { notesEn }, notesEn.ifBlank { notesFa })
    }

    enum class Kind { NOT_INSTALLED, NEW_VERSION, UP_TO_DATE, REMOTE_OLDER }

    class Outcome(val kind: Kind, val meta: Meta) {
        val hasNewer: Boolean get() = kind == Kind.NEW_VERSION || kind == Kind.NOT_INSTALLED
    }

    /** برای لغو دانلود از نخ اصلی. */
    class Cancel { val flag = AtomicBoolean(false); fun cancel() = flag.set(true) }

    fun interface DownloadProgress { fun update(done: Long, total: Long) }

    private fun open(base: String, name: String): HttpURLConnection {
        val url = URL(base + name + "?t=" + System.currentTimeMillis())
        return (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 20_000
            requestMethod = "GET"
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "DabirehIrani-FontStudio")
            setRequestProperty("Cache-Control", "no-cache")
        }
    }

    private fun networkError() = FetchException(
        AppLang.t("اتصال به مخزن برقرار نشد. اینترنت خود را بررسی کنید.", "Couldn't connect to the repository. Check your internet.")
    )

    /** آدرس‌ها با شروع از آخرین آدرس موفق. */
    private fun orderedBases(): List<String> {
        val i = activeBase.coerceIn(0, BASES.size - 1)
        return listOf(BASES[i]) + BASES.filterIndexed { k, _ -> k != i }
    }

    private fun parseMeta(bytes: ByteArray): Meta {
        if (bytes.size > MAX_META_BYTES) throw FetchException(AppLang.t("فهرست نسخه بیش از حد بزرگ است.", "The version index is too large."))
        val o = JSONObject(bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF"))
        val v = o.optInt("version", 0)
        if (v <= 0) throw FetchException(AppLang.t("فهرست نسخهٔ مخزن معتبر نیست.", "The repository version index is invalid."))
        val zip = o.optString("zip", DEFAULT_ZIP).trim()
        // فقط نام ساده؛ مسیر یا آدرس دیگر پذیرفته نمی‌شود (دانلود فقط از همین پوشهٔ مخزن)
        if (!Regex("[A-Za-z0-9._-]{1,80}\\.zip").matches(zip)) throw FetchException(AppLang.t("نام فایل بسته معتبر نیست.", "The package file name is invalid."))
        return Meta(
            version = v,
            versionName = o.optString("versionName", ""),
            sha256 = o.optString("sha256").trim().lowercase(),
            size = o.optLong("size", 0L),
            zip = zip,
            minAppVersionCode = o.optInt("minAppVersionCode", 0),
            releasedAt = o.optString("releasedAt", ""),
            notesFa = o.optString("notes", ""),
            notesEn = o.optString("notesEn", "")
        )
    }

    /** روی نخ پس‌زمینه. */
    fun fetchMeta(ctx: Context): Meta {
        var notFound = false
        for (base in orderedBases()) {
            var conn: HttpURLConnection? = null
            try {
                conn = open(base, META_NAME)
                val code = conn.responseCode
                if (code == 404) { notFound = true; continue }
                if (code !in 200..299) continue
                val meta = parseMeta(conn.inputStream.use { it.readBytes() })
                activeBase = BASES.indexOf(base).coerceAtLeast(0)
                FontStudioStore.rememberRemote(ctx, meta)
                return meta
            } catch (e: FetchException) {
                throw e
            } catch (_: Exception) {
                // آدرس بعدی
            } finally {
                conn?.disconnect()
            }
        }
        if (notFound) throw FetchException(AppLang.t("استودیو هنوز در مخزن منتشر نشده است.", "The studio hasn't been published in the repository yet."))
        throw networkError()
    }

    fun check(ctx: Context): Outcome {
        val meta = fetchMeta(ctx)
        val local = FontStudioStore.installedVersionCode(ctx)
        val kind = when {
            !FontStudioStore.isInstalled(ctx) -> Kind.NOT_INSTALLED
            meta.version > local -> Kind.NEW_VERSION
            meta.version < local -> Kind.REMOTE_OLDER
            else -> Kind.UP_TO_DATE
        }
        return Outcome(kind, meta)
    }

    private fun freeBytes(ctx: Context): Long = try { StatFs(ctx.filesDir.absolutePath).availableBytes } catch (_: Exception) { Long.MAX_VALUE }

    /**
     * بسته را دانلود، با SHA-256 مقایسه و نصب می‌کند. روی نخ پس‌زمینه صدا بزنید.
     * فایل دانلودشده در cache می‌ماند فقط تا پایان نصب.
     */
    fun downloadAndInstall(
        ctx: Context,
        cancel: Cancel,
        onDownload: DownloadProgress,
        onExtract: FontStudioInstaller.Progress
    ): FontStudioInstaller.Result {
        val meta = fetchMeta(ctx)
        if (meta.minAppVersionCode > com.example.persianfontkeyboard.BuildConfig.VERSION_CODE) {
            throw FetchException(AppLang.t(
                "این نسخهٔ استودیو به نسخهٔ جدیدتری از اپلیکیشن نیاز دارد. ابتدا اپلیکیشن را بروزرسانی کنید.",
                "This studio version needs a newer version of the app. Please update the app first."
            ))
        }
        if (meta.size > 0 && freeBytes(ctx) < meta.size * 4 + 20L * 1024 * 1024) {
            throw FetchException(AppLang.t("فضای خالی گوشی برای دانلود و نصب کافی نیست.", "Not enough free storage to download and install."))
        }
        val tmp = File(FontStudioStore.ioDir(ctx), "font-studio-download.zip")
        var lastError: Exception = networkError()
        for (base in orderedBases()) {
            tmp.delete()
            var conn: HttpURLConnection? = null
            try {
                conn = open(base, meta.zip)
                val code = conn.responseCode
                if (code !in 200..299) { lastError = FetchException(AppLang.t("فایل بسته در این آدرس پیدا نشد (کد $code).", "The package file wasn't found at this address (code $code).")); continue }
                val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else meta.size
                val md = MessageDigest.getInstance("SHA-256")
                var done = 0L
                conn.inputStream.use { input ->
                    FileOutputStream(tmp).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            if (cancel.flag.get()) throw FetchException(AppLang.t("دانلود لغو شد.", "Download cancelled."))
                            val n = input.read(buf)
                            if (n < 0) break
                            done += n
                            if (done > MAX_ZIP_BYTES) throw FetchException(AppLang.t("فایل دریافتی بیش از حد بزرگ است.", "The received file is too large."))
                            md.update(buf, 0, n)
                            out.write(buf, 0, n)
                            onDownload.update(done, total)
                        }
                    }
                }
                val got = md.digest().joinToString("") { String.format("%02x", it) }
                if (meta.sha256.isNotEmpty() && got != meta.sha256) {
                    lastError = FetchException(AppLang.t(
                        "فایل دریافتی با فهرست نسخه هم‌خوان نیست (شاید در حال انتشار یا کش آینه است). چند دقیقهٔ دیگر دوباره تلاش کنید.",
                        "The received file doesn't match the version index (it may be being published or cached). Try again in a few minutes."
                    ))
                    continue
                }
                activeBase = BASES.indexOf(base).coerceAtLeast(0)
                return FontStudioInstaller.installFromFile(ctx, tmp, onExtract)
            } catch (e: FetchException) {
                if (cancel.flag.get()) throw e
                lastError = e
            } catch (e: FontStudioInstaller.InstallException) {
                throw e
            } catch (e: Exception) {
                lastError = networkError()
            } finally {
                conn?.disconnect()
                tmp.delete()
            }
        }
        throw lastError
    }

    /** [work] روی نخ پس‌زمینه اجرا و نتیجه روی نخ اصلی تحویل می‌شود. */
    fun <T> async(work: () -> T, done: (Result<T>) -> Unit) {
        Thread {
            val r = try { Result.success(work()) } catch (e: Exception) { Result.failure(e) }
            Handler(Looper.getMainLooper()).post { done(r) }
        }.start()
    }
}
