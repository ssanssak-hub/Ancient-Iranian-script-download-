package com.example.persianfontkeyboard.fontstudio

import android.content.Context
import java.io.File

/**
 * مسیرها و وضعیت نصب «استودیو ساخت و ویرایش فونت».
 *
 *  files/fontstudio/pkg/<versionCode>/   ← فایل‌های بستهٔ نصب‌شده (فقط‌خواندنی برای صفحهٔ استودیو)
 *  files/fontstudio/staging/             ← استخراج موقت (بعد از موفقیت جابه‌جا می‌شود)
 *  files/fontstudio/workspace/           ← فضای کار کاربر (پروژه‌ها، بازیابی خودکار) — با حذف استودیو پاک نمی‌شود
 *  cache/fontstudio_io/                  ← فایل‌های رد و بدل شده بین صفحهٔ استودیو و گوشی (موقت)
 */
object FontStudioStore {

    private const val PREFS = "font_studio_prefs"
    private const val KEY_VERSION_CODE = "installed_version_code"
    private const val KEY_VERSION_NAME = "installed_version_name"
    private const val KEY_SIGNED = "installed_signed"
    private const val KEY_DIRECT_OPEN = "direct_open"
    private const val KEY_AUTO_CHECK = "auto_check"
    private const val KEY_LAST_REMOTE = "last_remote_version"
    private const val KEY_REMOTE_NAME = "last_remote_name"
    private const val KEY_REMOTE_SIZE = "last_remote_size"
    private const val KEY_REMOTE_DATE = "last_remote_date"
    private const val KEY_REMOTE_NOTES_FA = "last_remote_notes_fa"
    private const val KEY_REMOTE_NOTES_EN = "last_remote_notes_en"
    private const val KEY_CHECKED_AT = "last_checked_at"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun root(c: Context): File = File(c.filesDir, "fontstudio").apply { mkdirs() }
    fun pkgRoot(c: Context): File = File(root(c), "pkg").apply { mkdirs() }
    fun stagingDir(c: Context): File = File(root(c), "staging")
    fun workspace(c: Context): File = File(root(c), "workspace").apply { mkdirs() }
    fun ioDir(c: Context): File = File(c.cacheDir, "fontstudio_io").apply { mkdirs() }

    fun installedVersionCode(c: Context): Int = prefs(c).getInt(KEY_VERSION_CODE, 0)
    fun installedVersionName(c: Context): String = prefs(c).getString(KEY_VERSION_NAME, "") ?: ""
    fun installedSigned(c: Context): Boolean = prefs(c).getBoolean(KEY_SIGNED, false)

    /** پوشهٔ نسخهٔ نصب‌شدهٔ فعلی؛ اگر نصب نیست یا خراب است null. */
    fun currentDir(c: Context): File? {
        val code = installedVersionCode(c)
        if (code <= 0) return null
        val dir = File(pkgRoot(c), code.toString())
        return if (File(dir, FontStudioManifest.FILE_NAME).isFile) dir else null
    }

    fun currentManifest(c: Context): FontStudioManifest? = try {
        currentDir(c)?.let { FontStudioManifest.parse(File(it, FontStudioManifest.FILE_NAME).readText()) }
    } catch (_: Exception) {
        null
    }

    /** آیا استودیو دانلود/نصب شده و آمادهٔ اجراست؟ */
    fun isInstalled(c: Context): Boolean {
        val m = currentManifest(c) ?: return false
        return File(currentDir(c)!!, m.entry).isFile
    }

    fun markInstalled(c: Context, m: FontStudioManifest, signed: Boolean) {
        prefs(c).edit()
            .putInt(KEY_VERSION_CODE, m.versionCode)
            .putString(KEY_VERSION_NAME, m.versionName)
            .putBoolean(KEY_SIGNED, signed)
            .apply()
    }

    fun clearInstalled(c: Context) {
        prefs(c).edit().remove(KEY_VERSION_CODE).remove(KEY_VERSION_NAME).remove(KEY_SIGNED).apply()
    }

    /** حذف همهٔ فایل‌های بسته (فضای کار کاربر دست‌نخورده می‌ماند). */
    fun uninstall(c: Context) {
        clearInstalled(c)
        pkgRoot(c).deleteRecursively()
        stagingDir(c).deleteRecursively()
        ioDir(c).deleteRecursively()
    }


    fun directOpen(c: Context): Boolean = prefs(c).getBoolean(KEY_DIRECT_OPEN, true)
    fun setDirectOpen(c: Context, on: Boolean) = prefs(c).edit().putBoolean(KEY_DIRECT_OPEN, on).apply()

    fun autoCheck(c: Context): Boolean = prefs(c).getBoolean(KEY_AUTO_CHECK, false)
    fun setAutoCheck(c: Context, on: Boolean) = prefs(c).edit().putBoolean(KEY_AUTO_CHECK, on).apply()

    fun lastRemoteVersion(c: Context): Int = prefs(c).getInt(KEY_LAST_REMOTE, 0)
    fun rememberRemoteVersion(c: Context, v: Int) = prefs(c).edit().putInt(KEY_LAST_REMOTE, v).apply()

    /** اطلاعات آخرین نسخهٔ مخزن (برای نمایش بدون اینترنت). */
    fun rememberRemote(c: Context, m: FontStudioRemote.Meta) {
        prefs(c).edit()
            .putInt(KEY_LAST_REMOTE, m.version).putString(KEY_REMOTE_NAME, m.versionName).putLong(KEY_REMOTE_SIZE, m.size)
            .putString(KEY_REMOTE_DATE, m.releasedAt).putString(KEY_REMOTE_NOTES_FA, m.notesFa).putString(KEY_REMOTE_NOTES_EN, m.notesEn)
            .putLong(KEY_CHECKED_AT, System.currentTimeMillis()).apply()
    }
    fun remoteName(c: Context): String = prefs(c).getString(KEY_REMOTE_NAME, "") ?: ""
    fun remoteSize(c: Context): Long = prefs(c).getLong(KEY_REMOTE_SIZE, 0L)
    fun remoteDate(c: Context): String = prefs(c).getString(KEY_REMOTE_DATE, "") ?: ""
    fun remoteNotesFa(c: Context): String = prefs(c).getString(KEY_REMOTE_NOTES_FA, "") ?: ""
    fun remoteNotesEn(c: Context): String = prefs(c).getString(KEY_REMOTE_NOTES_EN, "") ?: ""
    fun lastCheckedAt(c: Context): Long = prefs(c).getLong(KEY_CHECKED_AT, 0L)
}
