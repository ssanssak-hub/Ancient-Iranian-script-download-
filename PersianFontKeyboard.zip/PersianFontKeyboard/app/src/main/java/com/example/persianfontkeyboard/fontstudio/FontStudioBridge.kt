package com.example.persianfontkeyboard.fontstudio

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.persianfontkeyboard.AppLang
import com.example.persianfontkeyboard.BuildConfig
import com.example.persianfontkeyboard.FontManager
import com.example.persianfontkeyboard.R
import com.example.persianfontkeyboard.ThemeManager
import com.example.persianfontkeyboard.TextColorManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * پلِ بین صفحهٔ استودیو (WebView) و برنامه. فقط همین کلاس به جاوااسکریپت داده می‌شود
 * (`window.AndroidStudio`)؛ استودیو معمولاً از پوشش Promise‌ـدار `/__host/host.js` استفاده می‌کند.
 *
 * اصول امنیتی:
 *  • هیچ مسیری از حافظهٔ گوشی مستقیم داده نمی‌شود؛ فایل‌ها فقط از راه انتخاب‌گر/ذخیره‌گر سیستم (SAF) می‌آیند و می‌روند.
 *  • فضای کار (workspace) فقط داخل پوشهٔ خصوصی برنامه است و سهمیه دارد.
 *  • فونت‌های رمزنگاری‌شدهٔ دانلودی (SecureFontStore) هرگز به استودیو داده نمی‌شوند.
 *  • openExternal فقط https باز می‌کند.
 */
class FontStudioBridge(private val host: Host) {

    interface Host {
        val ctx: Context
        /** Context صفحه (Activity) برای خواندن رنگ‌های تم؛ Context برنامه تم را ندارد. */
        val themeCtx: Context
        fun emit(msg: JSONObject)
        fun runOnUi(r: Runnable)
        fun launchPick(reqId: String, accept: List<String>, multiple: Boolean)
        fun launchSave(reqId: String, file: File, name: String, mime: String)
        fun requestClose()
        fun openManager()
        fun setKeepScreenOn(on: Boolean)
        fun setOrientation(mode: String)
        fun setUnsaved(on: Boolean)
        fun launchInfo(): JSONObject
    }

    companion object {
        /** نسخهٔ رابط میزبان؛ بستهٔ استودیو در مانیفست `hostApi` را می‌گوید. */
        const val API_VERSION = 1
        const val ORIGIN = "https://appassets.androidplatform.net"
        const val PREFIX_STUDIO = "/studio/"
        const val PREFIX_IO = "/__io/"
        const val PREFIX_WS = "/__ws/"
        const val PREFIX_HOST = "/__host/"

        private const val MAX_STAGE_BYTES = 400L * 1024 * 1024
        private const val MAX_IN_BYTES = 400L * 1024 * 1024
        private const val WS_QUOTA = 1024L * 1024 * 1024
        private const val MAX_TEXT_BYTES = 4L * 1024 * 1024
        private val ID_RE = Regex("[A-Za-z0-9_-]{1,64}")
    }

    private val ctx: Context get() = host.ctx
    private val pool = Executors.newFixedThreadPool(2)
    private val stages = ConcurrentHashMap<String, StageState>()

    private class StageState(val file: File) { var nextIndex = 0; var size = 0L }

    fun shutdown() { pool.shutdownNow() }

    // =====================================================================
    // اطلاعات میزبان
    // =====================================================================

    @JavascriptInterface
    fun hostInfo(): String {
        val c = ctx
        val o = JSONObject()
        o.put("apiVersion", API_VERSION)
        o.put("appId", BuildConfig.APPLICATION_ID)
        o.put("appVersionName", BuildConfig.VERSION_NAME)
        o.put("appVersionCode", BuildConfig.VERSION_CODE)
        o.put("androidSdk", Build.VERSION.SDK_INT)
        o.put("lang", AppLang.code)
        o.put("rtl", AppLang.code == AppLang.FA)
        o.put("dark", ThemeManager.isDark(c))
        o.put("density", c.resources.displayMetrics.density.toDouble())
        o.put("packageVersionCode", FontStudioStore.installedVersionCode(c))
        o.put("packageVersionName", FontStudioStore.installedVersionName(c))
        o.put("packageSigned", FontStudioStore.installedSigned(c))
        o.put("wsQuotaBytes", WS_QUOTA)
        o.put("maxFileBytes", MAX_STAGE_BYTES)
        o.put("colors", JSONObject().apply {
            put("background", hex(ThemeManager.themeColor(host.themeCtx, R.attr.appBackground)))
            put("toolbar", hex(ThemeManager.themeColor(host.themeCtx, R.attr.appToolbar)))
            put("toolbarText", hex(ThemeManager.themeColor(host.themeCtx, R.attr.appToolbarText)))
            put("text", hex(TextColorManager.getColor(c)))
        })
        o.put("launch", host.launchInfo())
        return o.toString()
    }

    private fun hex(color: Int): String = String.format("#%06X", 0xFFFFFF and color)

    // =====================================================================
    // انتخاب فایل از گوشی  → رویداد filesPicked
    // =====================================================================

    @JavascriptInterface
    fun pickFiles(reqId: String, acceptJson: String, multiple: Boolean) {
        if (!validReq(reqId)) return
        val accept = ArrayList<String>()
        try {
            val a = JSONArray(acceptJson)
            for (i in 0 until a.length()) accept += a.optString(i)
        } catch (_: Exception) { }
        host.runOnUi(Runnable { host.launchPick(reqId, accept, multiple) })
    }

    /** از میزبان صدا زده می‌شود وقتی کاربر فایل‌ها را انتخاب کرد (uris خالی = لغو). */
    fun onPicked(reqId: String, uris: List<Uri>) {
        pool.execute {
            val arr = JSONArray()
            var error: String? = null
            try {
                for (u in uris) copyPicked(u)?.let { arr.put(it) }
            } catch (e: Exception) {
                error = e.message ?: "pick failed"
            }
            val m = JSONObject().put("type", "filesPicked").put("reqId", reqId).put("files", arr)
            if (error != null) m.put("error", error)
            host.emit(m)
        }
    }

    private fun copyPicked(uri: Uri): JSONObject? {
        val name = safeName(FontManager.queryDisplayName(ctx, uri) ?: "file")
        val id = UUID.randomUUID().toString().replace("-", "").take(16)
        val dir = File(FontStudioStore.ioDir(ctx), "in/$id").apply { mkdirs() }
        val out = File(dir, name)
        var size = 0L
        val input = ctx.contentResolver.openInputStream(uri) ?: return null
        input.use { ins ->
            FileOutputStream(out).use { fo ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    size += n
                    if (size > MAX_IN_BYTES) {
                        out.delete()
                        throw IllegalStateException(AppLang.t("حجم فایل بیش از حد مجاز است.", "The file is larger than allowed."))
                    }
                    fo.write(buf, 0, n)
                }
            }
        }
        return JSONObject()
            .put("id", id)
            .put("name", name)
            .put("size", size)
            .put("mime", ctx.contentResolver.getType(uri) ?: "")
            .put("url", ORIGIN + PREFIX_IO + "in/$id/" + Uri.encode(name))
    }

    // =====================================================================
    // مرحله‌بندی بایت‌ها (JS ← گوشی) با تکه‌های Base64
    // =====================================================================

    @JavascriptInterface
    fun stageBegin(stageId: String): Boolean {
        if (!ID_RE.matches(stageId)) return false
        val f = File(FontStudioStore.ioDir(ctx), "stage/$stageId")
        f.parentFile?.mkdirs()
        f.delete()
        stages[stageId] = StageState(f)
        return try { f.createNewFile() } catch (_: Exception) { false }
    }

    @JavascriptInterface
    fun stageChunk(stageId: String, index: Int, base64: String): Boolean {
        val st = stages[stageId] ?: return false
        if (index != st.nextIndex) return false
        return try {
            val bytes = Base64.decode(base64, Base64.NO_WRAP)
            st.size += bytes.size
            if (st.size > MAX_STAGE_BYTES) { stages.remove(stageId); st.file.delete(); return false }
            FileOutputStream(st.file, true).use { it.write(bytes) }
            st.nextIndex++
            true
        } catch (_: Exception) {
            false
        }
    }

    /** نتیجه: {"ok":true,"size":N,"url":"…"} */
    @JavascriptInterface
    fun stageEnd(stageId: String): String {
        val st = stages[stageId] ?: return JSONObject().put("ok", false).toString()
        return JSONObject()
            .put("ok", st.file.isFile)
            .put("size", st.file.length())
            .put("url", ORIGIN + PREFIX_IO + "stage/$stageId")
            .toString()
    }

    @JavascriptInterface
    fun stageDiscard(stageId: String) {
        stages.remove(stageId)?.file?.delete()
    }

    private fun stageFile(stageId: String): File? =
        if (ID_RE.matches(stageId)) stages[stageId]?.file?.takeIf { it.isFile } else null

    // =====================================================================
    // خروجی گرفتن: ذخیره در حافظه (SAF) و اشتراک‌گذاری
    // =====================================================================

    @JavascriptInterface
    fun saveStaged(reqId: String, stageId: String, suggestedName: String, mime: String) {
        if (!validReq(reqId)) return
        val f = stageFile(stageId)
        if (f == null) {
            host.emit(JSONObject().put("type", "saveDone").put("reqId", reqId).put("error", "stage not found"))
            return
        }
        val name = safeName(suggestedName)
        host.runOnUi(Runnable { host.launchSave(reqId, f, name, mime.ifBlank { "application/octet-stream" }) })
    }

    @JavascriptInterface
    fun shareStaged(stageId: String, fileName: String, mime: String): Boolean {
        val f = stageFile(stageId) ?: return false
        return try {
            val dir = File(FontStudioStore.ioDir(ctx), "share").apply { deleteRecursively(); mkdirs() }
            val out = File(dir, safeName(fileName))
            f.copyTo(out, overwrite = true)
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", out)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime.ifBlank { "application/octet-stream" }
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(send, AppLang.t("اشتراک‌گذاری", "Share")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            host.runOnUi(Runnable { ctx.startActivity(chooser) })
            true
        } catch (_: Exception) {
            false
        }
    }

    /** پس از پایان ذخیره‌سازی SAF از میزبان صدا زده می‌شود. */
    fun onSaveFinished(reqId: String, saved: Boolean, name: String, error: String?) {
        val m = JSONObject().put("type", "saveDone").put("reqId", reqId).put("saved", saved).put("name", name)
        if (error != null) m.put("error", error)
        host.emit(m)
    }

    // =====================================================================
    // فونت‌های خود اپلیکیشن
    // =====================================================================

    /** [{name, display, kind: bundled|downloaded|custom, exportable, isDefault, isSelected}] */
    @JavascriptInterface
    fun getAppFonts(): String {
        val c = ctx
        val arr = JSONArray()
        val default = FontManager.getDefaultFontFile(c)
        val selected = FontManager.getSelectedFontFile(c)
        for (n in FontManager.listBundledFonts(c)) {
            arr.put(fontJson(n, "bundled", !FontManager.hasUpdatedBundledVersion(c, n), n == default, n == selected))
        }
        for (n in FontManager.listDownloadedFonts(c)) arr.put(fontJson(n, "downloaded", false, n == default, n == selected))
        for (n in FontManager.listCustomFonts(c)) arr.put(fontJson(n, "custom", true, n == default, n == selected))
        return arr.toString()
    }

    private fun fontJson(n: String, kind: String, exportable: Boolean, def: Boolean, sel: Boolean) =
        JSONObject().put("name", n).put("display", FontManager.displayName(n)).put("kind", kind)
            .put("exportable", exportable).put("isDefault", def).put("isSelected", sel)

    /** فونت اپلیکیشن را به پوشهٔ رد و بدل کپی می‌کند → رویداد appFontReady {name,size,url}. */
    @JavascriptInterface
    fun exportAppFont(reqId: String, fontName: String) {
        if (!validReq(reqId)) return
        pool.execute {
            val c = ctx
            val m = JSONObject().put("type", "appFontReady").put("reqId", reqId)
            try {
                val bundled = FontManager.isBundledName(c, fontName)
                val custom = FontManager.isCustomFont(c, fontName)
                val okToExport = custom || (bundled && !FontManager.hasUpdatedBundledVersion(c, fontName))
                if (!okToExport) {
                    m.put("error", AppLang.t("این فونت محافظت‌شده است و در استودیو باز نمی‌شود.", "This font is protected and can't be opened in the studio."))
                } else {
                    val bytes = FontManager.readFontBytes(c, fontName)
                    val dir = File(FontStudioStore.ioDir(c), "appfont").apply { mkdirs() }
                    val out = File(dir, safeName(fontName))
                    out.writeBytes(bytes)
                    m.put("name", out.name).put("size", out.length())
                        .put("url", ORIGIN + PREFIX_IO + "appfont/" + Uri.encode(out.name))
                }
            } catch (e: Exception) {
                m.put("error", e.message ?: "export failed")
            }
            host.emit(m)
        }
    }

    /** فونت ساخته‌شده را به فهرست فونت‌های کاربر در اپلیکیشن اضافه می‌کند (TTF/OTF/TTC) → رویداد fontInstalled. */
    @JavascriptInterface
    fun installFontToApp(reqId: String, stageId: String, displayName: String) {
        if (!validReq(reqId)) return
        val f = stageFile(stageId)
        pool.execute {
            val m = JSONObject().put("type", "fontInstalled").put("reqId", reqId)
            if (f == null) {
                m.put("error", "stage not found")
            } else {
                try {
                    val r = FileInputStream(f).use { FontManager.importFont(ctx, safeName(displayName), it) }
                    when (r) {
                        is FontManager.ImportResult.Success -> m.put("ok", true).put("fileName", r.fileName)
                        is FontManager.ImportResult.Failure -> m.put("error", r.message)
                    }
                } catch (e: Exception) {
                    m.put("error", e.message ?: "install failed")
                }
            }
            host.emit(m)
        }
    }

    // =====================================================================
    // فضای کار (workspace): پروژه‌ها، بازیابی خودکار، تنظیمات
    // =====================================================================

    private fun wsFile(path: String): File? {
        val rel = FontStudioManifest.normalize(path) ?: return null
        val root = FontStudioStore.workspace(ctx)
        val f = File(root, rel)
        return try {
            if (f.canonicalPath.startsWith(root.canonicalPath + File.separator)) f else null
        } catch (_: Exception) { null }
    }

    private fun wsDir(path: String): File? =
        if (path.isBlank() || path == "/" || path == ".") FontStudioStore.workspace(ctx) else wsFile(path)

    private fun dirSize(f: File): Long =
        if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

    @JavascriptInterface
    fun wsList(dir: String): String {
        val d = wsDir(dir) ?: return "[]"
        val arr = JSONArray()
        d.listFiles()?.sortedBy { it.name.lowercase() }?.forEach {
            arr.put(JSONObject().put("name", it.name).put("isDir", it.isDirectory)
                .put("size", if (it.isFile) it.length() else 0L).put("modified", it.lastModified()))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun wsStat(path: String): String {
        val f = wsFile(path)
        if (f == null || !f.exists()) return JSONObject().put("exists", false).toString()
        return JSONObject().put("exists", true).put("isDir", f.isDirectory)
            .put("size", if (f.isFile) f.length() else 0L).put("modified", f.lastModified()).toString()
    }

    @JavascriptInterface
    fun wsUsage(): String =
        JSONObject().put("used", dirSize(FontStudioStore.workspace(ctx))).put("quota", WS_QUOTA).toString()

    @JavascriptInterface
    fun wsDelete(path: String): Boolean {
        val f = wsFile(path) ?: return false
        return if (f.isDirectory) f.deleteRecursively() else f.delete()
    }

    @JavascriptInterface
    fun wsMove(from: String, to: String): Boolean {
        val a = wsFile(from) ?: return false
        val b = wsFile(to) ?: return false
        if (!a.exists()) return false
        b.parentFile?.mkdirs()
        return try { a.renameTo(b) || (a.copyRecursively(b, true) && a.deleteRecursively()) } catch (_: Exception) { false }
    }

    /** فایل مرحله‌بندی‌شده را داخل فضای کار می‌گذارد (جابه‌جایی). خواندن: GET /__ws/<path> */
    @JavascriptInterface
    fun wsPutStaged(stageId: String, path: String): Boolean {
        val src = stageFile(stageId) ?: return false
        val dst = wsFile(path) ?: return false
        val used = dirSize(FontStudioStore.workspace(ctx)) - (if (dst.isFile) dst.length() else 0L)
        if (used + src.length() > WS_QUOTA) return false
        dst.parentFile?.mkdirs()
        val tmp = File(dst.parentFile, dst.name + ".part")
        return try {
            src.copyTo(tmp, overwrite = true)
            if (dst.exists()) dst.delete()
            val ok = tmp.renameTo(dst)
            if (ok) { stages.remove(stageId); src.delete() }
            ok
        } catch (_: Exception) {
            tmp.delete(); false
        }
    }

    @JavascriptInterface
    fun wsPutText(path: String, text: String): Boolean {
        val dst = wsFile(path) ?: return false
        val bytes = text.toByteArray(Charsets.UTF_8)
        if (bytes.size > MAX_TEXT_BYTES) return false
        dst.parentFile?.mkdirs()
        val tmp = File(dst.parentFile, dst.name + ".part")
        return try {
            tmp.writeBytes(bytes)
            if (dst.exists()) dst.delete()
            tmp.renameTo(dst)
        } catch (_: Exception) { tmp.delete(); false }
    }

    @JavascriptInterface
    fun wsGetText(path: String): String? {
        val f = wsFile(path) ?: return null
        if (!f.isFile || f.length() > MAX_TEXT_BYTES) return null
        return try { f.readText(Charsets.UTF_8) } catch (_: Exception) { null }
    }

    // =====================================================================
    // امکانات کوچک سیستم
    // =====================================================================

    @JavascriptInterface
    fun toast(msg: String) {
        host.runOnUi(Runnable { Toast.makeText(ctx, msg.take(300), Toast.LENGTH_SHORT).show() })
    }

    @JavascriptInterface
    fun copyText(text: String) {
        host.runOnUi(Runnable {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("font-studio", text.take(1_000_000)))
        })
    }

    @JavascriptInterface
    fun pasteText(): String = try {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
    } catch (_: Exception) { "" }

    /** فقط https. */
    @JavascriptInterface
    fun openExternal(url: String): Boolean {
        val u = try { Uri.parse(url) } catch (_: Exception) { return false }
        if (u.scheme != "https" || u.host.isNullOrBlank()) return false
        host.runOnUi(Runnable {
            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
        })
        return true
    }

    @JavascriptInterface
    fun setKeepScreenOn(on: Boolean) { host.runOnUi(Runnable { host.setKeepScreenOn(on) }) }

    /** auto | portrait | landscape */
    @JavascriptInterface
    fun setOrientation(mode: String) { host.runOnUi(Runnable { host.setOrientation(mode) }) }

    @JavascriptInterface
    fun setUnsaved(on: Boolean) { host.runOnUi(Runnable { host.setUnsaved(on) }) }

    /** tick | click | heavy */
    @JavascriptInterface
    fun haptic(kind: String) {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            val ms = when (kind) { "heavy" -> 30L; "click" -> 15L; else -> 8L }
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        } catch (_: Exception) { }
    }

    @JavascriptInterface
    fun close() { host.runOnUi(Runnable { host.requestClose() }) }

    @JavascriptInterface
    fun openManager() { host.runOnUi(Runnable { host.openManager() }) }

    @JavascriptInterface
    fun log(level: String, msg: String) {
        if (!BuildConfig.DEBUG) return
        val m = msg.take(2000)
        when (level) { "error" -> Log.e("FontStudio", m); "warn" -> Log.w("FontStudio", m); else -> Log.d("FontStudio", m) }
    }

    // =====================================================================
    // کمکی‌ها
    // =====================================================================

    private fun validReq(id: String) = ID_RE.matches(id)

    private fun safeName(n: String): String {
        val s = n.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trim('.').take(120)
        return s.ifBlank { "file" }
    }
}
