package com.example.persianfontkeyboard.fontstudio

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import com.example.persianfontkeyboard.AppLang
import com.example.persianfontkeyboard.BuildConfig
import com.example.persianfontkeyboard.MainMenuApply
import com.example.persianfontkeyboard.MenuTarget
import com.example.persianfontkeyboard.R
import com.example.persianfontkeyboard.ThemeManager
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.Executors

/**
 * میزبان «استودیو ساخت و ویرایش فونت»: صفحهٔ وب بستهٔ دانلودشده را داخل یک WebView امن اجرا می‌کند.
 *
 *  • همهٔ فایل‌ها از آدرس مجازی https://appassets.androidplatform.net/… (فقط از پوشهٔ بستهٔ نصب‌شده) می‌آیند.
 *  • هر درخواست به بیرون از این آدرس مسدود است (هیچ اینترنتی برای صفحهٔ استودیو نیست).
 *  • ارتباط با گوشی فقط از راه [FontStudioBridge] است.
 *
 * ورودی‌های اختیاری Intent: [EXTRA_ACTION] (new | editAppDefault | editAppFont | openFile)، [EXTRA_FONT_NAME].
 */
class FontStudioHostActivity : AppCompatActivity(), FontStudioBridge.Host {

    companion object {
        const val EXTRA_ACTION = "fs_action"
        const val EXTRA_FONT_NAME = "fs_font_name"

        fun open(ctx: Context, action: String? = null, fontName: String? = null) {
            val i = Intent(ctx, FontStudioHostActivity::class.java)
            if (action != null) i.putExtra(EXTRA_ACTION, action)
            if (fontName != null) i.putExtra(EXTRA_FONT_NAME, fontName)
            if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    override val ctx: Context get() = applicationContext
    override val themeCtx: Context get() = this

    private lateinit var web: WebView
    private lateinit var bridge: FontStudioBridge
    private lateinit var loading: View
    private lateinit var errorBox: View
    private lateinit var errorText: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var unsaved = false
    private var pendingPickReq: String? = null
    private var pendingSave: Triple<String, File, String>? = null   // reqId, فایل، نام
    private var fileChooserCb: ValueCallback<Array<Uri>>? = null
    private var pageReady = false

    private val pickLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val req = pendingPickReq ?: return@registerForActivityResult
        pendingPickReq = null
        bridge.onPicked(req, if (r.resultCode == Activity.RESULT_OK) urisOf(r.data) else emptyList())
    }

    private val saveLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = pendingSave ?: return@registerForActivityResult
        pendingSave = null
        val uri = if (r.resultCode == Activity.RESULT_OK) r.data?.data else null
        if (uri == null) {
            bridge.onSaveFinished(p.first, false, p.third, null)
            return@registerForActivityResult
        }
        io.execute {
            try {
                contentResolver.openOutputStream(uri, "wt")!!.use { out -> p.second.inputStream().use { it.copyTo(out) } }
                bridge.onSaveFinished(p.first, true, p.third, null)
            } catch (e: Exception) {
                bridge.onSaveFinished(p.first, false, p.third, e.message ?: "save failed")
            }
        }
    }

    private val chooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = fileChooserCb ?: return@registerForActivityResult
        fileChooserCb = null
        val uris = if (r.resultCode == Activity.RESULT_OK) urisOf(r.data) else emptyList()
        cb.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
    }

    private fun urisOf(d: Intent?): List<Uri> {
        if (d == null) return emptyList()
        val cd = d.clipData
        if (cd != null) return (0 until cd.itemCount).mapNotNull { cd.getItemAt(it).uri }
        return listOfNotNull(d.data)
    }

    // ------------------------------------------------------------------ چرخهٔ حیات

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)

        // استودیو نصب نیست (مثلاً پاک شده) ← صفحهٔ مدیریت
        val manifest = FontStudioStore.currentManifest(this)
        val pkgDir = FontStudioStore.currentDir(this)
        if (manifest == null || pkgDir == null || !File(pkgDir, manifest.entry).isFile) {
            Toast.makeText(this, AppLang.t(
                "لطفاً برای استفاده از این قابلیت باید استودیو ساخت و ویرایش فونت را بارگیری کنید.",
                "To use this feature you need to download the Font Creation and Editing Studio."
            ), Toast.LENGTH_LONG).show()
            startActivity(Intent(this, FontStudioHubActivity::class.java))
            finish()
            return
        }

        bridge = FontStudioBridge(this)
        val bg = ThemeManager.themeColor(this, R.attr.appBackground)

        val root = FrameLayout(this).apply { setBackgroundColor(bg); fitsSystemWindows = true }

        web = WebView(this).apply {
            setBackgroundColor(bg)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        loading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            addView(ProgressBar(context))
            addView(TextView(context).apply {
                text = AppLang.t("در حال آماده‌سازی استودیو…", "Preparing the studio…")
                setTextColor(if (ThemeManager.isDark(context)) Color.WHITE else Color.DKGRAY)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, 0)
            })
        }
        root.addView(loading, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        errorText = TextView(this).apply { textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(24), dp(16), dp(24), dp(16)) }
        errorBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            setBackgroundColor(bg)
            addView(errorText)
            addView(android.widget.Button(context).apply {
                text = AppLang.t("بازگشت به مدیریت استودیو", "Back to studio manager")
                setOnClickListener { openManager() }
            })
            addView(android.widget.Button(context).apply {
                text = AppLang.t("تلاش دوباره", "Try again")
                setOnClickListener { errorBox.visibility = View.GONE; loading.visibility = View.VISIBLE; web.reload() }
            })
        }
        root.addView(errorBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        setContentView(root)
        MainMenuApply.attach(this, MenuTarget.FONT_STUDIO)

        configureWebView(pkgDir)
        web.addJavascriptInterface(bridge, "AndroidStudio")
        web.loadUrl(FontStudioBridge.ORIGIN + FontStudioBridge.PREFIX_STUDIO + manifest.entry)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { onBack() }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(pkgDir: File) {
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        val shim = object : WebViewAssetLoader.PathHandler {
            override fun handle(path: String): WebResourceResponse? {
                if (path != "host.js") return null
                return WebResourceResponse("text/javascript", "utf-8", 200, "OK",
                    mapOf("Cache-Control" to "no-store", "X-Content-Type-Options" to "nosniff"),
                    ByteArrayInputStream(FontStudioShim.JS.toByteArray(Charsets.UTF_8)))
            }
        }
        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler(FontStudioBridge.PREFIX_STUDIO, FontStudioPathHandler(pkgDir, cacheable = true, isStudioPage = true))
            .addPathHandler(FontStudioBridge.PREFIX_IO, FontStudioPathHandler(FontStudioStore.ioDir(this), cacheable = false))
            .addPathHandler(FontStudioBridge.PREFIX_WS, FontStudioPathHandler(FontStudioStore.workspace(this), cacheable = false))
            .addPathHandler(FontStudioBridge.PREFIX_HOST, shim)
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // IndexedDB / localStorage برای کش داخلی استودیو
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
            setGeolocationEnabled(false)
            mediaPlaybackRequiresUserGesture = true
            textZoom = 100                       // ویرایشگر فونت باید دقیق باشد؛ بزرگ‌نمایی فونت سیستم اعمال نشود
            builtInZoomControls = false
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                loader.shouldInterceptRequest(request.url)?.let { return it }
                // هر چیز بیرون از آدرس مجازی (اینترنت، file://، content://) مسدود است
                return WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val inside = u.scheme == "https" && u.host == "appassets.androidplatform.net"
                return !inside   // true = ناوبری مسدود
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pageReady = true
                loading.visibility = View.GONE
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (request.isForMainFrame) showError(AppLang.t("فایل صفحهٔ استودیو پیدا نشد (کد ${errorResponse.statusCode}). بسته را دوباره نصب کنید.", "The studio page file wasn't found (code ${errorResponse.statusCode}). Reinstall the package."))
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (request.isForMainFrame) showError(AppLang.t("بارگذاری استودیو ناموفق بود.", "Loading the studio failed."))
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                // پردازش وب کرش کرد یا حافظه کم شد؛ برنامه را از کرش نجات می‌دهیم و صفحه را دوباره می‌سازیم.
                Toast.makeText(this@FontStudioHostActivity, AppLang.t("استودیو به‌دلیل کمبود حافظه بسته شد؛ دوباره باز می‌شود.", "The studio closed due to low memory; reopening."), Toast.LENGTH_LONG).show()
                val i = intent
                finish()
                startActivity(i)
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileChooserCb?.onReceiveValue(null)
                fileChooserCb = cb
                return try {
                    chooserLauncher.launch(params.createIntent())
                    true
                } catch (_: Exception) {
                    fileChooserCb = null
                    false
                }
            }

            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (BuildConfig.DEBUG) android.util.Log.d("FontStudio", "${m.message()} (${m.sourceId()}:${m.lineNumber()})")
                return true
            }

            // دوربین/میکروفن/موقعیت: هرگز (هیچ‌کدام از Callbackها پیاده‌سازی نشده‌اند)
        }
    }

    private fun showError(msg: String) {
        loading.visibility = View.GONE
        errorText.text = msg
        errorText.setTextColor(if (ThemeManager.isDark(this)) Color.WHITE else Color.DKGRAY)
        errorBox.visibility = View.VISIBLE
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onPause() {
        if (::bridge.isInitialized && pageReady) emit(JSONObject().put("type", "pause"))
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::bridge.isInitialized && pageReady) emit(JSONObject().put("type", "resume"))
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            (web.parent as? ViewGroup)?.removeView(web)
            web.removeJavascriptInterface("AndroidStudio")
            web.destroy()
        }
        if (::bridge.isInitialized) bridge.shutdown()
        io.shutdownNow()
        if (isFinishing) {
            try { FontStudioStore.ioDir(this).deleteRecursively() } catch (_: Exception) { }
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ دکمهٔ بازگشت

    private fun onBack() {
        if (!pageReady) { finish(); return }
        web.evaluateJavascript(
            "(function(){try{return !!(window.FontStudioHost&&window.FontStudioHost.__back())}catch(e){return false}})()"
        ) { r ->
            if (r == "true") return@evaluateJavascript
            if (unsaved) {
                AlertDialog.Builder(this)
                    .setTitle(AppLang.t("تغییرات ذخیره‌نشده", "Unsaved changes"))
                    .setMessage(AppLang.t(
                        "پروژه تغییرات ذخیره‌نشده دارد. با خروج ممکن است از دست برود (نسخهٔ بازیابی خودکار هم اگر فعال باشد نگه داشته می‌شود).",
                        "The project has unsaved changes. Leaving may lose them (the auto-recovery copy is kept if it's enabled)."
                    ))
                    .setPositiveButton(AppLang.t("خروج", "Leave")) { _, _ -> finish() }
                    .setNegativeButton(AppLang.t("ماندن", "Stay"), null)
                    .show()
            } else finish()
        }
    }

    // ------------------------------------------------------------------ FontStudioBridge.Host

    override fun emit(msg: JSONObject) {
        runOnUi(Runnable {
            if (!::web.isInitialized) return@Runnable
            web.evaluateJavascript(
                "window.FontStudioHost&&window.FontStudioHost.__emit&&window.FontStudioHost.__emit(" + JSONObject.quote(msg.toString()) + ")",
                null
            )
        })
    }

    override fun runOnUi(r: Runnable) { if (Looper.myLooper() == Looper.getMainLooper()) r.run() else ui.post(r) }

    override fun launchPick(reqId: String, accept: List<String>, multiple: Boolean) {
        if (pendingPickReq != null) { bridge.onPicked(reqId, emptyList()); return }
        pendingPickReq = reqId
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
        }
        try { pickLauncher.launch(i) } catch (_: Exception) { pendingPickReq = null; bridge.onPicked(reqId, emptyList()) }
    }

    override fun launchSave(reqId: String, file: File, name: String, mime: String) {
        if (pendingSave != null) { bridge.onSaveFinished(reqId, false, name, "busy"); return }
        pendingSave = Triple(reqId, file, name)
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, name)
        }
        try { saveLauncher.launch(i) } catch (_: Exception) { pendingSave = null; bridge.onSaveFinished(reqId, false, name, "no picker") }
    }

    override fun requestClose() { finish() }

    override fun openManager() {
        startActivity(Intent(this, FontStudioHubActivity::class.java).putExtra(FontStudioHubActivity.EXTRA_NO_AUTO_OPEN, true))
    }

    override fun setKeepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun setOrientation(mode: String) {
        requestedOrientation = when (mode) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    override fun setUnsaved(on: Boolean) { unsaved = on }

    override fun launchInfo(): JSONObject = JSONObject().apply {
        put("action", intent.getStringExtra(EXTRA_ACTION) ?: "none")
        intent.getStringExtra(EXTRA_FONT_NAME)?.let { put("fontName", it) }
    }
}
