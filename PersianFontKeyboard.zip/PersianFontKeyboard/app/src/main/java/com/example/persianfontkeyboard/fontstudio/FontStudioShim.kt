package com.example.persianfontkeyboard.fontstudio

/**
 * پوشش Promise‌ـدار روی `window.AndroidStudio`؛ از آدرس `/__host/host.js` به صفحهٔ استودیو داده می‌شود.
 * استودیو فقط کافی است این را در index.html بیاورد:  <script src="/__host/host.js"></script>
 *
 * ⚠️ این رشته «raw» است؛ داخل آن نباید نویسهٔ دلار (به‌ویژه الگوی ${…}) بیاید.
 */
object FontStudioShim {

    const val JS = """
(function () {
  'use strict';
  if (window.FontStudioHost) return;
  var A = window.AndroidStudio;
  if (!A) { console.error('AndroidStudio bridge is missing'); return; }

  var seq = 0, pending = {}, listeners = {}, backHandler = null;
  function rid() { seq++; return 'r' + seq + '_' + Date.now().toString(36); }
  function expect(reqId) {
    return new Promise(function (resolve, reject) { pending[reqId] = { resolve: resolve, reject: reject }; });
  }
  function emitLocal(m) { (listeners[m.type] || []).slice().forEach(function (fn) { try { fn(m); } catch (e) { console.error(e); } }); }

  function toBytes(data) {
    if (data instanceof Uint8Array) return Promise.resolve(data);
    if (data instanceof ArrayBuffer) return Promise.resolve(new Uint8Array(data));
    if (ArrayBuffer.isView(data)) return Promise.resolve(new Uint8Array(data.buffer, data.byteOffset, data.byteLength));
    if (typeof Blob !== 'undefined' && data instanceof Blob) return data.arrayBuffer().then(function (b) { return new Uint8Array(b); });
    if (typeof data === 'string') return Promise.resolve(new TextEncoder().encode(data));
    return Promise.reject(new Error('Unsupported data type'));
  }
  function b64(bytes, from, to) {
    var s = '', step = 0x8000;
    for (var i = from; i < to; i += step) {
      s += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + step, to)));
    }
    return btoa(s);
  }
  var CHUNK = 384 * 1024;
  function stage(data) {
    return toBytes(data).then(function (bytes) {
      var id = 's' + rid().replace(/[^A-Za-z0-9_-]/g, '');
      if (!A.stageBegin(id)) throw new Error('stageBegin failed');
      var idx = 0;
      for (var off = 0; off < bytes.length || (off === 0 && bytes.length === 0); off += CHUNK) {
        var end = Math.min(off + CHUNK, bytes.length);
        if (!A.stageChunk(id, idx++, b64(bytes, off, end))) { A.stageDiscard(id); throw new Error('stageChunk failed'); }
        if (bytes.length === 0) break;
      }
      var r = JSON.parse(A.stageEnd(id));
      if (!r.ok) throw new Error('stageEnd failed');
      return { stageId: id, size: r.size, url: r.url };
    });
  }

  var H = {
    apiVersion: 1,
    info: JSON.parse(A.hostInfo()),

    on: function (type, fn) { (listeners[type] = listeners[type] || []).push(fn); },
    off: function (type, fn) { listeners[type] = (listeners[type] || []).filter(function (f) { return f !== fn; }); },

    /* ---- فایل‌ها ---- */
    pickFiles: function (opts) {
      opts = opts || {};
      var id = rid(), p = expect(id);
      A.pickFiles(id, JSON.stringify(opts.accept || []), !!opts.multiple);
      return p.then(function (m) { return m.files || []; });
    },
    fetchBytes: function (url) {
      return fetch(url).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); })
        .then(function (b) { return new Uint8Array(b); });
    },
    stage: stage,
    saveFile: function (data, name, mime) {
      return stage(data).then(function (st) {
        var id = rid(), p = expect(id);
        A.saveStaged(id, st.stageId, name, mime || 'application/octet-stream');
        return p.then(function (m) { A.stageDiscard(st.stageId); return { saved: !!m.saved, name: m.name }; },
                      function (e) { A.stageDiscard(st.stageId); throw e; });
      });
    },
    shareFile: function (data, name, mime) {
      return stage(data).then(function (st) { var ok = A.shareStaged(st.stageId, name, mime || 'application/octet-stream'); return ok; });
    },

    /* ---- فونت‌های خود اپلیکیشن ---- */
    appFonts: {
      list: function () { return JSON.parse(A.getAppFonts()); },
      exportToStudio: function (name) {
        var id = rid(), p = expect(id);
        A.exportAppFont(id, name);
        return p.then(function (m) { return H.fetchBytes(m.url).then(function (bytes) { return { name: m.name, bytes: bytes }; }); });
      },
      install: function (data, displayName) {
        return stage(data).then(function (st) {
          var id = rid(), p = expect(id);
          A.installFontToApp(id, st.stageId, displayName);
          return p.then(function (m) { A.stageDiscard(st.stageId); return m; }, function (e) { A.stageDiscard(st.stageId); throw e; });
        });
      }
    },

    /* ---- فضای کار (پروژه‌ها، بازیابی خودکار) ---- */
    ws: {
      list: function (dir) { return JSON.parse(A.wsList(dir || '')); },
      stat: function (path) { return JSON.parse(A.wsStat(path)); },
      usage: function () { return JSON.parse(A.wsUsage()); },
      remove: function (path) { return A.wsDelete(path); },
      move: function (from, to) { return A.wsMove(from, to); },
      putText: function (path, text) { return A.wsPutText(path, text); },
      getText: function (path) { return A.wsGetText(path); },
      put: function (path, data) {
        return stage(data).then(function (st) {
          if (!A.wsPutStaged(st.stageId, path)) { A.stageDiscard(st.stageId); throw new Error('wsPut failed (quota or path)'); }
          return true;
        });
      },
      read: function (path) { return H.fetchBytes('/__ws/' + path.split('/').map(encodeURIComponent).join('/')); }
    },

    /* ---- سیستم ---- */
    toast: function (m) { A.toast(String(m)); },
    copyText: function (t) { A.copyText(String(t)); },
    pasteText: function () { return A.pasteText(); },
    openExternal: function (u) { return A.openExternal(String(u)); },
    keepScreenOn: function (on) { A.setKeepScreenOn(!!on); },
    setOrientation: function (mode) { A.setOrientation(mode || 'auto'); },
    haptic: function (k) { A.haptic(k || 'tick'); },
    setUnsaved: function (on) { A.setUnsaved(!!on); },
    close: function () { A.close(); },
    openManager: function () { A.openManager(); },
    log: function (level, msg) { A.log(level, String(msg)); },

    /* دکمهٔ بازگشت: fn باید true برگرداند اگر خودش مدیریت کرد (مثلاً پنجره‌ای را بست). */
    setBackHandler: function (fn) { backHandler = fn; },

    /* ---- فراخوانی از طرف برنامه ---- */
    __emit: function (s) {
      var m = JSON.parse(s);
      var p = m.reqId && pending[m.reqId];
      if (p) { delete pending[m.reqId]; if (m.error) p.reject(new Error(m.error)); else p.resolve(m); }
      emitLocal(m);
    },
    __back: function () { try { return backHandler ? !!backHandler() : false; } catch (e) { return false; } }
  };
  window.FontStudioHost = H;
  window.addEventListener('error', function (e) { A.log('error', (e.message || '') + ' @' + (e.filename || '') + ':' + (e.lineno || 0)); });
})();
"""
}
