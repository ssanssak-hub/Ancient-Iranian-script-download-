package com.example.persianfontkeyboard.fontstudio

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.example.persianfontkeyboard.AppLang
import com.example.persianfontkeyboard.BuildConfig
import com.example.persianfontkeyboard.R
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * «انزیپ» و نصب امن بستهٔ استودیو:
 *  ۱) زیپ بدون ذخیره‌شدن کامل در حافظه خوانده می‌شود (ZipInputStream)، با دفاع در برابر Zip-Slip و بمب زیپ.
 *  ۲) مانیفست خوانده، به برنامهٔ ما (applicationId) و نسخهٔ برنامه (minAppVersionCode) بسته می‌شود.
 *  ۳) امضای مانیفست (ECDSA P-256 / SHA-256) با کلید عمومی داخل برنامه بررسی می‌شود.
 *     اگر کلید عمومی در `font_studio_pubkey` خالی باشد، «حالت توسعه» است و بستهٔ بی‌امضا هم نصب می‌شود.
 *  ۴) SHA-256 همهٔ فایل‌ها با مانیفست مقایسه می‌شود؛ فایل اضافه یا کم → رد.
 *  ۵) نصب اتمی: ابتدا در پوشهٔ موقت، بعد جابه‌جایی؛ نسخهٔ قبلی فقط بعد از موفقیت پاک می‌شود.
 */
object FontStudioInstaller {

    const val MAX_ENTRIES = 6000
    const val MAX_TOTAL_BYTES = 400L * 1024 * 1024
    const val MAX_FILE_BYTES = 120L * 1024 * 1024
    const val MAX_MANIFEST_BYTES = 2L * 1024 * 1024

    /** پسوندهای مجاز داخل بسته (چیز دیگری نصب نمی‌شود). */
    private val ALLOWED_EXT = setOf(
        "html", "htm", "js", "mjs", "css", "json", "wasm", "map", "txt", "md",
        "png", "jpg", "jpeg", "webp", "svg", "gif", "ico",
        "woff", "woff2", "ttf", "otf", "bin", "dat", "csv"
    )

    class InstallException(message: String) : Exception(message)

    class Result(val manifest: FontStudioManifest, val signed: Boolean, val replacedVersion: Int)

    fun interface Progress { fun update(doneBytes: Long, label: String) }

    /** از یک Uri (انتخاب‌گر فایل) نصب می‌کند. روی نخ پس‌زمینه صدا بزنید. */
    fun installFromUri(ctx: Context, uri: Uri, progress: Progress? = null): Result {
        val input = ctx.contentResolver.openInputStream(uri)
            ?: throw InstallException(AppLang.t("فایل زیپ باز نشد.", "The zip file couldn't be opened."))
        return input.use { installFromStream(ctx, it, progress) }
    }

    fun installFromFile(ctx: Context, file: File, progress: Progress? = null): Result =
        file.inputStream().use { installFromStream(ctx, it, progress) }

    @Synchronized
    fun installFromStream(ctx: Context, input: InputStream, progress: Progress? = null): Result {
        val staging = FontStudioStore.stagingDir(ctx)
        staging.deleteRecursively()
        if (!staging.mkdirs()) throw InstallException(AppLang.t("ساخت پوشهٔ موقت ممکن نشد.", "Couldn't create the temp folder."))
        try {
            val extracted = extract(input, staging, progress)

            // --- مانیفست ---
            val manifestBytes = extracted.manifestBytes
                ?: throw InstallException(AppLang.t("این فایل بستهٔ استودیو نیست (manifest.json پیدا نشد).", "This isn't a studio package (manifest.json not found)."))
            val manifest = try {
                FontStudioManifest.parse(manifestBytes.toString(Charsets.UTF_8))
            } catch (e: FontStudioManifest.Companion.Invalid) {
                throw InstallException(AppLang.t("مانیفست بسته معتبر نیست: ${e.message}", "The package manifest is invalid: ${e.message}"))
            }

            // --- مخصوص همین برنامه ---
            if (manifest.applicationId != BuildConfig.APPLICATION_ID) {
                throw InstallException(AppLang.t("این بسته برای برنامهٔ دیگری ساخته شده و روی این اپلیکیشن کار نمی‌کند.", "This package was built for another app and won't run in this app."))
            }
            if (manifest.minAppVersionCode > BuildConfig.VERSION_CODE) {
                throw InstallException(AppLang.t(
                    "این نسخهٔ استودیو به نسخهٔ جدیدتری از اپلیکیشن نیاز دارد. اپلیکیشن را بروزرسانی کنید.",
                    "This studio version needs a newer version of the app. Please update the app."
                ))
            }
            if (manifest.hostApi > FontStudioBridge.API_VERSION) {
                throw InstallException(AppLang.t(
                    "این استودیو از رابط میزبان جدیدتری استفاده می‌کند؛ اپلیکیشن را بروزرسانی کنید.",
                    "This studio uses a newer host interface; please update the app."
                ))
            }

            // --- امضا ---
            val signed = verifySignature(ctx, manifestBytes, extracted.sigBytes)

            // --- هم‌خوانی فایل‌ها با مانیفست ---
            val onDisk = extracted.hashes
            for ((path, hash) in manifest.files) {
                val got = onDisk[path] ?: throw InstallException(AppLang.t("فایل «$path» در زیپ نیست.", "The file “$path” is missing from the zip."))
                if (got != hash) throw InstallException(AppLang.t("فایل «$path» خراب یا دستکاری‌شده است.", "The file “$path” is corrupt or was modified."))
            }
            for (path in onDisk.keys) {
                if (!manifest.files.containsKey(path)) {
                    throw InstallException(AppLang.t("فایل اضافه‌ای در زیپ هست که در مانیفست نیست: $path", "The zip has a file that isn't in the manifest: $path"))
                }
            }

            // --- نصب اتمی ---
            File(staging, FontStudioManifest.FILE_NAME).writeBytes(manifestBytes)
            extracted.sigBytes?.let { File(staging, FontStudioManifest.SIG_NAME).writeBytes(it) }

            val prevCode = FontStudioStore.installedVersionCode(ctx)
            val target = File(FontStudioStore.pkgRoot(ctx), manifest.versionCode.toString())
            if (target.exists()) target.deleteRecursively()
            if (!staging.renameTo(target)) {
                target.mkdirs()
                staging.copyRecursively(target, overwrite = true)
                staging.deleteRecursively()
            }
            FontStudioStore.markInstalled(ctx, manifest, signed)

            // نسخه‌های قدیمی‌تر پاک می‌شوند
            FontStudioStore.pkgRoot(ctx).listFiles()?.forEach { d ->
                if (d.isDirectory && d.name != manifest.versionCode.toString()) d.deleteRecursively()
            }
            return Result(manifest, signed, prevCode)
        } catch (e: InstallException) {
            staging.deleteRecursively()
            throw e
        } catch (e: Throwable) {
            staging.deleteRecursively()
            throw InstallException(AppLang.t("نصب استودیو ناموفق بود: ${e.javaClass.simpleName}", "Studio install failed: ${e.javaClass.simpleName}"))
        }
    }

    private class Extracted(
        val manifestBytes: ByteArray?,
        val sigBytes: ByteArray?,
        val hashes: Map<String, String>
    )

    private fun extract(input: InputStream, dest: File, progress: Progress?): Extracted {
        val destCanonical = dest.canonicalPath + File.separator
        var manifest: ByteArray? = null
        var sig: ByteArray? = null
        val hashes = LinkedHashMap<String, String>()
        var entries = 0
        var total = 0L
        val buf = ByteArray(64 * 1024)

        ZipInputStream(input.buffered()).use { zin ->
            var e: ZipEntry? = zin.nextEntry
            while (e != null) {
                entries++
                if (entries > MAX_ENTRIES) throw InstallException(AppLang.t("تعداد فایل‌های زیپ بیش از حد است.", "The zip has too many files."))
                if (!e.isDirectory) {
                    val rawName = e.name
                    // فایل‌های زائدِ ساخته‌شده توسط macOS/ویندوز نادیده گرفته می‌شوند
                    val junk = rawName.startsWith("__MACOSX/") || rawName.endsWith(".DS_Store") || rawName.endsWith("Thumbs.db")
                    val name = if (junk) "" else (FontStudioManifest.normalize(rawName)
                        ?: throw InstallException(AppLang.t("مسیر نامعتبر در زیپ: $rawName", "Invalid path in zip: $rawName")))

                    when (name) {
                        "" -> { /* نادیده */ }
                        FontStudioManifest.FILE_NAME -> {
                            manifest = readLimited(zin, MAX_MANIFEST_BYTES, buf)
                        }
                        FontStudioManifest.SIG_NAME -> {
                            sig = readLimited(zin, 4096, buf)
                        }
                        else -> {
                            val ext = name.substringAfterLast('.', "").lowercase()
                            if (ext !in ALLOWED_EXT) {
                                throw InstallException(AppLang.t("نوع فایل مجاز نیست: $name", "File type not allowed: $name"))
                            }
                            val out = File(dest, name)
                            if (!out.canonicalPath.startsWith(destCanonical)) {
                                throw InstallException(AppLang.t("مسیر خطرناک در زیپ: $name", "Unsafe path in zip: $name"))
                            }
                            out.parentFile?.mkdirs()
                            val md = MessageDigest.getInstance("SHA-256")
                            var size = 0L
                            FileOutputStream(out).use { fo ->
                                while (true) {
                                    val n = zin.read(buf)
                                    if (n < 0) break
                                    size += n
                                    total += n
                                    if (size > MAX_FILE_BYTES || total > MAX_TOTAL_BYTES) {
                                        throw InstallException(AppLang.t("حجم بسته بیش از حد مجاز است.", "The package is larger than allowed."))
                                    }
                                    md.update(buf, 0, n)
                                    fo.write(buf, 0, n)
                                }
                            }
                            hashes[name] = hex(md.digest())
                            progress?.update(total, name)
                        }
                    }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
        return Extracted(manifest, sig, hashes)
    }

    private fun readLimited(zin: ZipInputStream, max: Long, buf: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream()
        var size = 0L
        while (true) {
            val n = zin.read(buf)
            if (n < 0) break
            size += n
            if (size > max) throw InstallException(AppLang.t("فایل مانیفست/امضا بیش از حد بزرگ است.", "The manifest/signature file is too large."))
            bos.write(buf, 0, n)
        }
        return bos.toByteArray()
    }

    /**
     * true = امضا درست است. false = حالت توسعه (کلید عمومی تنظیم نشده) و بسته بی‌امضاست.
     * اگر کلید عمومی تنظیم شده باشد، نبودن/غلط‌بودن امضا خطا می‌دهد.
     */
    private fun verifySignature(ctx: Context, manifest: ByteArray, sigBytes: ByteArray?): Boolean {
        val keyB64 = ctx.getString(R.string.font_studio_pubkey).trim()
        if (keyB64.isEmpty()) return false
        val sigText = sigBytes?.toString(Charsets.UTF_8)?.trim()
        if (sigText.isNullOrEmpty()) {
            throw InstallException(AppLang.t("بسته امضا ندارد؛ فقط بستهٔ رسمی نصب می‌شود.", "The package isn't signed; only the official package can be installed."))
        }
        val ok = try {
            val pub = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(keyB64, Base64.DEFAULT)))
            val s = Signature.getInstance("SHA256withECDSA")
            s.initVerify(pub)
            s.update(manifest)
            s.verify(Base64.decode(sigText, Base64.DEFAULT))
        } catch (_: Throwable) {
            false
        }
        if (!ok) throw InstallException(AppLang.t("امضای بسته معتبر نیست؛ بسته دستکاری شده یا رسمی نیست.", "The package signature is invalid; it was modified or isn't official."))
        return true
    }

    /**
     * سلامت فایل‌های نصب‌شده را دوباره با مانیفست می‌سنجد (ترمیم/عیب‌یابی). null = سالم؛ وگرنه متن مشکل.
     * روی نخ پس‌زمینه صدا بزنید.
     */
    fun verifyInstalled(ctx: Context): String? {
        val dir = FontStudioStore.currentDir(ctx) ?: return AppLang.t("استودیو نصب نیست.", "The studio isn't installed.")
        val m = FontStudioStore.currentManifest(ctx) ?: return AppLang.t("مانیفست نصب‌شده خراب است.", "The installed manifest is damaged.")
        val buf = ByteArray(64 * 1024)
        for ((path, hash) in m.files) {
            val f = File(dir, path)
            if (!f.isFile) return AppLang.t("فایل گم شده: $path", "Missing file: $path")
            val md = MessageDigest.getInstance("SHA-256")
            f.inputStream().use { ins ->
                while (true) { val n = ins.read(buf); if (n < 0) break; md.update(buf, 0, n) }
            }
            if (hex(md.digest()) != hash) return AppLang.t("فایل خراب است: $path", "Damaged file: $path")
        }
        return null
    }

    private fun hex(b: ByteArray): String {
        val sb = StringBuilder(b.size * 2)
        for (x in b) sb.append(String.format("%02x", x))
        return sb.toString()
    }
}
