package com.example.persianfontkeyboard.fontstudio

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.persianfontkeyboard.AppLang
import com.example.persianfontkeyboard.FontManager
import com.example.persianfontkeyboard.MainMenuApply
import com.example.persianfontkeyboard.MenuTarget
import com.example.persianfontkeyboard.R
import com.example.persianfontkeyboard.TextColorManager
import com.example.persianfontkeyboard.ThemeManager
import java.io.File
import java.util.Locale

/**
 * صفحهٔ «استودیو ساخت و ویرایش فونت» در منوی اصلی (مرکز مدیریت):
 *  • اگر استودیو دانلود نشده: پیام «لطفاً برای استفاده … بارگیری کنید» + دکمه‌های دانلود و «انزیپ فایل زیپ».
 *  • اگر نصب است: باز کردن استودیو، میانبرهای کار (فونت جدید، ویرایش فونت پیش‌فرض/فونت‌های برنامه، باز کردن فایل)،
 *    بررسی نسخه/بروزرسانی، انزیپ نسخهٔ دستی، بررسی سلامت فایل‌ها، ورود مستقیم و حذف.
 *
 * وقتی استودیو نصب باشد و «ورود مستقیم» روشن باشد، صفحه بدون نمایش، مستقیم استودیو را باز می‌کند.
 */
class FontStudioHubActivity : AppCompatActivity() {

    companion object {
        /** از داخل خود استودیو (دکمهٔ مدیریت) صدا زده می‌شود؛ ورود مستقیم را نادیده می‌گیرد. */
        const val EXTRA_NO_AUTO_OPEN = "fs_no_auto_open"
        const val MSG_NOT_INSTALLED_FA = "لطفاً برای استفاده از این قابلیت باید استودیو ساخت و ویرایش فونت را بارگیری کنید."
        const val MSG_NOT_INSTALLED_EN = "To use this feature you need to download the Font Creation and Editing Studio."
    }

    private lateinit var content: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var statusView: TextView
    private lateinit var cancelBtn: TextView
    @Volatile private var busy = false
    @Volatile private var cancel: FontStudioRemote.Cancel? = null

    private val zipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) unzipFrom(uri)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun color(attr: Int): Int = ThemeManager.themeColor(this, attr)
    private fun textColor(): Int = TextColorManager.getColor(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)

        // ورود مستقیم به استودیو
        if (!intent.getBooleanExtra(EXTRA_NO_AUTO_OPEN, false) &&
            FontStudioStore.isInstalled(this) && FontStudioStore.directOpen(this)
        ) {
            FontStudioHostActivity.open(this)
            finish()
            return
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            setBackgroundColor(color(R.attr.appBackground))
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(color(R.attr.appToolbar))
        }
        bar.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundResource(android.R.color.transparent)
            contentDescription = AppLang.t("بازگشت", "Back")
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(34), dp(34)))
        bar.addView(TextView(this).apply {
            text = AppLang.t("استودیو ساخت و ویرایش فونت", "Font Creation & Editing Studio")
            setTextColor(color(R.attr.appToolbarText))
            textSize = 13f
            setTypeface(Typeface.DEFAULT_BOLD)
            setPadding(dp(8), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(5)))

        statusView = label("", 11.5f).apply { visibility = View.GONE; setPadding(dp(14), dp(4), dp(14), 0) }
        root.addView(statusView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        cancelBtn = chip(AppLang.t("✖ لغو", "✖ Cancel")) { cancel?.cancel() }.apply { visibility = View.GONE }
        root.addView(cancelBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.END; setMargins(dp(14), dp(4), dp(14), 0)
        })

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(24)) }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        MainMenuApply.attach(this, MenuTarget.FONT_STUDIO)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized && !busy) render()
    }

    // ------------------------------------------------------------------ رسم صفحه

    private fun render() {
        content.removeAllViews()
        val installed = FontStudioStore.isInstalled(this)

        if (!installed) {
            // پیام اصلی خواسته‌شده
            content.addView(card(color(R.attr.appSurface)).apply {
                addView(label("⬇️  " + AppLang.t(MSG_NOT_INSTALLED_FA, MSG_NOT_INSTALLED_EN), 14f, bold = true))
                addView(label(AppLang.t(
                    "استودیو بخشی از اپلیکیشن نیست تا حجم آن زیاد نشود؛ هر کاربر که خواست آن را دانلود می‌کند و فقط روی همین اپلیکیشن کار می‌کند.",
                    "The studio isn't part of the app, to keep it small. Anyone who wants it downloads it, and it only runs inside this app."
                ), 12f).apply { alpha = 0.85f; setPadding(0, dp(8), 0, 0) })
            })
            content.addView(bigButton(AppLang.t("⬇️ دانلود استودیو از مخزن", "⬇️ Download the studio from the repository")) { downloadFromRepo() })
            content.addView(bigButton(AppLang.t("📦 انزیپ فایل زیپ (استخراج از حافظهٔ گوشی)", "📦 Unzip a zip file (extract from storage)")) { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) })
            content.addView(row(
                chip(AppLang.t("🔎 بررسی نسخهٔ مخزن", "🔎 Check repository version")) { checkAndUpdate() },
                chip(AppLang.t("🌐 صفحهٔ مخزن (دانلود دستی)", "🌐 Repository page (manual download)")) { openRepoPage() }
            ))
            remoteInfoCard()?.let { content.addView(it) }
            content.addView(note(AppLang.t(
                "اگر زیپ استودیو را خودتان (مثلاً با مرورگر) دانلود کرده‌اید، دکمهٔ «انزیپ» آن را بررسی و نصب می‌کند.",
                "If you downloaded the studio zip yourself (e.g. with a browser), the Unzip button verifies and installs it."
            )))
            return
        }

        val m = FontStudioStore.currentManifest(this)
        val sizeMb = (dirSize(FontStudioStore.currentDir(this)!!) / 1024.0 / 1024.0)
        content.addView(card(color(R.attr.appSurface)).apply {
            addView(label("✅  " + AppLang.t("استودیو نصب است", "The studio is installed"), 14f, bold = true))
            val signed = if (FontStudioStore.installedSigned(this@FontStudioHubActivity))
                AppLang.t("امضای رسمی تأیید شد", "Official signature verified")
            else AppLang.t("بدون امضا (حالت توسعه)", "Unsigned (development mode)")
            addView(label(
                AppLang.t("نسخه: ", "Version: ") + (m?.versionName?.ifBlank { null } ?: "?") + " (${FontStudioStore.installedVersionCode(this@FontStudioHubActivity)})\n" +
                    AppLang.t("حجم روی گوشی: ", "Size on device: ") + String.format(Locale.US, "%.1f MB", sizeMb) + "\n" + signed,
                12f
            ).apply { setPadding(0, dp(6), 0, 0) })
        })

        content.addView(bigButton(AppLang.t("🚀 باز کردن استودیو", "🚀 Open the studio")) { FontStudioHostActivity.open(this) })
        remoteInfoCard()?.let { content.addView(it) }

        content.addView(section(AppLang.t("شروع سریع", "Quick start")))
        content.addView(row(
            chip(AppLang.t("🆕 ساخت فونت جدید", "🆕 New font")) { FontStudioHostActivity.open(this, "new") },
            chip(AppLang.t("📂 باز کردن فایل فونت/پروژه", "📂 Open font/project file")) { FontStudioHostActivity.open(this, "openFile") }
        ))
        content.addView(row(
            chip(AppLang.t("✏️ ویرایش فونت پیش‌فرض اپلیکیشن", "✏️ Edit the app's default font")) { editDefaultFont() },
            chip(AppLang.t("🔤 ویرایش یکی از فونت‌های اپلیکیشن", "🔤 Edit one of the app's fonts")) { chooseAppFont() }
        ))

        content.addView(section(AppLang.t("نسخه و بسته", "Version and package")))
        content.addView(row(
            chip(AppLang.t("⟳ بررسی / بروزرسانی", "⟳ Check / update")) { checkAndUpdate() },
            chip(AppLang.t("📦 انزیپ فایل زیپ", "📦 Unzip a zip file")) { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }
        ))
        content.addView(row(
            chip(AppLang.t("🩺 بررسی سلامت فایل‌ها", "🩺 Verify files")) { verify() },
            chip(AppLang.t("🗑 حذف استودیو", "🗑 Remove the studio")) { confirmRemove() }
        ))

        content.addView(CheckBox(this).apply {
            text = AppLang.t("ورود مستقیم به استودیو با زدن آیتم منو", "Open the studio directly when tapping the menu item")
            textSize = 12f
            setTextColor(textColor())
            isChecked = FontStudioStore.directOpen(this@FontStudioHubActivity)
            setOnCheckedChangeListener { _, on -> FontStudioStore.setDirectOpen(this@FontStudioHubActivity, on) }
        })
        content.addView(CheckBox(this).apply {
            text = AppLang.t("هنگام باز شدن این صفحه، نسخهٔ جدید را بررسی کن", "Check for a new version when this page opens")
            textSize = 12f
            setTextColor(textColor())
            isChecked = FontStudioStore.autoCheck(this@FontStudioHubActivity)
            setOnCheckedChangeListener { _, on -> FontStudioStore.setAutoCheck(this@FontStudioHubActivity, on) }
        })
        content.addView(note(AppLang.t(
            "حذف استودیو فقط فایل‌های خود استودیو را پاک می‌کند؛ پروژه‌ها و فایل‌های کاری شما می‌مانند.",
            "Removing the studio only deletes the studio's own files; your projects and working files stay."
        )))

        if (FontStudioStore.autoCheck(this) && !busy && !autoChecked) {
            autoChecked = true
            FontStudioRemote.async({ FontStudioRemote.check(this) }) { r ->
                r.getOrNull()?.let { if (it.kind == FontStudioRemote.Kind.NEW_VERSION && !isFinishing) render() }
            }
        }
    }

    private var autoChecked = false

    // ------------------------------------------------------------------ کارها

    private fun setBusy(on: Boolean, msg: String = "") {
        busy = on
        progress.visibility = if (on) View.VISIBLE else View.GONE
        progress.isIndeterminate = on
        statusView.visibility = if (msg.isEmpty() && !on) View.GONE else View.VISIBLE
        statusView.text = msg
        cancelBtn.visibility = View.GONE
    }

    private fun downloadFromRepo() {
        if (busy) return
        val c = FontStudioRemote.Cancel()
        cancel = c
        setBusy(true, AppLang.t("در حال اتصال به مخزن…", "Connecting to the repository…"))
        cancelBtn.visibility = View.VISIBLE
        FontStudioRemote.async({
            FontStudioRemote.downloadAndInstall(this, c,
                { done, total ->
                    runOnUiThread {
                        progress.isIndeterminate = total <= 0
                        if (total > 0) progress.progress = (done * 1000 / total).toInt()
                        statusView.text = AppLang.t("در حال دانلود… ", "Downloading… ") + mb(done) + if (total > 0) " / " + mb(total) else ""
                    }
                },
                { _, label -> runOnUiThread { progress.isIndeterminate = true; cancelBtn.visibility = View.GONE; statusView.text = AppLang.t("در حال استخراج: ", "Extracting: ") + label.takeLast(40) } })
        }) { r -> finishInstall(r) }
    }

    private fun unzipFrom(uri: Uri) {
        if (busy) return
        setBusy(true, AppLang.t("در حال بررسی و استخراج زیپ…", "Checking and extracting the zip…"))
        FontStudioRemote.async({
            FontStudioInstaller.installFromUri(this, uri) { _, label ->
                runOnUiThread { statusView.text = AppLang.t("در حال استخراج: ", "Extracting: ") + label.takeLast(40) }
            }
        }) { r -> finishInstall(r) }
    }

    private fun finishInstall(r: Result<FontStudioInstaller.Result>) {
        setBusy(false)
        r.onSuccess {
            Toast.makeText(this, AppLang.t("استودیو نصب شد ✔ (نسخهٔ ${it.manifest.versionName})", "Studio installed ✔ (version ${it.manifest.versionName})"), Toast.LENGTH_LONG).show()
            render()
        }.onFailure {
            AlertDialog.Builder(this)
                .setTitle(AppLang.t("نصب استودیو ناموفق بود", "Studio install failed"))
                .setMessage(it.message ?: "")
                .setPositiveButton(AppLang.t("باشه", "OK"), null)
                .show()
            render()
        }
    }

    private fun checkAndUpdate() {
        if (busy) return
        setBusy(true, AppLang.t("در حال بررسی نسخهٔ مخزن…", "Checking the repository version…"))
        FontStudioRemote.async({ FontStudioRemote.check(this) }) { r ->
            setBusy(false)
            r.onSuccess { o ->
                when (o.kind) {
                    FontStudioRemote.Kind.NEW_VERSION, FontStudioRemote.Kind.NOT_INSTALLED -> {
                        AlertDialog.Builder(this)
                            .setTitle(AppLang.t("نسخهٔ جدید موجود است", "A new version is available"))
                            .setMessage(
                                AppLang.t("نسخهٔ مخزن: ", "Repository version: ") + o.meta.versionName + (if (o.meta.releasedAt.isNotBlank()) " (" + o.meta.releasedAt + ")" else "") + "\n" +
                                    (if (o.meta.size > 0) AppLang.t("حجم: ", "Size: ") + mb(o.meta.size) + "\n" else "") + o.meta.notes
                            )
                            .setPositiveButton(AppLang.t("دانلود و نصب", "Download and install")) { _, _ -> downloadFromRepo() }
                            .setNegativeButton(AppLang.t("بعداً", "Later"), null)
                            .show()
                    }
                    FontStudioRemote.Kind.UP_TO_DATE ->
                        Toast.makeText(this, AppLang.t("نسخهٔ شما به‌روز است.", "You're up to date."), Toast.LENGTH_SHORT).show()
                    FontStudioRemote.Kind.REMOTE_OLDER ->
                        Toast.makeText(this, AppLang.t("نسخهٔ نصب‌شدهٔ شما از مخزن جدیدتر است.", "Your installed version is newer than the repository."), Toast.LENGTH_SHORT).show()
                }
                render()
            }.onFailure {
                Toast.makeText(this, it.message ?: "", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun verify() {
        if (busy) return
        setBusy(true, AppLang.t("در حال بررسی سلامت فایل‌ها…", "Verifying files…"))
        FontStudioRemote.async({ FontStudioInstaller.verifyInstalled(this) }) { r ->
            setBusy(false)
            val problem = r.getOrNull()
            AlertDialog.Builder(this)
                .setTitle(AppLang.t("نتیجهٔ بررسی", "Result"))
                .setMessage(if (r.isFailure) (r.exceptionOrNull()?.message ?: "") else problem
                    ?: AppLang.t("همهٔ فایل‌های استودیو سالم‌اند ✔", "All studio files are intact ✔"))
                .setPositiveButton(AppLang.t("باشه", "OK"), null)
                .apply {
                    if (problem != null) setNeutralButton(AppLang.t("دانلود دوباره", "Download again")) { _, _ -> downloadFromRepo() }
                }
                .show()
        }
    }

    private fun confirmRemove() {
        AlertDialog.Builder(this)
            .setTitle(AppLang.t("حذف استودیو؟", "Remove the studio?"))
            .setMessage(AppLang.t(
                "فایل‌های استودیو پاک می‌شود. پروژه‌ها و فایل‌های کاری شما می‌مانند و هر وقت دوباره دانلود کنید قابل‌استفاده‌اند.",
                "The studio files will be deleted. Your projects and working files stay and are usable again whenever you re-download."
            ))
            .setPositiveButton(AppLang.t("حذف", "Remove")) { _, _ -> FontStudioStore.uninstall(this); render() }
            .setNegativeButton(AppLang.t("انصراف", "Cancel"), null)
            .show()
    }

    /** فقط فونت‌هایی که اجازهٔ باز شدن در استودیو را دارند: فونت همراه برنامه (بدون نسخهٔ رمزنگاری‌شدهٔ جایگزین) و فونت‌های خود کاربر. */
    private fun editableFonts(): List<String> {
        val bundled = FontManager.listBundledFonts(this).filter { !FontManager.hasUpdatedBundledVersion(this, it) }
        return bundled + FontManager.listCustomFonts(this)
    }

    private fun editDefaultFont() {
        val name = FontManager.getSelectedFontFile(this) ?: FontManager.getDefaultFontFile(this)
        if (name == null || name !in editableFonts()) {
            Toast.makeText(this, AppLang.t(
                "فونت پیش‌فرض اپلیکیشن محافظت‌شده است؛ یکی از فونت‌های دیگر را انتخاب کنید.",
                "The app's default font is protected; choose another font."
            ), Toast.LENGTH_LONG).show()
            chooseAppFont()
            return
        }
        FontStudioHostActivity.open(this, "editAppDefault", name)
    }

    private fun chooseAppFont() {
        val list = editableFonts()
        if (list.isEmpty()) {
            Toast.makeText(this, AppLang.t("فونتی برای ویرایش پیدا نشد.", "No editable font was found."), Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(AppLang.t("کدام فونت ویرایش شود؟", "Which font to edit?"))
            .setItems(list.map { FontManager.displayName(it) }.toTypedArray()) { _, i ->
                FontStudioHostActivity.open(this, "editAppFont", list[i])
            }
            .setNegativeButton(AppLang.t("انصراف", "Cancel"), null)
            .show()
    }

    /** کارت اطلاعات آخرین نسخهٔ مخزن (از آخرین بررسی)؛ اگر هنوز بررسی نشده null. */
    private fun remoteInfoCard(): View? {
        val v = FontStudioStore.lastRemoteVersion(this)
        if (v <= 0) return null
        val installed = FontStudioStore.installedVersionCode(this)
        val notes = AppLang.t(
            FontStudioStore.remoteNotesFa(this).ifBlank { FontStudioStore.remoteNotesEn(this) },
            FontStudioStore.remoteNotesEn(this).ifBlank { FontStudioStore.remoteNotesFa(this) }
        )
        val date = FontStudioStore.remoteDate(this)
        val size = FontStudioStore.remoteSize(this)
        val checked = FontStudioStore.lastCheckedAt(this)
        return card(color(R.attr.appSurface)).apply {
            val newer = FontStudioStore.isInstalled(this@FontStudioHubActivity) && v > installed
            addView(label((if (newer) "🔔 " else "ℹ️ ") + AppLang.t("آخرین نسخهٔ مخزن", "Latest version in the repository"), 13f, bold = true))
            addView(label(
                AppLang.t("نسخه: ", "Version: ") + FontStudioStore.remoteName(this@FontStudioHubActivity).ifBlank { v.toString() } +
                    (if (date.isNotBlank()) "\n" + AppLang.t("تاریخ انتشار: ", "Released: ") + date else "") +
                    (if (size > 0) "\n" + AppLang.t("حجم: ", "Size: ") + mb(size) else "") +
                    (if (checked > 0) "\n" + AppLang.t("آخرین بررسی: ", "Last checked: ") + java.text.DateFormat.getDateTimeInstance().format(java.util.Date(checked)) else ""),
                12f
            ).apply { setPadding(0, dp(6), 0, 0) })
            if (notes.isNotBlank()) addView(label("📝 $notes", 12f).apply { setPadding(0, dp(8), 0, 0); alpha = 0.9f })
            if (newer) addView(chip(AppLang.t("⬇ بروزرسانی به این نسخه", "⬇ Update to this version")) { downloadFromRepo() }.apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }
            })
        }
    }

    private fun openRepoPage() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(FontStudioRemote.REPO_PAGE)))
        } catch (_: Exception) {
            Toast.makeText(this, FontStudioRemote.REPO_PAGE, Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------------ ابزارهای رسم

    private fun mb(b: Long): String = String.format(Locale.US, "%.1f MB", b / 1024.0 / 1024.0)

    private fun dirSize(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

    private fun label(text: String, sizeSp: Float, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(textColor())
        textDirection = AppLang.textDirection
        setLineSpacing(0f, 1.2f)
        if (bold) setTypeface(Typeface.DEFAULT_BOLD)
    }

    private fun note(text: String): TextView = label(text, 11f).apply { alpha = 0.7f; setPadding(dp(4), dp(12), dp(4), 0) }

    private fun section(text: String): TextView = label(text, 12.5f, bold = true).apply { setPadding(dp(2), dp(16), dp(2), dp(6)) }

    private fun card(bg: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(bg) }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }
    }

    private fun chip(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 11.5f
        gravity = Gravity.CENTER
        maxLines = 3
        setTextColor(textColor())
        setPadding(dp(8), dp(10), dp(8), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(color(R.attr.appSurface))
            setStroke(dp(1), color(R.attr.appPrimary))
        }
        setOnClickListener { onClick() }
    }

    private fun bigButton(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 14f
        gravity = Gravity.CENTER
        setTypeface(Typeface.DEFAULT_BOLD)
        setTextColor(color(R.attr.appOnAccent))
        setPadding(dp(12), dp(14), dp(12), dp(14))
        background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(color(R.attr.appAccent)) }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }
    }

    private fun row(a: View, b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(0, 0, dp(4), 0) })
        addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(dp(4), 0, 0, 0) })
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    }
}
