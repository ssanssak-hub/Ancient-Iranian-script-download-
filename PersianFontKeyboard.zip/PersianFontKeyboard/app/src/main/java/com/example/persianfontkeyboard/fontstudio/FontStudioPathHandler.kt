package com.example.persianfontkeyboard.fontstudio

import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.FileInputStream

/**
 * فایل‌های یک پوشه را از آدرس مجازی `https://appassets.androidplatform.net/<prefix>/…` به صفحهٔ استودیو می‌دهد.
 * فقط داخل [root] می‌خواند (مسیر کانونیکال بررسی می‌شود؛ `..` و لینک نمادین جواب نمی‌دهند).
 *
 *  /studio/…  ← فایل‌های بستهٔ نصب‌شده (کش‌پذیر)
 *  /__io/…    ← فایل‌های رد و بدل‌شده با گوشی (کش نمی‌شود)
 *  /__ws/…    ← فضای کار کاربر (کش نمی‌شود)
 */
class FontStudioPathHandler(
    private val root: File,
    private val cacheable: Boolean,
    private val isStudioPage: Boolean = false
) : WebViewAssetLoader.PathHandler {

    private val rootCanonical: String = try { root.canonicalPath + File.separator } catch (_: Exception) { root.absolutePath + File.separator }

    override fun handle(path: String): WebResourceResponse? {
        return try {
            // path از Uri.getPath() می‌آید و پیش‌تر دیکد شده؛ دوباره دیکد نمی‌کنیم.
            val rel = FontStudioManifest.normalize(path) ?: return notFound()
            val f = File(root, rel)
            val canon = f.canonicalPath
            if (!canon.startsWith(rootCanonical) || !f.isFile) return notFound()
            val ext = f.name.substringAfterLast('.', "").lowercase()
            val mime = mimeOf(ext)
            val headers = HashMap<String, String>()
            headers["Cache-Control"] = if (cacheable) "public, max-age=3600" else "no-store"
            headers["X-Content-Type-Options"] = "nosniff"
            if (isStudioPage && (ext == "html" || ext == "htm")) {
                headers["Content-Security-Policy"] = CSP
            }
            val resp = WebResourceResponse(mime, if (mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") || mime.contains("svg")) "utf-8" else null, FileInputStream(f))
            resp.responseHeaders = headers
            resp
        } catch (_: Exception) {
            notFound()
        }
    }

    private fun notFound(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))

    companion object {
        /**
         * سیاست امنیتی صفحه: هیچ منبع بیرونی بارگذاری نمی‌شود و هیچ درخواست شبکه‌ای به بیرون ممکن نیست.
         * 'wasm-unsafe-eval' برای موتورهای WebAssembly (مثل HarfBuzz/FreeType/Brotli).
         */
        const val CSP = "default-src 'self'; script-src 'self' 'wasm-unsafe-eval' blob:; " +
            "style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data: blob:; " +
            "connect-src 'self' data: blob:; worker-src 'self' blob:; media-src 'self' blob:; " +
            "object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"

        fun mimeOf(ext: String): String = when (ext) {
            "html", "htm" -> "text/html"
            "js", "mjs" -> "text/javascript"
            "css" -> "text/css"
            "json", "map" -> "application/json"
            "wasm" -> "application/wasm"
            "svg" -> "image/svg+xml"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "ico" -> "image/x-icon"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "txt", "md", "csv" -> "text/plain"
            else -> "application/octet-stream"
        }
    }
}
