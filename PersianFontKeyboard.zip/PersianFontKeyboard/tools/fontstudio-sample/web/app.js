(function () {
  'use strict';
  var H = window.FontStudioHost;
  function $(id) { return document.getElementById(id); }
  function show(id, v) { $(id).textContent = typeof v === 'string' ? v : JSON.stringify(v, null, 2); }
  if (!H) { show('info', 'FontStudioHost در دسترس نیست!'); return; }

  show('info', H.info);
  H.on('pause', function () { H.ws.putText('autosave/last.txt', 'paused at ' + new Date().toISOString()); });

  var lastBytes = null, lastName = 'sample.txt';
  $('btnPick').onclick = function () {
    H.pickFiles({ multiple: false }).then(function (files) {
      if (!files.length) return show('fileOut', 'لغو شد');
      var f = files[0];
      return H.fetchBytes(f.url).then(function (b) {
        lastBytes = b; lastName = f.name;
        show('fileOut', { name: f.name, size: f.size, mime: f.mime, firstBytes: Array.prototype.slice.call(b.subarray(0, 8)) });
      });
    }).catch(function (e) { show('fileOut', String(e)); });
  };
  $('btnSave').onclick = function () {
    H.saveFile(lastBytes || 'نمونهٔ آزمایشی استودیو فونت\n', lastBytes ? lastName : 'studio-test.txt', 'application/octet-stream')
      .then(function (r) { show('fileOut', r); }).catch(function (e) { show('fileOut', String(e)); });
  };
  $('btnShare').onclick = function () {
    H.shareFile(lastBytes || 'نمونه', lastBytes ? lastName : 'studio-test.txt', 'application/octet-stream')
      .then(function (ok) { show('fileOut', 'share: ' + ok); });
  };

  var loadedFont = null;
  $('btnFonts').onclick = function () {
    var list = H.appFonts.list(), box = $('fontList');
    box.textContent = '';
    list.forEach(function (f) {
      var b = document.createElement('button');
      b.className = 'font-row';
      b.textContent = f.display + ' · ' + f.kind + (f.exportable ? '' : ' 🔒');
      b.disabled = !f.exportable;
      b.onclick = function () {
        H.appFonts.exportToStudio(f.name).then(function (r) {
          loadedFont = r;
          var face = new FontFace('TestFace', r.bytes.buffer);
          return face.load().then(function () {
            document.fonts.add(face);
            $('preview').style.fontFamily = 'TestFace';
            $('btnInstall').disabled = false;
            show('fontOut', 'بارگذاری شد: ' + r.name + ' (' + r.bytes.length + ' بایت)');
          });
        }).catch(function (e) { show('fontOut', String(e)); });
      };
      box.appendChild(b);
    });
    show('fontOut', list.length + ' فونت');
  };
  $('btnInstall').onclick = function () {
    if (!loadedFont) return;
    H.appFonts.install(loadedFont.bytes, 'test_' + loadedFont.name)
      .then(function (m) { show('fontOut', m); }).catch(function (e) { show('fontOut', String(e)); });
  };

  $('btnWs').onclick = function () {
    var proj = JSON.stringify({ name: 'پروژهٔ نمونه', savedAt: Date.now() });
    H.ws.put('projects/demo/project.json', proj)
      .then(function () { return H.ws.read('projects/demo/project.json'); })
      .then(function (b) {
        show('wsOut', { read: new TextDecoder().decode(b), list: H.ws.list('projects/demo'), usage: H.ws.usage() });
      }).catch(function (e) { show('wsOut', String(e)); });
  };

  $('btnToast').onclick = function () { H.toast('سلام از استودیو 👋'); };
  $('btnHaptic').onclick = function () { H.haptic('click'); };
  var unsaved = false;
  $('btnUnsaved').onclick = function () { unsaved = !unsaved; H.setUnsaved(unsaved); H.toast(unsaved ? 'ذخیره‌نشده: روشن' : 'ذخیره‌نشده: خاموش'); };
  $('btnMgr').onclick = function () { H.openManager(); };
  $('btnClose').onclick = function () { H.close(); };
  H.setBackHandler(function () { return false; });
})();
