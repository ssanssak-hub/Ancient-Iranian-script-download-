import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.stream.*;
import java.util.zip.*;

/**
 * ساخت و امضای بستهٔ «استودیو ساخت و ویرایش فونت» (بدون وابستگی؛ فقط JDK 11+).
 *
 *  ۱) ساخت جفت‌کلید (یک‌بار):
 *       java tools/FontStudioPackager.java genkey keys/
 *     ← keys/private.b64 (محرمانه! در مخزن نگذارید)  و  keys/public.b64
 *     محتوای public.b64 را در app/src/main/res/values/fontstudio_keys.xml (font_studio_pubkey) بگذارید.
 *
 *  ۲) ساخت بسته:
 *       java tools/FontStudioPackager.java pack <پوشهٔ-وب> <خروجی.zip> --version-code 1 --version-name 1.0.0 \
 *            [--min-app 1] [--host-api 1] [--key keys/private.b64] [--notes-file notes-fa.txt] [--notes-en-file notes-en.txt] [--released 2026-11-26]
 *     پوشهٔ وب باید index.html داشته باشد؛ همهٔ فایل‌ها زیر web/ در زیپ قرار می‌گیرند.
 *     کنار زیپ، فایل fontstudio.meta.json هم ساخته می‌شود (هر دو را در پوشهٔ createfonts مخزن بگذارید).
 *     بدون --key: بستهٔ بی‌امضا (فقط برای «حالت توسعه»ٔ برنامه که کلید عمومی‌اش خالی است).
 */
public class FontStudioPackager {

    public static void main(String[] a) throws Exception {
        if (a.length == 0) usage();
        switch (a[0]) {
            case "genkey": genkey(Paths.get(a.length > 1 ? a[1] : "keys")); break;
            case "pack": pack(a); break;
            default: usage();
        }
    }

    static void usage() {
        System.err.println("genkey <dir>  |  pack <webDir> <out.zip> --version-code N --version-name X [--min-app N] [--host-api N] [--key private.b64] [--notes T | --notes-file f.txt] [--notes-en T | --notes-en-file f.txt] [--released YYYY-MM-DD] [--app-id ID]");
        System.exit(2);
    }

    static void genkey(Path dir) throws Exception {
        Files.createDirectories(dir);
        KeyPairGenerator g = KeyPairGenerator.getInstance("EC");
        g.initialize(new java.security.spec.ECGenParameterSpec("secp256r1"));
        KeyPair kp = g.generateKeyPair();
        Files.write(dir.resolve("private.b64"), Base64.getEncoder().encode(kp.getPrivate().getEncoded()));
        Files.write(dir.resolve("public.b64"), Base64.getEncoder().encode(kp.getPublic().getEncoded()));
        System.out.println("ساخته شد: " + dir.resolve("private.b64") + " (محرمانه) و " + dir.resolve("public.b64"));
    }

    static String sha256(Path p) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(p)) {
            byte[] buf = new byte[65536]; int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    /** رشتهٔ امن برای JSON؛ نویسه‌های غیر ASCII (فارسی) به \\uXXXX تبدیل می‌شوند تا به کدگذاری ترمینال وابسته نباشد. */
    static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '\\') b.append("\\\\");
            else if (c == '"') b.append("\\\"");
            else if (c == '\n') b.append("\\n");
            else if (c == '\r') { }
            else if (c < 32 || c > 126) b.append(String.format("\\u%04x", (int) c));
            else b.append(c);
        }
        return b.toString();
    }
    static String readText(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8).trim();
    }

    static void pack(String[] a) throws Exception {
        if (a.length < 3) usage();
        Path web = Paths.get(a[1]);
        Path out = Paths.get(a[2]);
        Map<String, String> o = new HashMap<>();
        for (int i = 3; i + 1 < a.length; i += 2) o.put(a[i], a[i + 1]);
        int vc = Integer.parseInt(o.getOrDefault("--version-code", "1"));
        String vn = o.getOrDefault("--version-name", "1.0.0");
        int minApp = Integer.parseInt(o.getOrDefault("--min-app", "1"));
        int hostApi = Integer.parseInt(o.getOrDefault("--host-api", "1"));
        String appId = o.getOrDefault("--app-id", "irani.script.keyboards");
        String notes = o.containsKey("--notes-file") ? readText(o.get("--notes-file")) : o.getOrDefault("--notes", "");
        String notesEn = o.containsKey("--notes-en-file") ? readText(o.get("--notes-en-file")) : o.getOrDefault("--notes-en", "");
        String released = o.getOrDefault("--released", java.time.LocalDate.now().toString());
        if (!Files.isRegularFile(web.resolve("index.html"))) throw new IllegalArgumentException("index.html در پوشهٔ وب نیست");

        List<Path> files;
        try (Stream<Path> s = Files.walk(web)) {
            files = s.filter(Files::isRegularFile).sorted().collect(Collectors.toList());
        }
        TreeMap<String, String> hashes = new TreeMap<>();
        for (Path f : files) {
            String rel = "web/" + web.relativize(f).toString().replace('\\', '/');
            if (rel.endsWith(".DS_Store") || rel.endsWith("Thumbs.db")) continue;
            hashes.put(rel, sha256(f));
        }
        StringBuilder m = new StringBuilder();
        m.append("{\n  \"id\": \"font-studio\",\n");
        m.append("  \"applicationId\": \"").append(esc(appId)).append("\",\n");
        m.append("  \"versionCode\": ").append(vc).append(",\n");
        m.append("  \"versionName\": \"").append(esc(vn)).append("\",\n");
        m.append("  \"minAppVersionCode\": ").append(minApp).append(",\n");
        m.append("  \"hostApi\": ").append(hostApi).append(",\n");
        m.append("  \"entry\": \"web/index.html\",\n  \"files\": {\n");
        int i = 0;
        for (Map.Entry<String, String> e : hashes.entrySet()) {
            m.append("    \"").append(esc(e.getKey())).append("\": \"").append(e.getValue()).append("\"");
            m.append(++i < hashes.size() ? ",\n" : "\n");
        }
        m.append("  }\n}\n");
        byte[] manifest = m.toString().getBytes(StandardCharsets.UTF_8);

        byte[] sig = null;
        if (o.containsKey("--key")) {
            byte[] raw = Base64.getDecoder().decode(new String(Files.readAllBytes(Paths.get(o.get("--key"))), StandardCharsets.UTF_8).trim());
            PrivateKey pk = KeyFactory.getInstance("EC").generatePrivate(new PKCS8EncodedKeySpec(raw));
            Signature s = Signature.getInstance("SHA256withECDSA");
            s.initSign(pk);
            s.update(manifest);
            sig = Base64.getEncoder().encode(s.sign());
        }

        Path parent = out.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        try (ZipOutputStream z = new ZipOutputStream(Files.newOutputStream(out))) {
            z.setLevel(9);
            put(z, "manifest.json", manifest);
            if (sig != null) put(z, "manifest.sig", sig);
            for (Path f : files) {
                String rel = "web/" + web.relativize(f).toString().replace('\\', '/');
                if (!hashes.containsKey(rel)) continue;
                put(z, rel, Files.readAllBytes(f));
            }
        }
        String zipName = out.getFileName().toString();
        String meta = "{\n  \"version\": " + vc + ",\n  \"versionName\": \"" + esc(vn) + "\",\n  \"sha256\": \"" + sha256(out)
            + "\",\n  \"size\": " + Files.size(out) + ",\n  \"zip\": \"" + esc(zipName) + "\",\n  \"minAppVersionCode\": " + minApp
            + ",\n  \"releasedAt\": \"" + esc(released) + "\",\n  \"notes\": \"" + esc(notes) + "\",\n  \"notesEn\": \"" + esc(notesEn) + "\"\n}\n";
        Path metaPath = (parent != null ? parent : Paths.get(".")).resolve("fontstudio.meta.json");
        Files.write(metaPath, meta.getBytes(StandardCharsets.UTF_8));
        System.out.println("OK  " + out + "  (" + Files.size(out) + " bytes, " + hashes.size() + " files, " + (sig != null ? "signed" : "UNSIGNED") + ")");
        System.out.println("meta: " + metaPath);
    }

    static void put(ZipOutputStream z, String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setTime(0L);
        z.putNextEntry(e);
        z.write(data);
        z.closeEntry();
    }
}
